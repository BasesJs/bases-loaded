﻿// Decompiled with JetBrains decompiler
// Type: FirstCitizens.ContentServices.OnBase.Wamcon.VirtualDirectory
// Assembly: WebApplicationManagementConsole, Version=25.1.2.1000, Culture=neutral, PublicKeyToken=null
// MVID: E12C454C-A807-4890-B0D3-E1DEC2961811
// Assembly location: C:\Users\jacob\OpenCloud\Code\Web Applications Management Console\WebApplicationManagementConsole.exe

using System;
using System.DirectoryServices;

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class VirtualDirectory : IDisposable
{
  private long _siteId;
  private string _siteName;
  private string _name;
  private string _appName;
  private string _physicalPath;
  private string _locationPath;
  private DirectoryEntry _directoryEntry;
  private DirectoryEntry _directoryEntryParent;
  private ServerManager _serverManager;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ServerManager _microsoftServerManager;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.VirtualDirectory _microsoftVirtualDirectory;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.Application _microsoftApplication;

  internal VirtualDirectory(
    ServerManager serverManager,
    string name,
    long siteId,
    string siteName,
    string appName)
  {
    this._serverManager = serverManager;
    this._name = name;
    this._siteId = siteId;
    this._siteName = siteName;
    this._appName = appName;
    string key1 = appName;
    if (key1 != null)
      key1 = Utility.PrependSlash(this._appName);
    string key2 = Utility.PrependSlash(this._name);
    this._microsoftServerManager = this._serverManager.MicrosoftServerManager;
    this._microsoftApplication = this._microsoftServerManager.Sites[this._siteName].Applications[key1];
    this._microsoftVirtualDirectory = this._microsoftApplication.VirtualDirectories[key2];
    this._physicalPath = this._microsoftApplication.VirtualDirectories[key2].PhysicalPath;
    this._locationPath = $"{this._siteName}/{this._name}";
  }

  public string Name => this._name.TrimStart('/');

  public string SiteName => this._siteName;

  public string AppName => this._appName;

  public long SiteId => this._siteId;

  public string PhysicalPath
  {
    get => this._physicalPath;
    set
    {
      this._microsoftVirtualDirectory.PhysicalPath = value;
      this._microsoftServerManager.CommitChanges();
      this._physicalPath = value;
    }
  }

  internal DirectoryEntry DirectoryEntry => this._directoryEntry;

  internal DirectoryEntry DirectoryEntryParent => this._directoryEntryParent;

  public void Dispose()
  {
    if (this._directoryEntry != null)
    {
      this._directoryEntry.Dispose();
      this._directoryEntry = (DirectoryEntry) null;
    }
    if (this._directoryEntryParent == null)
      return;
    this._directoryEntryParent.Dispose();
    this._directoryEntryParent = (DirectoryEntry) null;
  }

  public override string ToString() => $"Name = {this._name}";
}
