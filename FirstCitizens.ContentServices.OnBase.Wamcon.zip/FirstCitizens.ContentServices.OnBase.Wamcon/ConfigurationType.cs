﻿
namespace FirstCitizens.ContentServices.OnBase.Wamcon;
public enum ConfigurationType
{
  AgendaPubAccess,
  ApplicationServer,
  DeficiencyPop,
  FiServ_PDS1450,
  HealthcareFormManager,
  IdentityProvider,
  JackHenryServer,
  MobileBroker,
  PatientWindow,
  PlanReview,
  PublicAccessLegacy,
  PublicAccessNextGen,
  ReportingViewer,
  WebServer,
  WebServicePublishing,
  WOPI,
  Unknown,
}
