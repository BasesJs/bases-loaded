﻿using System.Collections.Generic;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.Logging;

public class LoggingRoute
{
  public LoggingRoute(string name)
  {
    this.Name = name;
    this.Pairs = new Dictionary<string, string>();
  }

  public string Name { get; set; }

  public LoggingRoute.SourceType Source { get; set; }

  public Dictionary<string, string> Pairs { get; set; }

  public enum SourceType
  {
    Diagnostics,
    Audit,
  }
}
