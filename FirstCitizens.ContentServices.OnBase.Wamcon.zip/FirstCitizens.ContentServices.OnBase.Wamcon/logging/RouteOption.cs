﻿using System.Collections.Generic;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.Logging;

public class RouteOption
{
  public RouteOption(KeyValuePair<string, string> pair)
  {
    this.Key = pair.Key;
    this.Value = pair.Value;
  }

  public string Key { get; set; }

  public string Value { get; set; }
}
