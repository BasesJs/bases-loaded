﻿using System;
using System.ComponentModel;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.Logging;

public class LoggingProperties : INotifyPropertyChanged
{
  private string _eventSource;
  private bool _selfDebug;
  private int _truncateLogValues;
  private bool _writeFile;
  private string _eventLogLocation;
  private int _maxFileSize;
  private int _maxFiles;
  private int _minimumChecks;

  public string EventSource
  {
    get => this._eventSource;
    set
    {
      if (!(this._eventSource != value))
        return;
      this._eventSource = value;
      this.NotifyPropertyChanged(nameof (EventSource));
    }
  }

  public bool SelfDebug
  {
    get => this._selfDebug;
    set
    {
      if (this._selfDebug == value)
        return;
      this._selfDebug = value;
      this.NotifyPropertyChanged(nameof (SelfDebug));
    }
  }

  public int TruncateLogValues
  {
    get => this._truncateLogValues;
    set
    {
      if (this._truncateLogValues == value)
        return;
      this._truncateLogValues = value;
      this.NotifyPropertyChanged(nameof (TruncateLogValues));
    }
  }

  public bool WriteFile
  {
    get => this._writeFile;
    set
    {
      if (this._writeFile == value)
        return;
      this._writeFile = value;
      this.NotifyPropertyChanged(nameof (WriteFile));
    }
  }

  public string EventLogLocation
  {
    get => this._eventLogLocation;
    set
    {
      if (!(this._eventLogLocation != value))
        return;
      this._eventLogLocation = value;
      this.NotifyPropertyChanged(nameof (EventLogLocation));
    }
  }

  public int MaxFilesSize
  {
    get => this._maxFileSize;
    set
    {
      if (this._maxFileSize == value)
        return;
      this._maxFileSize = value;
      this.NotifyPropertyChanged(nameof (MaxFilesSize));
    }
  }

  public int MaxFile
  {
    get => this._maxFiles;
    set
    {
      if (this._maxFiles == value)
        return;
      this._maxFiles = value;
      this.NotifyPropertyChanged(nameof (MaxFile));
    }
  }

  public int MinimumChecks
  {
    get => this._minimumChecks;
    set
    {
      if (this._minimumChecks == value)
        return;
      this._minimumChecks = value;
      this.NotifyPropertyChanged(nameof (MinimumChecks));
    }
  }

  public Action SaveButtonEnabled { get; set; }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string propertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged != null)
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    Action saveButtonEnabled = this.SaveButtonEnabled;
    if (saveButtonEnabled == null)
      return;
    saveButtonEnabled();
  }
}
