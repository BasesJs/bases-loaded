﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.Logging;

public class RouteTypeProperties
{
  public string RouteName { get; set; }

  public bool Logging { get; set; }

  public bool Audit { get; set; }
}
