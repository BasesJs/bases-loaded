﻿// Decompiled with JetBrains decompiler
// Type: FirstCitizens.ContentServices.OnBase.Wamcon.Application
// Assembly: WebApplicationManagementConsole, Version=25.1.2.1000, Culture=neutral, PublicKeyToken=null
// MVID: E12C454C-A807-4890-B0D3-E1DEC2961811
// Assembly location: C:\Users\jacob\OpenCloud\Code\Web Applications Management Console\WebApplicationManagementConsole.exe

using System.DirectoryServices;

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class Application : IDisposable
{
  private long _siteId;
  private string _siteName;
  private string _name;
  private string _applicationPoolName;
  private string _physicalPath;
  private string _locationPath;
  private DirectoryEntry _directoryEntry;
  private DirectoryEntry _directoryEntryParent;
  private ServerManager _serverManager;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ServerManager _microsoftServerManager;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.Application _microsoftApplication;
  private Configuration _applicationConfig;
  private Configuration _applicationHostConfig;
  private VirtualDirectoryCollection _virtualDirectories;

  internal Application(
    ServerManager serverManager,
    string name,
    string fullName,
    long siteId,
    string siteName)
  {
    this._serverManager = serverManager;
    this._name = name;
    this._siteId = siteId;
    this._siteName = siteName;
    this._virtualDirectories = new VirtualDirectoryCollection(this._serverManager, this._siteName, this._siteId, this._name);
    this._microsoftServerManager = this._serverManager.MicrosoftServerManager;
    this._microsoftApplication = this._microsoftServerManager.Sites[this._siteName].Applications[fullName];
    this._applicationPoolName = this._microsoftApplication.ApplicationPoolName;
    this._physicalPath = this._microsoftApplication.VirtualDirectories["/"].PhysicalPath;
    this._locationPath = $"{this._siteName}/{this._name}";
    foreach (FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.VirtualDirectory virtualDirectory1 in this._microsoftApplication.VirtualDirectories)
    {
      using (VirtualDirectory virtualDirectory2 = new VirtualDirectory(this._serverManager, virtualDirectory1.Path, this._siteId, this._siteName, fullName))
        this._virtualDirectories.Add(virtualDirectory2);
    }
  }

  public string Name => this._name;

  public string SiteName => this._siteName;

  public long SiteId => this._siteId;

  public string PhysicalPath
  {
    get => this._physicalPath;
    set
    {
      this._microsoftApplication.VirtualDirectories["/"].PhysicalPath = value;
      this._microsoftServerManager.CommitChanges();
      this._physicalPath = value;
    }
  }

  public string ApplicationPoolName
  {
    get => this._applicationPoolName;
    set
    {
      this._microsoftApplication.ApplicationPoolName = value;
      this._microsoftServerManager.CommitChanges();
      this._applicationPoolName = value;
    }
  }

  public string DefaultDocument
  {
    set
    {
      this.RefreshApplicationConfig();
      ConfigurationElementCollection collection = this._applicationConfig.GetSection("system.webServer/defaultDocument").GetCollection("files");
      collection.Clear();
      ConfigurationElement element = collection.CreateElement();
      element[nameof (value)] = (object) value;
      collection.Add(element);
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool EnableSsl
  {
    set
    {
      this.RefreshApplicationHostConfig();
      this._applicationHostConfig.GetSection("system.webServer/security/access", this._locationPath)["sslFlags"] = !value ? (object) "None" : (object) "Ssl";
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool EnableSsl128
  {
    set
    {
      this.RefreshApplicationHostConfig();
      this._applicationHostConfig.GetSection("system.webServer/security/access", this._locationPath)["sslFlags"] = !value ? (object) "None" : (object) "Ssl, Ssl128";
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool AnonymousAuthentication
  {
    get
    {
      this.RefreshApplicationHostConfig();
      return Convert.ToBoolean(this._applicationHostConfig.GetSection("system.webServer/security/authentication/anonymousAuthentication", this._locationPath)["enabled"]);
    }
    set
    {
      this.RefreshApplicationHostConfig();
      this._applicationHostConfig.GetSection("system.webServer/security/authentication/anonymousAuthentication", this._locationPath)["enabled"] = (object) value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool WindowsAuthentication
  {
    get
    {
      this.RefreshApplicationHostConfig();
      return Convert.ToBoolean(this._applicationHostConfig.GetSection("system.webServer/security/authentication/windowsAuthentication", this._locationPath)["enabled"]);
    }
    set
    {
      this.RefreshApplicationHostConfig();
      this._applicationHostConfig.GetSection("system.webServer/security/authentication/windowsAuthentication", this._locationPath)["enabled"] = (object) value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool KernelMode
  {
    get
    {
      this.RefreshApplicationHostConfig();
      return Convert.ToBoolean(this._applicationHostConfig.GetSection("system.webServer/security/authentication/windowsAuthentication", this._locationPath)["useKernelMode"]);
    }
    set
    {
      this.RefreshApplicationHostConfig();
      this._applicationHostConfig.GetSection("system.webServer/security/authentication/windowsAuthentication", this._locationPath)["useKernelMode"] = (object) value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool AppPoolCredentials
  {
    get
    {
      this.RefreshApplicationHostConfig();
      return Convert.ToBoolean(this._applicationHostConfig.GetSection("system.webServer/security/authentication/windowsAuthentication", this._locationPath)["useAppPoolCredentials"]);
    }
    set
    {
      this.RefreshApplicationHostConfig();
      this._applicationHostConfig.GetSection("system.webServer/security/authentication/windowsAuthentication", this._locationPath)["useAppPoolCredentials"] = (object) value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public ushort ExpirationInDays
  {
    set
    {
      this.RefreshApplicationConfig();
      ConfigurationElement childElement = this._applicationConfig.GetSection("system.webServer/staticContent").GetChildElement("clientCache");
      if (value == (ushort) 0)
      {
        childElement["cacheControlMode"] = (object) "DisableCache";
      }
      else
      {
        TimeSpan timeSpan = new TimeSpan((int) value, 0, 0, 0);
        childElement["cacheControlMaxAge"] = (object) timeSpan;
        childElement["cacheControlMode"] = (object) "UseMaxAge";
      }
      this._microsoftServerManager.CommitChanges();
    }
  }

  public VirtualDirectoryCollection VirtualDirectories => this._virtualDirectories;

  internal DirectoryEntry DirectoryEntry => this._directoryEntry;

  internal DirectoryEntry DirectoryEntryParent => this._directoryEntryParent;

  public void Dispose()
  {
    if (this._directoryEntry != null)
    {
      this._directoryEntry.Dispose();
      this._directoryEntry = (DirectoryEntry) null;
    }
    if (this._directoryEntryParent == null)
      return;
    this._directoryEntryParent.Dispose();
    this._directoryEntryParent = (DirectoryEntry) null;
  }

  public override string ToString() => $"Name = {this._name}";

  public bool AddMimeType(string FileExtension, string MimeType)
  {
    bool flag1 = false;
    bool flag2 = false;
    this.RefreshApplicationConfig();
    ConfigurationElementCollection collection = this._applicationConfig.GetSection("system.webServer/staticContent").GetCollection();
    foreach (ConfigurationElement configurationElement in collection)
    {
      if (configurationElement.ElementTagName == "mimeMap" && string.Compare(configurationElement["fileExtension"].ToString(), FileExtension, StringComparison.OrdinalIgnoreCase) == 0)
      {
        flag2 = true;
        break;
      }
    }
    if (!flag2)
    {
      ConfigurationElement element = collection.CreateElement("mimeMap");
      element["fileExtension"] = (object) FileExtension;
      element["mimeType"] = (object) MimeType;
      collection.Add(element);
      flag1 = true;
      this._microsoftServerManager.CommitChanges();
    }
    return flag1;
  }

  public bool AddHttpHeader(string Name, string Value)
  {
    bool flag1 = false;
    bool flag2 = false;
    this.RefreshApplicationConfig();
    ConfigurationElementCollection collection = this._applicationConfig.GetSection("system.webServer/httpProtocol").GetCollection("customHeaders");
    foreach (ConfigurationElement configurationElement in collection)
    {
      if (string.Compare(configurationElement["name"].ToString(), Name, StringComparison.OrdinalIgnoreCase) == 0 && string.Compare(configurationElement["value"].ToString(), Value, StringComparison.OrdinalIgnoreCase) == 0)
      {
        flag2 = true;
        break;
      }
    }
    if (!flag2)
    {
      ConfigurationElement element = collection.CreateElement("add");
      element["name"] = (object) Name;
      element["value"] = (object) Value;
      collection.Add(element);
      flag1 = true;
      this._microsoftServerManager.CommitChanges();
    }
    return flag1;
  }

  private void RefreshApplicationConfig()
  {
    this._applicationConfig = this._microsoftApplication.GetWebConfiguration();
  }

  private void RefreshApplicationHostConfig()
  {
    this._applicationHostConfig = this._microsoftServerManager.GetApplicationHostConfiguration();
  }
}
