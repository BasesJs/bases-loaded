﻿using System;
using System.Collections;
using System.Xml;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public class AuthenticationHelper : IDisposable
{
    private static readonly string[] _webSrvloginPages = new string[24]
    {
    "AccLogin.aspx",
    "AccSSOLoginPage.aspx",
    "Apps",
    "AuthOptServicePipeline.ashx",
    "AuthService.asmx",
    "Diagnostics/Diagnostics.aspx",
    "DKTReader.aspx",
    "DocPop/Correction.aspx",
    "DocPop/DocPop.aspx",
    "DocPop/DocPopURLCreator.aspx",
    "DocPop/FormPop.aspx",
    "DocPop/PDFPop.aspx",
    "DocPop/ReindexPop.aspx",
    "FolderPop/FolderPop.aspx",
    "FolderPop/FolderPopURLCreator.aspx",
    "Login.aspx",
    "LoginFormProc.aspx",
    "RecoverAppServerSession.aspx",
    "SharePointPortal.aspx",
    "UnityForm.aspx",
    "Workflow/WFLogin.aspx",
    "WorkView/FilterPop.aspx",
    "WorkView/FilterPopURLCreator.aspx",
    "WorkView/ObjectPop.aspx"
    };
    private static readonly string[] _appSrvEndPoints = new string[2]
    {
    "AuthService.asmx",
    "AuthOptServicePipeline.ashx"
    };
    private static ServerManager serverManager;

    public void Dispose()
    {
        this.Dispose(true);
        GC.SuppressFinalize((object)this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!disposing || AuthenticationHelper.serverManager == null)
            return;
        AuthenticationHelper.serverManager.Dispose();
        AuthenticationHelper.serverManager = (ServerManager)null;
    }

    public static bool CanSetWindowsAuthentication(ApplicationConfiguration appConfig)
    {
        return appConfig.ConfigType == ConfigurationType.WebServer || appConfig.ConfigType == ConfigurationType.ApplicationServer;
    }

    public static bool IsWindowsAuthenticationOptimized(ApplicationConfiguration appConfig)
    {
        bool flag1;
        try
        {
            Application iisApplication = AuthenticationHelper.getIisApplication(appConfig.Name);
            bool windowsAuthentication = iisApplication.WindowsAuthentication;
            bool anonymousAuthentication = iisApplication.AnonymousAuthentication;
            bool kernelMode = iisApplication.KernelMode;
            bool appPoolCredentials = iisApplication.AppPoolCredentials;
            XmlDocument xmlDocument = new XmlDocument();
            string webConfigPath = appConfig.WebConfigPath;
            using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
            {
                XmlResolver = (XmlResolver)null
            }))
                xmlDocument.Load(reader);
            bool flag2 = true;
            string[] pointsForConfigType = AuthenticationHelper.getEndPointsForConfigType(appConfig.ConfigType);
            if (pointsForConfigType != null)
            {
                foreach (string str in pointsForConfigType)
                {
                    XmlNode xmlNode = xmlDocument.DocumentElement.SelectSingleNode($"location[@path='{str}']");
                    if (xmlNode != null)
                    {
                        if (xmlNode.SelectSingleNode("system.webServer/security/authorization/add[@accessType='Deny'][@users='?']") == null)
                        {
                            flag2 = false;
                            break;
                        }
                    }
                    else
                    {
                        flag2 = false;
                        break;
                    }
                }
            }
            flag1 = windowsAuthentication & anonymousAuthentication & flag2 & kernelMode & appPoolCredentials;
        }
        catch
        {
            flag1 = false;
        }
        return flag1;
    }

    public static void EnableWindowsAuthentication(ApplicationConfiguration appConfig)
    {
        Application iisApplication = AuthenticationHelper.getIisApplication(appConfig.Name);
        iisApplication.WindowsAuthentication = true;
        iisApplication.AppPoolCredentials = true;
        iisApplication.KernelMode = true;
        iisApplication.AnonymousAuthentication = true;
        string[] pointsForConfigType = AuthenticationHelper.getEndPointsForConfigType(appConfig.ConfigType);
        if (pointsForConfigType == null || pointsForConfigType.Length == 0)
            return;
        AuthenticationHelper.updateAuthorizationOnLoginPages(appConfig, pointsForConfigType, false);
    }

    public static void DisableWindowsAuthentication(ApplicationConfiguration appConfig)
    {
        Application iisApplication = AuthenticationHelper.getIisApplication(appConfig.Name);
        iisApplication.WindowsAuthentication = false;
        iisApplication.AnonymousAuthentication = true;
        string[] pointsForConfigType = AuthenticationHelper.getEndPointsForConfigType(appConfig.ConfigType);
        if (pointsForConfigType == null || pointsForConfigType.Length == 0)
            return;
        AuthenticationHelper.updateAuthorizationOnLoginPages(appConfig, pointsForConfigType, true);
    }

    public static void SetAuthorizationToDeny(ApplicationConfiguration appConfig, XmlDocument doc)
    {
        Application iisApplication = AuthenticationHelper.getIisApplication(appConfig.Name);
        iisApplication.WindowsAuthentication = false;
        iisApplication.AnonymousAuthentication = true;
        if (doc == null)
            return;
        XmlNode node = AuthenticationHelper.getOrCreateNode(AuthenticationHelper.getOrCreateNode((XmlNode)doc.DocumentElement, "system.web", 2), "authorization", 3);
        node.RemoveAll();
        AuthenticationHelper.getOrCreateNode(node, "deny", 4, attrName: "users", attrValue: "?");
    }

    private static string[] getEndPointsForConfigType(ConfigurationType type)
    {
        string[] pointsForConfigType = (string[])null;
        switch (type)
        {
            case ConfigurationType.ApplicationServer:
                pointsForConfigType = AuthenticationHelper._appSrvEndPoints;
                break;
            case ConfigurationType.WebServer:
                pointsForConfigType = AuthenticationHelper._webSrvloginPages;
                break;
        }
        return pointsForConfigType;
    }

    private static void updateAuthorizationOnLoginPages(
      ApplicationConfiguration config,
      string[] pageList,
      bool allowAnonymous)
    {
        XmlDocument xmlDocument = new XmlDocument();
        string webConfigPath = config.WebConfigPath;
        using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
        {
            XmlResolver = (XmlResolver)null
        }))
            xmlDocument.Load(reader);
        foreach (string page in pageList)
        {
            AuthenticationHelper.updateAnonymousSystemWebServer(xmlDocument, page, allowAnonymous);
            AuthenticationHelper.updateAnonymousSystemWeb(xmlDocument, page, allowAnonymous, config.ConfigType);
        }
        XmlEditor.XmlDocumentSaveWithFormatting(xmlDocument, config.WebConfigPath);
    }

    private static void updateAnonymousSystemWebServer(
      XmlDocument webCfg,
      string path,
      bool allowAnonymous)
    {
        XmlNode node1 = AuthenticationHelper.getOrCreateNode(AuthenticationHelper.getOrCreateNode(AuthenticationHelper.getOrCreateNode(AuthenticationHelper.getOrCreateNode((XmlNode)webCfg.DocumentElement, "location", 1, attrName: nameof(path), attrValue: path), "system.webServer", 2), "security", 3), "authorization", 4);
        string attrValue1 = allowAnonymous ? "Deny" : "Allow";
        string attrValue2 = allowAnonymous ? "Allow" : "Deny";
        XmlNode node2 = AuthenticationHelper.getOrCreateNode(node1, "add", createIfNotFound: false, attrName: "accessType", attrValue: attrValue1, attrName2: "users", attrValue2: "?");
        if (node2 != null)
            node2.Attributes["accessType"].Value = attrValue2;
        else
            AuthenticationHelper.getOrCreateNode(node1, "add", 5, attrName: "accessType", attrValue: attrValue2, attrName2: "users", attrValue2: "?");
    }

    private static void updateAnonymousSystemWeb(
      XmlDocument webCfg,
      string path,
      bool allowAnonymous,
      ConfigurationType configType)
    {
        XmlNode node1 = AuthenticationHelper.getOrCreateNode(AuthenticationHelper.getOrCreateNode((XmlNode)webCfg.DocumentElement, "location", 1, attrName: nameof(path), attrValue: path), "system.web", 2);
        XmlNode node2 = AuthenticationHelper.getOrCreateNode(node1, "authorization", 3);
        node2.RemoveAll();
        if (allowAnonymous)
            AuthenticationHelper.getOrCreateNode(node2, "allow", 4, attrName: "users", attrValue: "?");
        else
            AuthenticationHelper.getOrCreateNode(node2, "deny", 4, attrName: "users", attrValue: "?");
        if (configType == ConfigurationType.ApplicationServer)
            return;
        AuthenticationHelper.getOrCreateNode(node1, "identity", 3, attrName: "impersonate", attrValue: "true");
    }

    private static XmlNode getOrCreateNode(
      XmlNode parentNode,
      string name,
      int indentCount = 0,
      bool createIfNotFound = true,
      string attrName = null,
      string attrValue = null,
      string attrName2 = null,
      string attrValue2 = null)
    {
        if (parentNode == null || parentNode.OwnerDocument == null)
            return (XmlNode)null;
        string xpath;
        if (string.IsNullOrEmpty(attrName))
            xpath = name;
        else if (string.IsNullOrEmpty(attrName2))
            xpath = $"{name}[@{attrName}='{attrValue}']";
        else
            xpath = $"{name}[@{attrName}='{attrValue}'][@{attrName2}='{attrValue2}']";
        XmlNode node = parentNode.SelectSingleNode(xpath);
        if (node == null & createIfNotFound)
        {
            node = (XmlNode)parentNode.OwnerDocument.CreateElement(name);
            parentNode.AppendChild(node);
            AuthenticationHelper.addAttribute(node, attrName, attrValue);
            AuthenticationHelper.addAttribute(node, attrName2, attrValue2);
        }
        return node;
    }

    private static void addAttribute(XmlNode node, string attrName, string attrValue)
    {
        if (string.IsNullOrEmpty(attrName))
            return;
        XmlAttribute attribute = node.OwnerDocument.CreateAttribute(attrName);
        attribute.Value = attrValue;
        node.Attributes.Append(attribute);
    }

    private static Application getIisApplication(string virtualFolder)
    {
        Application iisApplication = (Application)null;
        AuthenticationHelper.serverManager = new ServerManager();
        foreach (Site site in (IEnumerable)AuthenticationHelper.serverManager.Sites)
        {
            foreach (Application application in (IEnumerable)site.Applications)
            {
                foreach (VirtualDirectory virtualDirectory in (IEnumerable)application.VirtualDirectories)
                {
                    string name = virtualDirectory.Name;
                    if (string.IsNullOrEmpty(name))
                        name = application.Name;
                    if (string.Compare(name, virtualFolder, StringComparison.CurrentCultureIgnoreCase) == 0)
                    {
                        iisApplication = application;
                        break;
                    }
                }
            }
        }
        return iisApplication;
    }

    private delegate void UpdateAuthorizationOnLocationDelegate(XmlDocument webCfg, string path);
}
