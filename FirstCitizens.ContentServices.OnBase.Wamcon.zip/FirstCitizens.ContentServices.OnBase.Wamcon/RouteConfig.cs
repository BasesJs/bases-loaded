﻿using FirstCitizens.ContentServices.OnBase.Wamcon.Logging;
using System.Collections.Generic;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public class RouteConfig
{
  public RouteTypeProperties RouteProperties;
  public List<RouteOption> RouteKeyList;

  public RouteConfig()
  {
    this.RouteProperties = new RouteTypeProperties();
    this.RouteKeyList = new List<RouteOption>();
  }
}
