﻿
//using System.Globalization;
//using System.Threading;

//#nullable disable
//namespace FirstCitizens.ContentServices.OnBase.Wamcon;

//public static class Localize
//{
//  private static object[] obj = new object[1]{ (object) "" };
//  private static Thread currentThread = Thread.CurrentThread;
//  private static CultureInfo cultureInfo;

//  public static string GetString(string resourceString)
//  {
//    if (Localize.currentThread.CurrentUICulture != Localize.currentThread.CurrentCulture)
//      Localize.currentThread.CurrentUICulture = Localize.currentThread.CurrentCulture;
//    Localize.cultureInfo = new CultureInfo(Localize.currentThread.CurrentCulture.LCID);
//    return Strings.GetString(resourceString, Localize.obj);
//  }

//  public static string GetString(string resourceString, object obj)
//  {
//    if (Localize.currentThread.CurrentUICulture != Localize.currentThread.CurrentCulture)
//      Localize.currentThread.CurrentUICulture = Localize.currentThread.CurrentCulture;
//    Localize.cultureInfo = new CultureInfo(Localize.currentThread.CurrentCulture.LCID);
//    return Strings.GetString(resourceString, obj);
//  }
//}
