﻿using System;
using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationCollection(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject),
  IEnumerable
{
  protected override string TypeName => "Microsoft.Web.Administration.ApplicationCollection";

  public void Remove(Application app)
  {
    this.InvokeMethod(nameof (Remove), new object[1]
    {
      app.LateBoundObject
    }, true);
  }

  public void Add(string name)
  {
    this.InvokeMethod(nameof (Add), new object[1]
    {
      (object) name
    }, true);
  }

  public void Add(string name, string path)
  {
    this.InvokeMethod(nameof (Add), new object[2]
    {
      (object) name,
      (object) path
    }, true);
  }

  public IEnumerator GetEnumerator()
  {
    return (IEnumerator) new ApplicationEnumerator(this._serverManager, this._lateBoundObject);
  }

  public Application this[string key]
  {
    get
    {
      return new Application(this._serverManager, this.GetProperty<object>(nameof (Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) key }));
    }
    set
    {
      this.SetProperty(nameof (Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) key }, (object) value);
    }
  }
}
