﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class Application(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.Application";

  public VirtualDirectoryCollection VirtualDirectories
  {
    get
    {
      return new VirtualDirectoryCollection(this._serverManager, this.GetProperty<object>(nameof (VirtualDirectories)));
    }
  }

  public string Path => this.GetProperty<string>(nameof (Path));

  public string ApplicationPoolName
  {
    get => this.GetProperty<string>(nameof (ApplicationPoolName));
    set => this.SetProperty(nameof (ApplicationPoolName), (object) value);
  }

  public Configuration GetWebConfiguration()
  {
    return new Configuration(this._serverManager, this.InvokeMethod(nameof (GetWebConfiguration)));
  }
}
