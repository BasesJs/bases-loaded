﻿using System;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPoolProcessModel(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.ApplicationPoolProcessModel";

  public TimeSpan IdleTimeout
  {
    get => this.GetProperty<TimeSpan>(nameof (IdleTimeout));
    set => this.SetProperty(nameof (IdleTimeout), (object) value);
  }

  public bool PingingEnabled
  {
    get => this.GetProperty<bool>(nameof (PingingEnabled));
    set => this.SetProperty(nameof (PingingEnabled), (object) value);
  }
}
