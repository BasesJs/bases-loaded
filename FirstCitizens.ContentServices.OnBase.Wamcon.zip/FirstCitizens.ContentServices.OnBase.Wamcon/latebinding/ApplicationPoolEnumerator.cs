﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPoolEnumerator : IEnumerator
{
  private ServerManager _serverManager = (ServerManager) null;
  private object _appPoolCollectionObject = (object) null;
  private IEnumerator _enumerator;

  public ApplicationPoolEnumerator(ServerManager serverManager, object appPoolCollectionObject)
  {
    this._serverManager = serverManager;
    this._appPoolCollectionObject = appPoolCollectionObject;
    this._enumerator = ((IEnumerable) this._appPoolCollectionObject).GetEnumerator();
  }

  public object Current
  {
    get => (object) new ApplicationPool(this._serverManager, this._enumerator.Current);
  }

  public bool MoveNext() => this._enumerator.MoveNext();

  public void Reset() => this._enumerator.Reset();
}
