﻿using System;
using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class BindingCollection(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject),
  IEnumerable
{
  protected override string TypeName => "Microsoft.Web.Administration.BindingCollection";

  public void Remove(Binding binding)
  {
    this.InvokeMethod(nameof (Remove), new object[1]
    {
      binding.LateBoundObject
    }, true);
  }

  public void Add(string name)
  {
    this.InvokeMethod(nameof (Add), new object[1]
    {
      (object) name
    }, true);
  }

  public void Add(string name, string path)
  {
    this.InvokeMethod(nameof (Add), new object[2]
    {
      (object) name,
      (object) path
    }, true);
  }

  public IEnumerator GetEnumerator()
  {
    return (IEnumerator) new BindingEnumerator(this._serverManager, this._lateBoundObject);
  }

  public Binding this[int index]
  {
    get
    {
      return new Binding(this._serverManager, this.GetProperty<object>(nameof(Item), new Type[1]
      {
        typeof (int)
      }, new object[1]{ (object) index }));
    }
    set
    {
      this.SetProperty(nameof(Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) index }, (object) value);
    }
  }
}
