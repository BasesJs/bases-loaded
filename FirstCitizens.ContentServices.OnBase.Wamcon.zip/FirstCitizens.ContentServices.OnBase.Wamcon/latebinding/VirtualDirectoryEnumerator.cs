﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class VirtualDirectoryEnumerator : IEnumerator
{
  private ServerManager _serverManager = (ServerManager) null;
  private object _virtDirCollectionObject = (object) null;
  private IEnumerator _enumerator = (IEnumerator) null;

  public VirtualDirectoryEnumerator(ServerManager serverManager, object virtDirCollectionObject)
  {
    this._serverManager = serverManager;
    this._virtDirCollectionObject = virtDirCollectionObject;
    this._enumerator = ((IEnumerable) this._virtDirCollectionObject).GetEnumerator();
  }

  public object Current
  {
    get => (object) new VirtualDirectory(this._serverManager, this._enumerator.Current);
  }

  public bool MoveNext() => this._enumerator.MoveNext();

  public void Reset() => this._enumerator.Reset();
}
