﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPool(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.ApplicationPool";

  public ApplicationPoolProcessModel ProcessModel
  {
    get
    {
      return new ApplicationPoolProcessModel(this._serverManager, this.GetProperty<object>(nameof (ProcessModel)));
    }
  }

  public ApplicationPoolRecycling Recycling
  {
    get
    {
      return new ApplicationPoolRecycling(this._serverManager, this.GetProperty<object>(nameof (Recycling)));
    }
  }

  public ApplicationPoolFailure Failure
  {
    get
    {
      return new ApplicationPoolFailure(this._serverManager, this.GetProperty<object>(nameof (Failure)));
    }
  }

  public bool Enable32BitAppOnWin64
  {
    get => this.GetProperty<bool>(nameof (Enable32BitAppOnWin64));
    set => this.SetProperty(nameof (Enable32BitAppOnWin64), (object) value);
  }

  public long QueueLength
  {
    get => this.GetProperty<long>(nameof (QueueLength));
    set => this.SetProperty(nameof (QueueLength), (object) value);
  }

  public bool PingingEnabled
  {
    get => this.GetProperty<bool>(nameof (PingingEnabled));
    set => this.SetProperty(nameof (PingingEnabled), (object) value);
  }

  public bool RapidFailProtection
  {
    get => this.GetProperty<bool>(nameof (RapidFailProtection));
    set => this.SetProperty(nameof (RapidFailProtection), (object) value);
  }

  public string Name
  {
    get => this.GetProperty<string>(nameof (Name));
    set => this.SetProperty(nameof (Name), (object) value);
  }
}
