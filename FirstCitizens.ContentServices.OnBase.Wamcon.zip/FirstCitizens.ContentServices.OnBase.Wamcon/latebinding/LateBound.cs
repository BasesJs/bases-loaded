﻿using System;
using System.Globalization;
using System.Reflection;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class LateBound
{
  protected ServerManager _serverManager = (ServerManager) null;
  protected Assembly _microsoftAssembly = (Assembly) null;
  protected object _lateBoundObject = (object) null;
  protected Type _lateBoundType = (Type) null;

  public LateBound()
  {
  }

  public LateBound(ServerManager serverManager, object lateBoundObject)
  {
    this._serverManager = serverManager;
    this._microsoftAssembly = serverManager.MicrosoftAssembly;
    this._lateBoundObject = lateBoundObject;
    this.LoadType();
  }

  public object LateBoundObject => this._lateBoundObject;

  private void LoadType() => this._lateBoundType = this._microsoftAssembly.GetType(this.TypeName);

  protected virtual string TypeName
  {
    get => throw new NotImplementedException("TypeName must be implemented.");
  }

  protected T GetProperty<T>(string name)
  {
    return this.GetProperty<T>(name, new Type[0], (object[]) null, BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetField | BindingFlags.GetProperty);
  }

  protected T GetProperty<T>(string name, BindingFlags bindingFlags)
  {
    return this.GetProperty<T>(name, new Type[0], (object[]) null, bindingFlags);
  }

  protected T GetProperty<T>(string name, Type[] indexedTypes, object[] indexers)
  {
    return this.GetProperty<T>(name, indexedTypes, indexers, BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetField | BindingFlags.GetProperty);
  }

  protected T GetProperty<T>(
    string name,
    Type[] indexedTypes,
    object[] indexers,
    BindingFlags bindingFlags)
  {
    return (T) this._lateBoundType.GetProperty(name, indexedTypes).GetValue(this._lateBoundObject, bindingFlags, (Binder) null, indexers, CultureInfo.CurrentCulture);
  }

  protected void SetProperty(string name, object value)
  {
    this.SetProperty(name, new Type[0], (object[]) null, value);
  }

  protected void SetProperty(string name, Type[] indexedTypes, object[] indexers, object value)
  {
    this._lateBoundType.GetProperty(name, indexedTypes).SetValue(this._lateBoundObject, value, BindingFlags.Public | BindingFlags.GetField | BindingFlags.GetProperty, (Binder) null, indexers, CultureInfo.CurrentCulture);
    this._serverManager.CommitChanges();
  }

  protected object InvokeStaticMethod(string methodName)
  {
    return this.InvokeStaticMethod(methodName, new object[0]);
  }

  protected object InvokeStaticMethod(string methodName, object[] parameters)
  {
    return this._lateBoundType.InvokeMember(methodName, BindingFlags.Static | BindingFlags.Public | BindingFlags.InvokeMethod, (Binder) null, (object) null, parameters);
  }

  protected object InvokeMethod(string methodName)
  {
    return this.InvokeMethod(methodName, new object[0], false);
  }

  protected object InvokeMethod(string methodName, object[] parameters)
  {
    return this.InvokeMethod(methodName, parameters, false);
  }

  protected object InvokeMethod(string methodName, object[] parameters, bool commit)
  {
    return this.InvokeMethod(methodName, parameters, BindingFlags.Instance | BindingFlags.Public | BindingFlags.InvokeMethod, commit);
  }

  protected object InvokeMethod(
    string methodName,
    object[] parameters,
    BindingFlags bindingFlags,
    bool commit)
  {
    object obj = this._lateBoundType.InvokeMember(methodName, bindingFlags, (Binder) null, this._lateBoundObject, parameters);
    if (commit)
      this._serverManager.CommitChanges();
    return obj;
  }
}
