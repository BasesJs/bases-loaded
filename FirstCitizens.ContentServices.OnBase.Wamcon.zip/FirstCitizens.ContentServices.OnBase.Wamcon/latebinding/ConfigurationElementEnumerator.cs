﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ConfigurationElementEnumerator : IEnumerator
{
  private ServerManager _serverManager = (ServerManager) null;
  private object _elementCollectionObject = (object) null;
  private IEnumerator _enumerator = (IEnumerator) null;

  public ConfigurationElementEnumerator(ServerManager serverManager, object elementCollectionObject)
  {
    this._serverManager = serverManager;
    this._elementCollectionObject = elementCollectionObject;
    this._enumerator = ((IEnumerable) this._elementCollectionObject).GetEnumerator();
  }

  public object Current
  {
    get => (object) new ConfigurationElement(this._serverManager, this._enumerator.Current);
  }

  public bool MoveNext() => this._enumerator.MoveNext();

  public void Reset() => this._enumerator.Reset();
}
