﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ConfigurationElementCollection(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject),
  IEnumerable
{
  protected override string TypeName
  {
    get => "Microsoft.Web.Administration.ConfigurationElementCollection";
  }

  public bool AllowsAdd
  {
    get => this.GetProperty<bool>(nameof (AllowsAdd));
    set => this.SetProperty(nameof (AllowsAdd), (object) value);
  }

  public void Add(ConfigurationElement element)
  {
    this.InvokeMethod(nameof (Add), new object[1]
    {
      (object) element
    }, true);
  }

  public void Clear() => this.InvokeMethod(nameof (Clear), new object[0], true);

  public IEnumerator GetEnumerator()
  {
    return (IEnumerator) new ConfigurationElementEnumerator(this._serverManager, this._lateBoundObject);
  }

  public ConfigurationElement CreateElement()
  {
    return new ConfigurationElement(this._serverManager, this.InvokeMethod(nameof (CreateElement)));
  }

  public ConfigurationElement CreateElement(string name)
  {
    return new ConfigurationElement(this._serverManager, this.InvokeMethod(nameof (CreateElement), new object[1]
    {
      (object) name
    }));
  }
}
