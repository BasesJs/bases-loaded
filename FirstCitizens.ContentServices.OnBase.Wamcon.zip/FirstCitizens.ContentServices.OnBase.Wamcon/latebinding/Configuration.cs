﻿using System.Reflection;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class Configuration(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.Configuration";

  public ConfigurationSection GetSection(string sectionPath)
  {
    return new ConfigurationSection(this._serverManager, this._lateBoundType.InvokeMember(nameof (GetSection), BindingFlags.Instance | BindingFlags.Public | BindingFlags.InvokeMethod, (Binder) null, this._lateBoundObject, new object[1]
    {
      (object) sectionPath
    }));
  }

  public ConfigurationSection GetSection(string sectionPath, string locationPath)
  {
    return new ConfigurationSection(this._serverManager, this._lateBoundType.InvokeMember(nameof (GetSection), BindingFlags.Instance | BindingFlags.Public | BindingFlags.InvokeMethod, (Binder) null, this._lateBoundObject, new object[2]
    {
      (object) sectionPath,
      (object) locationPath
    }));
  }
}
