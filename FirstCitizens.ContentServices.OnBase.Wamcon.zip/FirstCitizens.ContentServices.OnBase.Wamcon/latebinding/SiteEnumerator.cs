﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class SiteEnumerator : IEnumerator
{
  private ServerManager _serverManager = (ServerManager) null;
  private object _siteCollectionObject = (object) null;
  private IEnumerator _enumerator = (IEnumerator) null;

  public SiteEnumerator(ServerManager serverManager, object siteCollectionObject)
  {
    this._serverManager = serverManager;
    this._siteCollectionObject = siteCollectionObject;
    this._enumerator = ((IEnumerable) this._siteCollectionObject).GetEnumerator();
  }

  public object Current => (object) new Site(this._serverManager, this._enumerator.Current);

  public bool MoveNext() => this._enumerator.MoveNext();

  public void Reset() => this._enumerator.Reset();
}
