﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPoolFailure(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.ApplicationPoolFailure";

  public bool RapidFailProtection
  {
    get => this.GetProperty<bool>(nameof (RapidFailProtection));
    set => this.SetProperty(nameof (RapidFailProtection), (object) value);
  }
}
