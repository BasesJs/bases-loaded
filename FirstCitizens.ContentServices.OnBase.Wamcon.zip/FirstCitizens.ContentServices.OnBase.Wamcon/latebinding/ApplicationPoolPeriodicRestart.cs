﻿using System;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPoolPeriodicRestart(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName
  {
    get => "Microsoft.Web.Administration.ApplicationPoolPeriodicRestart";
  }

  public TimeSpan Time
  {
    get => this.GetProperty<TimeSpan>(nameof (Time));
    set => this.SetProperty(nameof (Time), (object) value);
  }
}
