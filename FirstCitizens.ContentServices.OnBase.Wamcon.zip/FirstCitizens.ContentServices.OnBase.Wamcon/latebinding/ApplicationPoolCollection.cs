﻿using System;
using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPoolCollection(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject),
  IEnumerable
{
  protected override string TypeName => "Microsoft.Web.Administration.ApplicationPoolCollection";

  public void Remove(ApplicationPool appPool)
  {
    this.InvokeMethod(nameof (Remove), new object[1]
    {
      appPool.LateBoundObject
    }, true);
  }

  public void Add(string name)
  {
    this.InvokeMethod(nameof (Add), new object[1]
    {
      (object) name
    }, true);
  }

  public IEnumerator GetEnumerator()
  {
    return (IEnumerator) new ApplicationPoolEnumerator(this._serverManager, this._lateBoundObject);
  }

  public ApplicationPool this[string key]
  {
    get
    {
      return new ApplicationPool(this._serverManager, this.GetProperty<object>(nameof (Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) key }));
    }
    set
    {
      this.SetProperty(nameof (Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) key }, (object) value);
    }
  }
}
