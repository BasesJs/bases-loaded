﻿using System;
using System.Collections;
using System.Reflection;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class VirtualDirectoryCollection(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject),
  IEnumerable
{
  protected override string TypeName => "Microsoft.Web.Administration.VirtualDirectoryCollection";

  public void Remove(VirtualDirectory virtDir)
  {
    this.InvokeMethod(nameof (Remove), new object[1]
    {
      virtDir.LateBoundObject
    }, true);
  }

  public void Add(string name, string path)
  {
    foreach (MethodInfo method in this._lateBoundType.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public))
    {
      if (method.Name == nameof (Add))
      {
        method.Invoke(this._lateBoundObject, new object[2]
        {
          (object) name,
          (object) path
        });
        break;
      }
    }
    this._serverManager.CommitChanges();
  }

  public VirtualDirectory this[string key]
  {
    get
    {
      return new VirtualDirectory(this._serverManager, this.GetProperty<object>(nameof (Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) key }));
    }
    set
    {
      this.SetProperty(nameof (Item), new Type[1]
      {
        typeof (string)
      }, new object[1]{ (object) key }, (object) value);
    }
  }

  public IEnumerator GetEnumerator()
  {
    return (IEnumerator) new VirtualDirectoryEnumerator(this._serverManager, this._lateBoundObject);
  }
}
