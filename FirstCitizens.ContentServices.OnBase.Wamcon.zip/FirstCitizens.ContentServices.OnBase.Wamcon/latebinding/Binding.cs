﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class Binding(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.Binding";

  public string BindingInformation
  {
    get => this.GetProperty<string>(nameof (BindingInformation));
    set => this.SetProperty(nameof (BindingInformation), (object) value);
  }
}
