﻿using System.Globalization;
using System.Reflection;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ConfigurationElement(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.ConfigurationElement";

  public object this[string key]
  {
    get
    {
      return this._lateBoundType.GetProperty("this").GetValue(this._lateBoundObject, BindingFlags.NonPublic | BindingFlags.GetField | BindingFlags.GetProperty, (Binder) null, new object[1]
      {
        (object) key
      }, CultureInfo.CurrentCulture);
    }
    set
    {
      this._lateBoundType.GetProperty("this").SetValue(this._lateBoundObject, value, new object[1]
      {
        (object) key
      });
    }
  }

  public string ElementTagName
  {
    get => this.GetProperty<string>(nameof (ElementTagName));
    set => this.SetProperty(nameof (ElementTagName), (object) value);
  }
}
