﻿using System.Collections;


namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationEnumerator : IEnumerator
{
  private ServerManager _serverManager = (ServerManager) null;
  private object _appCollectionObject = (object) null;
  private IEnumerator _enumerator;

  public ApplicationEnumerator(ServerManager serverManager, object appCollectionObject)
  {
    this._serverManager = serverManager;
    this._appCollectionObject = appCollectionObject;
    this._enumerator = ((IEnumerable) this._appCollectionObject).GetEnumerator();
  }

  public object Current => (object) new Application(this._serverManager, this._enumerator.Current);

  public bool MoveNext() => this._enumerator.MoveNext();

  public void Reset() => this._enumerator.Reset();
}
