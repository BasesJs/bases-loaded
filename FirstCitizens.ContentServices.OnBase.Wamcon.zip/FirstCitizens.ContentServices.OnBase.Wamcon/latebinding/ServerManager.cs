﻿using System;
using System.Reflection;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ServerManager : LateBound, IDisposable
{
  private string _serverName = string.Empty;

  public ServerManager()
    : this("localhost")
  {
  }

  public ServerManager(string serverName)
  {
    this._serverName = serverName;
    this.LoadMicrosoftAssembly();
    this.LoadMicrosoftObjects();
  }

  protected override string TypeName => "Microsoft.Web.Administration.ServerManager";

  public Assembly MicrosoftAssembly => this._microsoftAssembly;

  public ApplicationPoolCollection ApplicationPools
  {
    get => new ApplicationPoolCollection(this, this.GetProperty<object>(nameof (ApplicationPools)));
  }

  public SiteCollection Sites => new SiteCollection(this, this.GetProperty<object>(nameof (Sites)));

  public Configuration GetApplicationHostConfiguration()
  {
    return new Configuration(this, this.InvokeMethod(nameof (GetApplicationHostConfiguration)));
  }

  public Configuration GetWebConfiguration(string siteName)
  {
    return new Configuration(this, this.InvokeMethod(nameof (GetWebConfiguration), new object[1]
    {
      (object) siteName
    }));
  }

  public void CommitChanges() => this.InvokeMethod(nameof (CommitChanges));

  private void LoadMicrosoftAssembly()
  {
    this._microsoftAssembly = Assembly.Load("Microsoft.Web.Administration, Version=7.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
  }

  private void LoadMicrosoftObjects()
  {
    this._lateBoundType = this._microsoftAssembly.GetType("Microsoft.Web.Administration.ServerManager");
    if (this._serverName.Equals("localhost", StringComparison.CurrentCultureIgnoreCase))
      this._lateBoundObject = this._lateBoundType.InvokeMember(string.Empty, BindingFlags.CreateInstance, (Binder) null, (object) null, new object[0]);
    else
      this._lateBoundObject = this.OpenRemote(this._serverName);
  }

  private object OpenRemote(string serverName)
  {
    return this.InvokeStaticMethod(nameof (OpenRemote), new object[1]
    {
      (object) serverName
    });
  }

  public void Dispose()
  {
    if (!(this._lateBoundObject is IDisposable lateBoundObject))
      return;
    lateBoundObject.Dispose();
  }
}
