﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class VirtualDirectory(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.VirtualDirectory";

  public string PhysicalPath
  {
    get => this.GetProperty<string>(nameof (PhysicalPath));
    set => this.SetProperty(nameof (PhysicalPath), (object) value);
  }

  public string Path
  {
    get => this.GetProperty<string>(nameof (Path));
    set => this.SetProperty(nameof (Path), (object) value);
  }
}
