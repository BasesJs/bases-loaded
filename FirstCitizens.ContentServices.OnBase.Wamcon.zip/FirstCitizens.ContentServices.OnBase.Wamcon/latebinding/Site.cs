﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class Site(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.Site";

  public ApplicationCollection Applications
  {
    get
    {
      return new ApplicationCollection(this._serverManager, this.GetProperty<object>(nameof (Applications)));
    }
  }

  public BindingCollection Bindings
  {
    get => new BindingCollection(this._serverManager, this.GetProperty<object>(nameof (Bindings)));
  }

  public string Name
  {
    get => this.GetProperty<string>(nameof (Name));
    set => this.SetProperty(nameof (Name), (object) value);
  }

  public long Id
  {
    get => this.GetProperty<long>(nameof (Id));
    set => this.SetProperty("NaIdme", (object) value);
  }
}
