﻿using System.Globalization;
using System.Reflection;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ConfigurationSection(ServerManager serverManager, object lateBoundObject) : LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.ConfigurationSection";

  public ConfigurationElement GetChildElement(string elementName)
  {
    return new ConfigurationElement(this._serverManager, this.InvokeMethod(nameof (GetChildElement), new object[1]
    {
      (object) elementName
    }));
  }

  public ConfigurationElementCollection GetCollection()
  {
    return new ConfigurationElementCollection(this._serverManager, this.InvokeMethod(nameof (GetCollection)));
  }

  public ConfigurationElementCollection GetCollection(string collectionName)
  {
    return new ConfigurationElementCollection(this._serverManager, this.InvokeMethod(nameof (GetCollection), new object[1]
    {
      (object) collectionName
    }));
  }

  public object this[string key]
  {
    get
    {
      return this._lateBoundType.GetProperty(nameof (Item)).GetValue(this._lateBoundObject, BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetProperty, (Binder) null, new object[1]
      {
        (object) key
      }, CultureInfo.CurrentCulture);
    }
    set
    {
      this._lateBoundType.GetProperty(nameof (Item)).SetValue(this._lateBoundObject, value, new object[1]
      {
        (object) key
      });
    }
  }
}
