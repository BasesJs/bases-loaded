﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class BindingEnumerator : IEnumerator
{
  private ServerManager _serverManager = (ServerManager) null;
  private object _bindingCollectionObject = (object) null;
  private IEnumerator _enumerator;

  public BindingEnumerator(ServerManager serverManager, object bindingCollectionObject)
  {
    this._serverManager = serverManager;
    this._bindingCollectionObject = bindingCollectionObject;
    this._enumerator = ((IEnumerable) this._bindingCollectionObject).GetEnumerator();
  }

  public object Current => (object) new Binding(this._serverManager, this._enumerator.Current);

  public bool MoveNext() => this._enumerator.MoveNext();

  public void Reset() => this._enumerator.Reset();
}
