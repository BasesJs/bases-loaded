﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding;

internal class ApplicationPoolRecycling(ServerManager serverManager, object lateBoundObject) : 
  LateBound(serverManager, lateBoundObject)
{
  protected override string TypeName => "Microsoft.Web.Administration.ApplicationPoolRecycling";

  public ApplicationPoolPeriodicRestart PeriodicRestart
  {
    get
    {
      return new ApplicationPoolPeriodicRestart(this._serverManager, this.GetProperty<object>(nameof (PeriodicRestart)));
    }
    set => this.SetProperty(nameof (PeriodicRestart), value.LateBoundObject);
  }
}
