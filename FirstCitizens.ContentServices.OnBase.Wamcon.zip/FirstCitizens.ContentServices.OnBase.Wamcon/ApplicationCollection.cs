﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class ApplicationCollection : CollectionBase<Application>
{
  private string _siteName;
  private long _siteId;

  internal ApplicationCollection(ServerManager serverManager, string siteName, long siteId)
    : base(serverManager)
  {
    this._siteName = siteName;
    this._siteId = siteId;
  }
}
