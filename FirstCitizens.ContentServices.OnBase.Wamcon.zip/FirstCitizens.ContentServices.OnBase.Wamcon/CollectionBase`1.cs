﻿using System.Collections;
using System.Collections.Generic;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public abstract class CollectionBase<T> : IEnumerable
{
  private List<T> _list = new List<T>();
  private ServerManager _serverManager;

  internal CollectionBase(ServerManager serverManager) => this._serverManager = serverManager;

  internal ServerManager ServerManager => this._serverManager;

  internal virtual void Add(T value) => this._list.Add(value);

  public T this[int i] => this._list[i];

  public int Count => this._list.Count;

  IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this._list.GetEnumerator();
}
