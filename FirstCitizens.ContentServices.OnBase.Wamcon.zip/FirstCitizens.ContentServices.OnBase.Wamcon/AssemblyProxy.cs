﻿// Decompiled with JetBrains decompiler
// Type: FirstCitizens.ContentServices.OnBase.Wamcon.AssemblyProxy
// Assembly: WebApplicationManagementConsole, Version=25.1.2.1000, Culture=neutral, PublicKeyToken=null
// MVID: E12C454C-A807-4890-B0D3-E1DEC2961811
// Assembly location: C:\Users\jacob\OpenCloud\Code\Web Applications Management Console\WebApplicationManagementConsole.exe

using System;
using System.IO;
using System.Reflection;

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public class AssemblyProxy : IDisposable
{
  private readonly string _assemblyFullName;
  private readonly Stream _xsdStream;
  private MemoryStream _stream;
  public static readonly string WEB_SERVER_ASSEMBLY_NAME = "Hyland.Applications.Web.Client";
  public static readonly string WEB_SERVER_SCHEMA_FILE = "Hyland.Applications.Web.Client.Schema.WebConfigSchema.xsd";
  public static readonly string APPLICATION_SERVER_ASSEMBLY_NAME = "Hyland.Applications.Server";
  public static readonly string APPLICATION_SERVER_SCHEMA_FILE = "Hyland.Applications.Server.Schema.WebConfigSchema.xsd";
  public static readonly string AGENDA_ASSEMBLY_NAME = "Hyland.Applications.AgendaPubAccess.Client";
  public static readonly string AGENDA_SCHEMA_FILE = "Hyland.Applications.AgendaPubAccess.Client.Schema.WebConfigSchema.xsd";
  public static readonly string PUBLIC_ACCESS_ASSEMBLY_NAME = "Hyland.Web.PublicAccess.Server";
  public static readonly string PUBLIC_ACCESS_SCHEMA_FILE = "Hyland.Web.PublicAccess.Server.Schema.WebConfigSchema.xsd";
  public static readonly string PUBLIC_ACCESS_LEGACY_ASSEMBLY_NAME = "Hyland.Web.PublicAccess";
  public static readonly string PUBLIC_ACCESS_LEGACY_SCHEMA_FILE = "Hyland.Web.PublicAccess.Schema.WebConfigSchema.xsd";
  public static readonly string DASHBOARD_ASSEMBLY_NAME = "Hyland.Applications.Web.DashboardViewer";
  public static readonly string DASHBOARD_SCHEMA_FILE = "Hyland.Applications.Web.DashboardViewer.Schema.WebConfigSchema.xsd";
  public static readonly string PLAN_REVIEW_ASSEMBLY_NAME = "Hyland.Applications.PlanReview.Client";
  public static readonly string PLAN_REVIEW_SCHEMA_FILE = "Hyland.Applications.PlanReview.Client.Schema.WebConfigSchema.xsd";
  public static readonly string MOBILE_ASSEMBLY_NAME = "Hyland.Mobile.WCF.Service";
  public static readonly string MOBILE_SCHEMA_FILE = "Hyland.Mobile.WCF.Service.Schema.WebConfigSchema.xsd";
  public static readonly string WOPI_ASSEMBLY_NAME = "Hyland.WopiServer";
  public static readonly string WOPI_SCHEMA_FILE = "Hyland.Wopi.Schema.WebConfigSchema.xsd";
  public static readonly string IDP_ASSEMBLY_NAME = "Hyland.IdentityModel.Server";
  public static readonly string IDP_SCHEMA_FILE = "Hyland.IdentityModel.Server.Schema.WebConfigSchema.xsd";
  public static readonly string JACK_HENRY_ASSEMBLY_NAME = "JackHenryServer";
  public static readonly string JACK_HENRY_SCHEMA_FILE = "JackHenryServer.WebConfigSchema.xsd";
  public static readonly string PDS1450_ASSEMBLY_NAME = "PDS1450";
  public static readonly string PDS1450_SCHEMA_FILE = "PDS1450.Schema.WebConfigSchema.xsd";
  public static readonly string WEB_SERVICE_PUBLISHING_ASSEMBLY_NAME = "Hyland.Integrations.WebServicesPublishing";
  public static readonly string WEB_SERVICE_PUBLISHING_SCHEMA_FILE = "Hyland.Integrations.WebServicesPublishing.Schema.WebConfigSchema.xsd";
  public static readonly string DEFICIENCYPOP_ASSEMBLY_NAME = "Hyland.Applications.Web.DeficiencyPop";
  public static readonly string DEFICIENCYPOP_SCHEMA_FILE = "Hyland.Applications.Web.DeficiencyPop.Schema.WebConfigSchema.xsd";
  public static readonly string PATIENTWINDOW_ASSEMBLY_NAME = "Hyland.Applications.Web.PatientWindow";
  public static readonly string PATIENTWINDOW_SCHEMA_FILE = "Hyland.Applications.Web.PatientWindow.Schema.WebConfigSchema.xsd";
  public static readonly string HEALTHCAREFORMMANAGER_ASSEMBLY_NAME = "Hyland.Applications.Web.HealthcareFormManager";
  public static readonly string HEALTHCAREFORMMANAGER_SCHEMA_FILE = "Hyland.Applications.Web.HealthcareFormManager.Schema.WebConfigSchema.xsd";

  public AssemblyProxy(string assemblyFile)
  {
    AppDomain domain = AppDomain.CreateDomain(Guid.NewGuid().ToString(), AppDomain.CurrentDomain.Evidence, AppDomain.CurrentDomain.SetupInformation);
    AssemblyProxy.AssemblyLoader instanceFromAndUnwrap = (AssemblyProxy.AssemblyLoader) domain.CreateInstanceFromAndUnwrap(typeof (AssemblyProxy.AssemblyLoader).Assembly.Location, typeof (AssemblyProxy.AssemblyLoader).FullName);
    instanceFromAndUnwrap.ReflectionOnlyLoadFrom(assemblyFile);
    this._assemblyFullName = instanceFromAndUnwrap.FullName;
    string resourceName = this.GetResourceName();
    using (Stream manifestResourceStream = instanceFromAndUnwrap.GetManifestResourceStream(resourceName))
    {
      this._xsdStream = (Stream) new MemoryStream();
      manifestResourceStream.CopyTo(this._xsdStream);
    }
    AppDomain.Unload(domain);
  }

  public void Dispose()
  {
    this.Dispose(true);
    GC.SuppressFinalize((object) this);
  }

  protected virtual void Dispose(bool disposing)
  {
    if (!disposing)
      return;
    if (this._xsdStream != null)
      this._xsdStream.Dispose();
    if (this._stream != null)
      this._stream.Dispose();
  }

  public Stream GetSchemaStream()
  {
    this._stream = new MemoryStream();
    this._xsdStream.Seek(0L, SeekOrigin.Begin);
    this._xsdStream.CopyTo((Stream) this._stream);
    this._stream.Seek(0L, SeekOrigin.Begin);
    return (Stream) this._stream;
  }

  public string FullName => this._assemblyFullName;

  public bool IsAppServerOrWebServer
  {
    get
    {
      return this._assemblyFullName.Contains(AssemblyProxy.WEB_SERVER_ASSEMBLY_NAME) || this._assemblyFullName.Contains(AssemblyProxy.APPLICATION_SERVER_ASSEMBLY_NAME);
    }
  }

  private string GetResourceName()
  {
    if (this._assemblyFullName.Contains(AssemblyProxy.WEB_SERVER_ASSEMBLY_NAME))
      return AssemblyProxy.WEB_SERVER_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.APPLICATION_SERVER_ASSEMBLY_NAME))
      return AssemblyProxy.APPLICATION_SERVER_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.AGENDA_ASSEMBLY_NAME))
      return AssemblyProxy.AGENDA_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.PUBLIC_ACCESS_ASSEMBLY_NAME))
      return AssemblyProxy.PUBLIC_ACCESS_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.PUBLIC_ACCESS_LEGACY_ASSEMBLY_NAME))
      return AssemblyProxy.PUBLIC_ACCESS_LEGACY_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.DASHBOARD_ASSEMBLY_NAME))
      return AssemblyProxy.DASHBOARD_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.PLAN_REVIEW_ASSEMBLY_NAME))
      return AssemblyProxy.PLAN_REVIEW_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.MOBILE_ASSEMBLY_NAME))
      return AssemblyProxy.MOBILE_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.WOPI_ASSEMBLY_NAME))
      return AssemblyProxy.WOPI_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.IDP_ASSEMBLY_NAME))
      return AssemblyProxy.IDP_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.JACK_HENRY_ASSEMBLY_NAME))
      return AssemblyProxy.JACK_HENRY_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.PDS1450_ASSEMBLY_NAME))
      return AssemblyProxy.PDS1450_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.WEB_SERVICE_PUBLISHING_ASSEMBLY_NAME))
      return AssemblyProxy.WEB_SERVICE_PUBLISHING_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.DEFICIENCYPOP_ASSEMBLY_NAME))
      return AssemblyProxy.DEFICIENCYPOP_SCHEMA_FILE;
    if (this._assemblyFullName.Contains(AssemblyProxy.PATIENTWINDOW_ASSEMBLY_NAME))
      return AssemblyProxy.PATIENTWINDOW_SCHEMA_FILE;
    return this._assemblyFullName.Contains(AssemblyProxy.HEALTHCAREFORMMANAGER_ASSEMBLY_NAME) ? AssemblyProxy.HEALTHCAREFORMMANAGER_SCHEMA_FILE : string.Empty;
  }

  [Serializable]
  private class AssemblyLoader : MarshalByRefObject
  {
    private Assembly _assembly;

    public void ReflectionOnlyLoadFrom(string assemblyFile)
    {
      this._assembly = Assembly.ReflectionOnlyLoadFrom(assemblyFile);
    }

    public Stream GetManifestResourceStream(string resourceName)
    {
      return this._assembly.GetManifestResourceStream(resourceName);
    }

    public string FullName => this._assembly.FullName;
  }
}
