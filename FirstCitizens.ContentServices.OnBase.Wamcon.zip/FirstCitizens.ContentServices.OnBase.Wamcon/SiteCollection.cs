﻿using System.Collections;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class SiteCollection : CollectionBase<Site>
{
  internal SiteCollection(ServerManager serverManager)
    : base(serverManager)
  {
  }

  public Site this[long id]
  {
    get
    {
      Site site1 = (Site) null;
      foreach (Site site2 in (IEnumerable) this)
      {
        if (site2.Id == id)
        {
          site1 = site2;
          break;
        }
      }
      return site1;
    }
  }
}
