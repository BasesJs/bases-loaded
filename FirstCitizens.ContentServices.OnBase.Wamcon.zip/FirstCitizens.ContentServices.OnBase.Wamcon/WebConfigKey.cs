﻿using System;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public class WebConfigKey
{
  public string KeyName { get; set; }

  public string Section { get; set; }

  public string Value { get; set; }

  public WebConfigKey(string name, string section)
  {
    this.KeyName = name;
    this.Section = section;
  }

  public WebConfigKey(string name, string section, string value)
  {
    this.KeyName = name;
    this.Section = section;
    this.Value = value;
  }

  public override int GetHashCode() => base.GetHashCode();

  public override bool Equals(object obj)
  {
    return obj is WebConfigKey webConfigKey ? this.KeyName.Equals(webConfigKey.KeyName, StringComparison.InvariantCultureIgnoreCase) && this.Section.Equals(webConfigKey.Section, StringComparison.InvariantCultureIgnoreCase) : base.Equals(obj);
  }
}
