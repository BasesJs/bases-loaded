﻿using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Reflection;

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public class ApplicationConfiguration
{
  public string AssemblyPath { get; set; }

  public string LocalPath { get; set; }

  public string WebConfigPath { get; set; }

  public string SchemaFilePath { get; set; }

  public string Schema { get; set; }

  public string Description { get; set; }

  public ConfigurationType ConfigType { get; set; }

  public string DisplayConfigType
  {
    get
    {
      switch (this.ConfigType)
      {
        case ConfigurationType.AgendaPubAccess:
          return Localize.GetString("STR_RC_AGENDAPUB_SERVER");
        case ConfigurationType.ApplicationServer:
          return Localize.GetString("STR_RC_APP_SERVER");
        case ConfigurationType.DeficiencyPop:
          return Localize.GetString("STR_RC_DEFICIENCY_POP");
        case ConfigurationType.FiServ_PDS1450:
          return Localize.GetString("STR_RC_APP_PDS1450");
        case ConfigurationType.HealthcareFormManager:
          return Localize.GetString("STR_RC_HEALTHCARE_FORM_MANAGER");
        case ConfigurationType.IdentityProvider:
          return Localize.GetString("STR_RC_IDENTITYPROVIDER");
        case ConfigurationType.JackHenryServer:
          return Localize.GetString("STR_RC_JACKHENRYSERVER");
        case ConfigurationType.MobileBroker:
          return Localize.GetString("STR_RC_MOBILEBROKER");
        case ConfigurationType.PatientWindow:
          return Localize.GetString("STR_PROD_PT_UNIVERSAL_PATIENT_VIEWER");
        case ConfigurationType.PlanReview:
          return Localize.GetString("STR_RC_PLANREVIEW");
        case ConfigurationType.PublicAccessLegacy:
          return Localize.GetString("STR_RC_PUBLIC_ACCESS_SERVER_LEGACY");
        case ConfigurationType.PublicAccessNextGen:
          return Localize.GetString("STR_RC_PUBLIC_ACCESS_SERVER_NEXTGEN");
        case ConfigurationType.ReportingViewer:
          return Localize.GetString("STR_RC_REPORTING_VIEWER");
        case ConfigurationType.WebServer:
          return Localize.GetString("STR_RC_WEB_SERVER");
        case ConfigurationType.WebServicePublishing:
          return Localize.GetString("STR_OS_EIS_LIVE");
        case ConfigurationType.WOPI:
          return "WOPI";
        default:
          return string.Empty;
      }
    }
  }

  public string Version { get; set; }

  public string Name { get; set; }

  public bool IsValid { get; set; }

  public bool EnableADFS { get; set; }

  public bool EnableDiagnostics { get; set; }

  public List<CustomConfigSection> CustomSections { get; set; } = new List<CustomConfigSection>();

  public ApplicationConfiguration(string name, string localPath)
  {
    this.Name = name;
    this.LocalPath = localPath;
    this.WebConfigPath = this.LocalPath;
    if (!this.LocalPath.EndsWith("\\"))
      this.WebConfigPath += "\\";
    this.WebConfigPath += "Web.Config";
    this.SchemaFilePath = this.GetDefaultSchemaPath();
    this.ConfigType = ConfigurationType.Unknown;
    if (File.Exists(this.LocalPath + "\\bin\\PDS1450.dll"))
    {
      this.ConfigType = ConfigurationType.FiServ_PDS1450;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.PDS1450_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.PDS1450_SCHEMA_FILE;
      this.SchemaFilePath = $"{this.LocalPath}\\{"WebConfigSchema.xsd"}";
      this.EnableDiagnostics = true;
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.Web.Client.dll"))
    {
      this.ConfigType = ConfigurationType.WebServer;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.WEB_SERVER_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.WEB_SERVER_SCHEMA_FILE;
      this.EnableADFS = true;
      this.EnableDiagnostics = true;
      this.CustomSections.Add((CustomConfigSection) new DocPopConfigSection());
      this.CustomSections.Add((CustomConfigSection) new FolderPopConfigSection());
      this.CustomSections.Add((CustomConfigSection) new PacketPopConfigSection());
      this.CustomSections.Add((CustomConfigSection) new PdfPopConfigSection());
      this.CustomSections.Add((CustomConfigSection) new FormPopConfigSection());
      this.CustomSections.Add((CustomConfigSection) new LoginFormProcConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.Server.dll"))
    {
      this.ConfigType = ConfigurationType.ApplicationServer;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.APPLICATION_SERVER_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.APPLICATION_SERVER_SCHEMA_FILE;
      this.EnableADFS = true;
      this.EnableDiagnostics = true;
      this.CustomSections.Add((CustomConfigSection) new ContentComposerConfigSection());
      this.CustomSections.Add((CustomConfigSection) new ExternalAccessClientConfigSection());
      this.CustomSections.Add((CustomConfigSection) new MediaHostedConfigSection());
      this.CustomSections.Add((CustomConfigSection) new AppServerPopConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.AgendaPubAccess.Client.dll"))
    {
      this.ConfigType = ConfigurationType.AgendaPubAccess;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.AGENDA_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.AGENDA_SCHEMA_FILE;
      this.CustomSections.Add((CustomConfigSection) new AgendaPubAccessConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Web.PublicAccess.Server.dll"))
    {
      this.ConfigType = ConfigurationType.PublicAccessNextGen;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.PUBLIC_ACCESS_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.PUBLIC_ACCESS_SCHEMA_FILE;
      this.CustomSections.Add((CustomConfigSection) new PublicAccessConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Web.PublicAccess.dll"))
    {
      this.ConfigType = ConfigurationType.PublicAccessLegacy;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.PUBLIC_ACCESS_LEGACY_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.PUBLIC_ACCESS_LEGACY_SCHEMA_FILE;
      this.CustomSections.Add((CustomConfigSection) new PublicAccessConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.Web.DashboardViewer.dll"))
    {
      this.ConfigType = ConfigurationType.ReportingViewer;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.DASHBOARD_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.DASHBOARD_SCHEMA_FILE;
      this.EnableDiagnostics = true;
      this.CustomSections.Add((CustomConfigSection) new ReportingViewerConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.PlanReview.Client.dll"))
    {
      this.ConfigType = ConfigurationType.PlanReview;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.PLAN_REVIEW_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.PLAN_REVIEW_SCHEMA_FILE;
      this.CustomSections.Add((CustomConfigSection) new PlanReviewConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Mobile.WCF.Service.dll"))
    {
      this.ConfigType = ConfigurationType.MobileBroker;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.MOBILE_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.MOBILE_SCHEMA_FILE;
      this.EnableDiagnostics = true;
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.WopiServer.dll"))
    {
      this.ConfigType = ConfigurationType.WOPI;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.WOPI_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.WOPI_SCHEMA_FILE;
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.IdentityModel.Server.dll"))
    {
      this.ConfigType = ConfigurationType.IdentityProvider;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.IDP_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.IDP_SCHEMA_FILE;
      this.EnableDiagnostics = true;
    }
    else if (File.Exists(this.LocalPath + "\\bin\\JackHenryServer.dll"))
    {
      this.ConfigType = ConfigurationType.JackHenryServer;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.JACK_HENRY_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.JACK_HENRY_SCHEMA_FILE;
      this.SchemaFilePath = $"{this.LocalPath}\\{"WebConfigSchema.xsd"}";
      this.CustomSections.Add((CustomConfigSection) new JackHenryIntegrationConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Integrations.WebServicesPublishing.dll"))
    {
      this.ConfigType = ConfigurationType.WebServicePublishing;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.WEB_SERVICE_PUBLISHING_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.WEB_SERVICE_PUBLISHING_SCHEMA_FILE;
      this.CustomSections.Add((CustomConfigSection) new WebServicePublishingConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.Web.DeficiencyPop.dll"))
    {
      this.ConfigType = ConfigurationType.DeficiencyPop;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.DEFICIENCYPOP_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.DEFICIENCYPOP_SCHEMA_FILE;
      this.EnableDiagnostics = true;
      this.CustomSections.Add((CustomConfigSection) new HealthcarePopConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.Web.PatientWindow.dll"))
    {
      this.ConfigType = ConfigurationType.PatientWindow;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.PATIENTWINDOW_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.PATIENTWINDOW_SCHEMA_FILE;
      this.EnableDiagnostics = true;
      this.CustomSections.Add((CustomConfigSection) new HealthcarePopConfigSection());
    }
    else if (File.Exists(this.LocalPath + "\\bin\\Hyland.Applications.Web.HealthcareFormManager.dll"))
    {
      this.ConfigType = ConfigurationType.HealthcareFormManager;
      this.AssemblyPath = this.GetAssemblyPath(AssemblyProxy.HEALTHCAREFORMMANAGER_ASSEMBLY_NAME);
      this.Schema = AssemblyProxy.HEALTHCAREFORMMANAGER_SCHEMA_FILE;
      this.EnableDiagnostics = true;
      this.CustomSections.Add((CustomConfigSection) new HealthcarePopConfigSection());
    }
    this.UpdateTitleBar();
    if (this.ConfigType == ConfigurationType.Unknown)
      return;
    this.ValidateAssembly();
  }

  private string GetAssemblyPath(string assemblyName)
  {
    return $"{this.LocalPath}\\bin\\{assemblyName}.dll";
  }

  private string GetDefaultSchemaPath() => $"{this.LocalPath}\\Schema\\{"WebConfigSchema.xsd"}";

  private void UpdateTitleBar()
  {
    string appSetting = ConfigurationManager.AppSettings["OEMProductName"];
    this.Description = string.IsNullOrEmpty(appSetting) ? "OnBase Web Application Management Console provided by Hyland Software, Inc" : appSetting + " Web Application Management Console provided by Hyland Software, Inc";
    if (string.IsNullOrEmpty(this.Name))
      return;
    this.Description = $"{this.Description} - Virtual Directory: {this.Name}";
  }

  private void ValidateAssembly()
  {
    this.IsValid = false;
    if (!Directory.Exists(this.LocalPath) || !File.Exists(this.WebConfigPath))
      return;
    this.Version = AssemblyName.GetAssemblyName(this.AssemblyPath).Version.ToString();
    this.IsValid = true;
    TraceLogWriter.Write("Caching config type '{0}' with the embedded schema '{1}' in Assembly '{2}'", (object) this.ConfigType, (object) this.Schema, (object) this.AssemblyPath);
  }
}
