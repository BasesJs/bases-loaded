﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

using System.Xml;
using System.Xml.Schema;
using System.Xml.XPath;

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public class XmlEditor
{
  private string _webConfigPath = string.Empty;
  private string _adminSchemaPath = string.Empty;
  private AssemblyProxy _assembly = (AssemblyProxy) null;
  private List<WebConfigKey> _webConfigKeys = (List<WebConfigKey>) null;
  private string _serviceClientType = string.Empty;
  public List<string> _diagnosticsLogNames = (List<string>) null;
  private List<CustomConfigSection> _customSections = (List<CustomConfigSection>) null;
  public List<WebConfigKey> undefinedKeys = new List<WebConfigKey>();
  public List<WebConfigKey> newImportKeys = new List<WebConfigKey>();
  public readonly string customIdentifier = "custom_";
  private List<string> importErrors = new List<string>();
  private Dictionary<string, string> typeErrors = new Dictionary<string, string>();
  public const string SchemaBool = "xs:boolean";
  public const string SchemaInt = "xs:int";
  public const string SchemaString = "xs:string";
  public const string SchemaComplex = "xs:complexType";
  public const string SchemaSimple = "xs:simpleType";
  public const string SchemaElement = "xs:element";
  public const string XmlTab = "\t";

  public string WebConfigPath
  {
    get => this._webConfigPath;
    set => this._webConfigPath = value;
  }

  public string SchemaPath => this._adminSchemaPath;

  public AssemblyProxy Assembly => this._assembly;

  public XmlEditor(
    string webConfigPath,
    AssemblyProxy assembly,
    List<CustomConfigSection> customSections)
  {
    this._webConfigPath = webConfigPath;
    this._assembly = assembly;
    this._webConfigKeys = new List<WebConfigKey>();
    this._customSections = customSections;
  }

  public XmlEditor(
    string webConfigPath,
    string schemaPath,
    AssemblyProxy assembly,
    List<CustomConfigSection> customSections)
    : this(webConfigPath, assembly, customSections)
  {
    this._adminSchemaPath = schemaPath;
  }

  public bool IsVersionCompatible()
  {
    double num = -1.0;
    double adminConsoleVersion = this.GetAdminConsoleVersion();
    if (adminConsoleVersion != -1.0)
      num = this.GetSchemaVersion();
    return num == -1.0 || adminConsoleVersion == num;
  }

  public void EditAppConfig(string key, string value)
  {
    XmlDocument docToSave = new XmlDocument();
    try
    {
      string configurationFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
      using (XmlReader reader = XmlReader.Create(configurationFile, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        docToSave.Load(reader);
      XmlAttribute key1 = this.FindKey(docToSave.GetElementsByTagName("appSettings")[0].ChildNodes, key);
      if (key1 != null)
      {
        key1.InnerXml = value;
      }
      else
      {
        XmlNode xmlNode = docToSave.SelectSingleNode("configuration/appSettings");
        int i = 0;
        XmlNode childNode;
        for (childNode = xmlNode.ChildNodes[i]; childNode.NodeType != XmlNodeType.Element; childNode = xmlNode.ChildNodes[i])
          ++i;
        XmlNode newChild = childNode.Clone();
        newChild.Attributes[nameof (key)].Value = key;
        newChild.Attributes[nameof (value)].Value = value;
        xmlNode.AppendChild(newChild);
      }
      XmlEditor.XmlDocumentSaveWithFormatting(docToSave, AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
      ConfigurationManager.AppSettings.Set(key, value);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_CACHE_USER_PREFS"), Localize.GetString("STR_RC_ERROR_EDITING_CONFIG_FILE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  public bool LoadFromXML(
    Control.ControlCollection controlColl,
    XmlDocument importDoc,
    string filePath,
    List<WebConfigKey> schemaKeys,
    DeprecatedKeyManager deprecatedKeys)
  {
    bool flag = false;
    bool import = false;
    this.undefinedKeys.Clear();
    this.newImportKeys.Clear();
    this.importErrors.Clear();
    this.typeErrors.Clear();
    List<WebConfigKey> keysLoaded = new List<WebConfigKey>();
    if (importDoc != null)
      import = true;
    else
      importDoc = new XmlDocument();
    try
    {
      if (!import)
      {
        string webConfigPath = this._webConfigPath;
        using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
          importDoc.Load(reader);
      }
      XPathNodeIterator xpathNodeIterator = importDoc.CreateNavigator().Select("configuration/appSettings/add");
      if (xpathNodeIterator != null)
      {
        while (xpathNodeIterator.MoveNext())
        {
          XPathNavigator current = xpathNodeIterator.Current;
          string namespaceUri = current.NamespaceURI;
          string attribute1 = current.GetAttribute("key", namespaceUri);
          string attribute2 = current.GetAttribute("value", namespaceUri);
          if (!deprecatedKeys.isDeprecated(attribute1))
          {
            if (attribute1 == "IdPUrl")
            {
              WebConfigKey key1 = new WebConfigKey("IdPServerLocation", "AppSettings");
              WebConfigKey key2 = new WebConfigKey("IdPTenant", "AppSettings");
              WebConfigKey key3 = new WebConfigKey("IdPClient", "AppSettings");
              WebConfigKey key4 = new WebConfigKey("IdPSecret", "AppSettings");
              string empty1 = string.Empty;
              string empty2 = string.Empty;
              string empty3 = string.Empty;
              string empty4 = string.Empty;
              string[] strArray = attribute2.Split(';');
              string str;
              if (strArray.Length == 4)
              {
                str = strArray[0];
                empty2 = strArray[1];
                empty3 = strArray[2];
                empty4 = strArray[3];
              }
              else
                str = attribute2;
              keysLoaded.Add(key1);
              keysLoaded.Add(key2);
              keysLoaded.Add(key3);
              keysLoaded.Add(key4);
              this.UpdateControl(controlColl, key1, str, import);
              this.UpdateControl(controlColl, key2, empty2, import);
              this.UpdateControl(controlColl, key3, empty3, import);
              this.UpdateControl(controlColl, key4, empty4, import);
            }
            else
            {
              WebConfigKey key = new WebConfigKey(attribute1, "AppSettings");
              keysLoaded.Add(key);
              if (!import)
                this._webConfigKeys.Add(key);
              this.UpdateControl(controlColl, key, attribute2, import);
            }
          }
        }
      }
      flag = true;
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_LOAD_CONFIG_ERROR"), Localize.GetString("STR_RC_LOADING_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    try
    {
      foreach (CustomConfigSection customSection in this._customSections)
      {
        if (importDoc.SelectSingleNode("configuration/" + customSection.Type) != null)
          keysLoaded = this.GetEncryptedKeys(customSection.Type, controlColl, keysLoaded, filePath, import, importDoc);
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_READ_PROTECTED"), Localize.GetString("STR_RC_READ_PROTECTED_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    this.MarkMissingKeys(controlColl, schemaKeys, keysLoaded);
    if (flag)
    {
      List<string> errorKeys = new List<string>();
      flag = this.FindNonAppSettingsSchemaPaths(importDoc, controlColl, import, out errorKeys);
      if (import)
      {
        this.importErrors.AddRange((IEnumerable<string>) errorKeys);
        this.ShowImportErrors(this.importErrors, this.typeErrors);
      }
      else if (this.typeErrors.Count > 0)
      {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.AppendLine(Localize.GetString("STR_RC_ERRORS_FOUND_WHILE_LOADING_CONFIG"));
        foreach (string str in this.typeErrors.Values)
          stringBuilder.AppendLine(str);
        stringBuilder.AppendLine(Localize.GetString("STR_RC_VALUES_HIGHLIGHTED_IN_RED"));
        int num = (int) MessageBox.Show(stringBuilder.ToString(), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
    return flag;
  }

  private void UpdateControl(
    Control.ControlCollection controlColl,
    WebConfigKey key,
    string value,
    bool import)
  {
    bool flag = false;
    if (key == null)
      return;
    Control[] controlArray = controlColl.Find(key.KeyName, true);
    if (controlArray.Length != 0)
    {
      Control spinbox = controlArray[0];
      if (!key.Section.Equals("AppSettings", StringComparison.Ordinal))
      {
        foreach (Control control in controlArray)
        {
          TabPage parentTab = this.GetParentTab(control);
          if (parentTab != null && parentTab.Name.Equals(key.Section))
          {
            spinbox = control;
            break;
          }
        }
      }
      switch (spinbox)
      {
        case TextBox _:
          flag = this.SetTextBoxValue(spinbox as TextBox, value);
          break;
        case NumericUpDown _:
          flag = this.SetSpinBoxValue((NumericUpDown) spinbox, key.KeyName, value);
          break;
        case CheckBox _:
          flag = this.SetCheckBoxValue((CheckBox) spinbox, key.KeyName, value);
          break;
        case ComboBox _:
          flag = this.SetComboBoxValue((ComboBox) spinbox, value);
          break;
      }
      if (import & flag)
        this.HighlightImportedKey(controlColl, key.KeyName, key.Section, Color.Yellow);
      else if (!import && this.typeErrors.ContainsKey(key.KeyName))
        this.HighlightImportedKey(controlColl, key.KeyName, key.Section, Color.Red);
    }
    else
      this.HandleMissingControl(controlColl, key.KeyName, key.Section, value, import);
  }

  private List<WebConfigKey> GetEncryptedKeys(
    string block,
    Control.ControlCollection controlColl,
    List<WebConfigKey> keysLoaded,
    string importPath,
    bool import,
    XmlDocument importDoc)
  {
    List<WebConfigKey> encryptedKeys = keysLoaded;
    XmlDocument xmlDocument = new XmlDocument();
    try
    {
      XmlNode xmlNode;
      if (!(EncryptionProvider.ReadEncryptedSettings(importPath, block).GetSection(block) is CustomConfigSection section))
      {
        section = EncryptionProvider.ReadEncryptedSettings(this._webConfigPath, block).GetSection(block) as CustomConfigSection;
        xmlNode = importDoc.SelectSingleNode("configuration/" + block);
      }
      else
      {
        using (StringReader stringReader = new StringReader(section.SectionInformation.GetRawXml()))
        {
          StringReader input = stringReader;
          using (XmlReader reader = XmlReader.Create((TextReader) input, new XmlReaderSettings()
          {
            XmlResolver = (XmlResolver) null
          }))
            xmlDocument.Load(reader);
        }
        xmlNode = xmlDocument.SelectSingleNode(block);
      }
      string tabName = section.TabName;
      int count = xmlNode.ChildNodes.Count;
      for (int i = 0; i < count; ++i)
      {
        XmlNode childNode = xmlNode.ChildNodes[i];
        string name = childNode.Name;
        if (string.Compare(name, "#comment", StringComparison.OrdinalIgnoreCase) != 0 && string.Compare(name, "#whitespace", StringComparison.OrdinalIgnoreCase) != 0)
        {
          string str = childNode.Attributes["value"].Value;
          WebConfigKey key = new WebConfigKey("protected" + name, tabName);
          if (!encryptedKeys.Contains(key))
            encryptedKeys.Add(key);
          if (!import && !this._webConfigKeys.Contains(key))
            this._webConfigKeys.Add(key);
          Control[] controlArray = controlColl.Find("tabControl", false);
          if (controlArray != null)
          {
            TabControl tabControl = controlArray[0] as TabControl;
            if (tabControl.TabPages.ContainsKey(section.TabName) && string.IsNullOrEmpty(section.Parent))
            {
              this.UpdateControl(tabControl.TabPages[section.TabName].Controls, key, str, import);
            }
            else
            {
              Control.ControlCollection controls = tabControl.TabPages[section.Parent].Controls;
              if (controls != null)
                this.UpdateControl((controls[0] as TabControl).TabPages[tabName].Controls, key, str, import);
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(Localize.GetString("STR_RC_READ_PROTECTED"));
      stringBuilder.Append(" ");
      stringBuilder.Append(block);
      stringBuilder.Append(".");
      int num = (int) MessageBox.Show(stringBuilder.ToString(), Localize.GetString("STR_RC_READ_PROTECTED_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return encryptedKeys;
  }

  private bool SetTextBoxValue(TextBox textbox, string value)
  {
    bool flag = false;
    if (string.Compare(textbox.Text, value, StringComparison.CurrentCultureIgnoreCase) != 0)
    {
      flag = true;
      textbox.Text = value;
    }
    return flag;
  }

  private bool SetSpinBoxValue(NumericUpDown spinbox, string key, string value)
  {
    bool flag = false;
    if (value.Length == 0)
      spinbox.Value = 0M;
    else if (string.Compare(spinbox.Value.ToString(), value, StringComparison.OrdinalIgnoreCase) != 0)
    {
      flag = true;
      string str = key.Replace("NotAppSettings", string.Empty);
      int result = 0;
      if (int.TryParse(value, out result))
      {
        if ((Decimal) result >= spinbox.Minimum && (Decimal) result <= spinbox.Maximum)
        {
          spinbox.Value = Convert.ToDecimal(result);
        }
        else
        {
          this.typeErrors.Add(key, "- " + Hyland.Localization.Strings.GetString("STR_RC_KEY_OUTSIDE_ALLOWED_RANGE", (object) value, (object) str));
          flag = true;
        }
      }
      else
      {
        this.typeErrors.Add(key, "- " + Hyland.Localization.Strings.GetString("STR_RC_VALUE_NOT_IMPORTED_MUST_BE_INT", (object) value, (object) str));
        flag = true;
      }
    }
    return flag;
  }

  private bool SetCheckBoxValue(CheckBox checkbox, string key, string value)
  {
    bool result = false;
    if (string.IsNullOrEmpty(value))
      value = "false";
    bool flag;
    if (bool.TryParse(value, out result))
    {
      flag = result != checkbox.Checked;
      checkbox.Checked = result;
    }
    else
    {
      string str = key.Replace("NotAppSettings", string.Empty);
      this.typeErrors.Add(key, "- " + Hyland.Localization.Strings.GetString("STR_RC_VALUE_NOT_IMPORTED_MUST_BE_BOOL", (object) value, (object) str));
      flag = true;
    }
    return flag;
  }

  private bool SetComboBoxValue(ComboBox combobox, string value)
  {
    bool flag = false;
    if (combobox.SelectedItem == null && !string.IsNullOrEmpty(value) || combobox.SelectedItem != null && string.Compare(combobox.SelectedItem.ToString(), value, StringComparison.CurrentCultureIgnoreCase) != 0)
    {
      flag = true;
      if (!ComboBoxOptionBase.SelectComboBoxItem(combobox, value))
      {
        ConfigSettingComboBoxOption settingComboBoxOption = new ConfigSettingComboBoxOption(value);
        combobox.Items.Add((object) settingComboBoxOption);
        combobox.SelectedItem = (object) settingComboBoxOption;
      }
    }
    return flag;
  }

  private void HandleMissingControl(
    Control.ControlCollection controlColl,
    string key,
    string section,
    string value,
    bool import)
  {
    if (string.Compare(ConfigurationManager.AppSettings[key], "hidden", StringComparison.OrdinalIgnoreCase) == 0)
    {
      if (string.Compare(this.GetWebConfigValue(key, string.Empty), value, StringComparison.Ordinal) == 0)
        return;
      this.importErrors.Add(key);
    }
    else
    {
      WebConfigKey webConfigKey = new WebConfigKey(key, section, value);
      this.undefinedKeys.Add(webConfigKey);
      string str = this.customIdentifier + key;
      Control[] controlArray = controlColl.Find(str, true);
      if (controlArray.Length != 0)
      {
        Control control = controlArray[0];
        string webConfigValue = this.GetWebConfigValue(key, string.Empty);
        if (control is TextBox)
          (control as TextBox).Text = value;
        else if (control is CheckBox)
        {
          CheckBox checkBox = control as CheckBox;
          bool result = false;
          if (bool.TryParse(value, out result))
            checkBox.Checked = result;
        }
        if (string.Compare(webConfigValue, value, StringComparison.CurrentCulture) != 0)
          this.HighlightImportedKey(controlColl, str, section, Color.Yellow);
      }
      else if (import)
        this.newImportKeys.Add(webConfigKey);
    }
  }

  private void MarkMissingKeys(
    Control.ControlCollection controlColl,
    List<WebConfigKey> schemaKeys,
    List<WebConfigKey> keysLoaded)
  {
    bool flag = false;
    foreach (WebConfigKey schemaKey in schemaKeys)
    {
      if (!keysLoaded.Contains(schemaKey) && !schemaKey.KeyName.StartsWith("NotAppSettings", StringComparison.OrdinalIgnoreCase) && !schemaKey.KeyName.StartsWith("protectedencrypt", StringComparison.OrdinalIgnoreCase) && string.Compare(ConfigurationManager.AppSettings[schemaKey.KeyName], "hidden", StringComparison.OrdinalIgnoreCase) != 0)
      {
        this.HighlightImportedKey(controlColl, schemaKey.KeyName, schemaKey.Section, Color.Yellow);
        flag = true;
      }
    }
    if (!flag)
      return;
    int num = (int) MessageBox.Show(Hyland.Localization.Strings.GetString("STR_RC_CONFIGURATION_MISSING_VALUES"), Hyland.Localization.Strings.GetString("STR_RC_MISSING_KEYS"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
  }

  private TabPage GetParentTab(Control control)
  {
    if (!(control.Parent.Parent.Parent is TabPage parent) && control.Parent.Parent.Parent.Parent.Parent != null)
      parent = control.Parent.Parent.Parent.Parent.Parent as TabPage;
    return parent;
  }

  public void HighlightImportedKey(
    Control.ControlCollection controlColl,
    string keyName,
    string tabName,
    Color color)
  {
    Control[] controlArray = controlColl.Find(keyName + "_Label", true);
    if (controlArray.Length == 0)
      return;
    Label ctl = (Label) controlArray[0];
    if (tabName.Length > 0)
    {
      foreach (Control control in controlArray)
      {
        TabPage parentTab = this.GetParentTab(control);
        if (parentTab != null && parentTab.Name.Equals(tabName))
        {
          ctl = (Label) control;
          break;
        }
      }
    }
    ctl.BackColor = color;
    int count = controlColl.Count;
    for (int index = 0; index < count; ++index)
    {
      if (controlColl[index] is TabControl)
      {
        IEnumerator enumerator = (controlColl[index] as TabControl).TabPages.GetEnumerator();
        try
        {
          while (enumerator.MoveNext())
          {
            TabPage current = (TabPage) enumerator.Current;
            string text = current.Text;
            if (current.Contains((Control) ctl) && !text.EndsWith("*", StringComparison.Ordinal))
            {
              current.Text = text + "*";
              break;
            }
          }
          break;
        }
        finally
        {
          if (enumerator is IDisposable disposable)
            disposable.Dispose();
        }
      }
    }
  }

  private void ShowImportErrors(List<string> readOnlyKeys, Dictionary<string, string> incorrectType)
  {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.AppendLine(Localize.GetString("STR_RC_WAMCON_IMPORT_COMPLETE"));
    stringBuilder.AppendLine();
    if (readOnlyKeys.Count > 0)
      stringBuilder.AppendLine(Localize.GetString("STR_RC_ERROR_KEYS_READONLY_OR_DO_NOT_EXIST"));
    foreach (string readOnlyKey in readOnlyKeys)
      stringBuilder.AppendLine(readOnlyKey);
    if (incorrectType.Count > 0)
    {
      if (!stringBuilder.ToString().EndsWith("\n", StringComparison.OrdinalIgnoreCase))
        stringBuilder.AppendLine();
      stringBuilder.AppendLine();
      foreach (string str in incorrectType.Values)
        stringBuilder.AppendLine(str);
    }
    int num = (int) MessageBox.Show(stringBuilder.ToString(), Localize.GetString("STR_RC_FINISHED_IMPORTING"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
  }

  public string GetWebConfigValue(string key, string filepath)
  {
    string empty1 = string.Empty;
    XmlDocument xmlDocument = new XmlDocument();
    try
    {
      string empty2 = string.Empty;
      string inputUri = !string.IsNullOrEmpty(filepath) ? filepath : this._webConfigPath;
      using (XmlReader reader = XmlReader.Create(inputUri, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        xmlDocument.Load(reader);
      XmlAttribute key1 = this.FindKey(xmlDocument.GetElementsByTagName("appSettings")[0].ChildNodes, key);
      if (key1 != null)
        empty1 = key1.Value;
    }
    catch (XmlException ex)
    {
      ErrorViewerWriter.Write((Exception) ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_READ_WEBCONFIG"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return empty1;
  }

  private bool FindNonAppSettingsSchemaPaths(
    XmlDocument doc,
    Control.ControlCollection controlColl,
    bool import,
    out List<string> errorKeys)
  {
    bool settingsSchemaPaths = false;
    errorKeys = new List<string>();
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        Stream input = schemaStream;
        using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
        {
          while (xmlReader.Read())
          {
            if (xmlReader.NodeType == XmlNodeType.Element && string.Compare(xmlReader.Name, "xs:element", StringComparison.OrdinalIgnoreCase) == 0)
            {
              string attribute1 = xmlReader.GetAttribute("name");
              if (!string.IsNullOrEmpty(attribute1) && attribute1.Contains("NotAppSettings"))
              {
                string attribute2 = xmlReader.GetAttribute("id");
                string attribute3 = xmlReader.GetAttribute("type");
                if (!string.IsNullOrEmpty(attribute2) && !string.IsNullOrEmpty(attribute3))
                {
                  List<string> collection = this.LoadNonAppSettingsKey(doc, controlColl, attribute1, attribute2, attribute3, import);
                  errorKeys.AddRange((IEnumerable<string>) collection);
                }
              }
            }
          }
        }
      }
      settingsSchemaPaths = true;
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_XML_FILE"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return settingsSchemaPaths;
  }

  private List<string> LoadNonAppSettingsKey(
    XmlDocument doc,
    Control.ControlCollection controlColl,
    string name,
    string path,
    string type,
    bool import)
  {
    bool flag1 = false;
    List<string> stringList = new List<string>();
    XPathNavigator xpathNavigator = doc.CreateNavigator().SelectSingleNode(path);
    if (xpathNavigator != null)
    {
      string input = xpathNavigator.Value;
      if (!string.IsNullOrEmpty(input))
      {
        if (string.Compare(name, "NotAppSettingsServerURL", StringComparison.OrdinalIgnoreCase) == 0)
          input = Regex.Replace(Regex.Replace(input, "/Service.asmx", string.Empty, RegexOptions.IgnoreCase), "/Service.rem", string.Empty, RegexOptions.IgnoreCase);
        if (string.Compare(name, "NotAppSettingsServiceClientType", StringComparison.OrdinalIgnoreCase) == 0)
          input = "SOAP";
        Control[] controlArray = controlColl.Find(name, true);
        if (controlArray.Length != 0)
        {
          switch (type)
          {
            case "xs:boolean":
              if (controlArray[0] is CheckBox checkbox)
              {
                flag1 = this.SetCheckBoxValue(checkbox, name, input);
                break;
              }
              break;
            case "xs:string":
              if (controlArray[0] is TextBox textbox)
              {
                flag1 = this.SetTextBoxValue(textbox, input);
                break;
              }
              break;
            case "xs:int":
              if (controlArray[0] is NumericUpDown spinbox)
              {
                flag1 = this.SetSpinBoxValue(spinbox, name, input);
                break;
              }
              break;
            default:
              if (controlArray[0] is ComboBox combobox)
              {
                flag1 = this.SetComboBoxValue(combobox, input);
                break;
              }
              break;
          }
          if (import & flag1)
            this.HighlightImportedKey(controlColl, name, string.Empty, Color.Yellow);
          else if (!import && this.typeErrors.ContainsKey(name))
            this.HighlightImportedKey(controlColl, name, string.Empty, Color.Red);
        }
        else if (import)
        {
          bool flag2 = true;
          try
          {
            XmlDocument xmlDocument = new XmlDocument();
            string webConfigPath = this._webConfigPath;
            using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
            {
              XmlResolver = (XmlResolver) null
            }))
              xmlDocument.Load(reader);
            XmlNode xmlNode = xmlDocument.SelectSingleNode(path);
            if (xmlNode != null)
            {
              if (xmlNode.Value.Equals(input))
                flag2 = false;
            }
          }
          catch (Exception ex)
          {
            ErrorViewerWriter.Write(ex);
          }
          if (flag2)
          {
            string str = name.Replace("NotAppSettings", string.Empty);
            stringList.Add(str);
          }
        }
      }
    }
    return stringList;
  }

  public bool IsUpdateNeeded(List<WebConfigKey> schemaKeys)
  {
    bool flag = false;
    foreach (WebConfigKey schemaKey in schemaKeys)
    {
      if (!string.IsNullOrEmpty(schemaKey.KeyName) && !this._webConfigKeys.Contains(schemaKey) && !schemaKey.KeyName.StartsWith("NotAppSettings", StringComparison.OrdinalIgnoreCase) && !schemaKey.KeyName.StartsWith("protectedencrypt", StringComparison.OrdinalIgnoreCase))
      {
        flag = true;
        break;
      }
    }
    if (!flag)
    {
      foreach (WebConfigKey webConfigKey in this._webConfigKeys)
      {
        if (!string.IsNullOrEmpty(webConfigKey.KeyName) && !schemaKeys.Contains(webConfigKey))
        {
          flag = true;
          break;
        }
      }
    }
    return flag;
  }

  public string UpdateSchema(List<WebConfigKey> schemaKeys)
  {
    string strA = "false";
    foreach (WebConfigKey schemaKey in schemaKeys)
    {
      if (string.Compare(strA, "error", StringComparison.OrdinalIgnoreCase) != 0)
      {
        if (!string.IsNullOrEmpty(schemaKey.KeyName) && !this._webConfigKeys.Contains(schemaKey) && !schemaKey.KeyName.StartsWith("NotAppSettings", StringComparison.OrdinalIgnoreCase) && !schemaKey.KeyName.StartsWith("protectedencrypt", StringComparison.OrdinalIgnoreCase))
        {
          strA = "true";
          string category = string.Empty;
          try
          {
            string adminSchemaPath = this._adminSchemaPath;
            using (XmlReader xmlReader = XmlReader.Create(adminSchemaPath, new XmlReaderSettings()
            {
              XmlResolver = (XmlResolver) null
            }))
            {
              while (xmlReader.Read())
              {
                if (xmlReader.NodeType == XmlNodeType.Element)
                {
                  if (string.Compare(xmlReader.Name, "xs:complexType", StringComparison.OrdinalIgnoreCase) == 0)
                    category = xmlReader.GetAttribute("name");
                  else if (string.Compare(xmlReader.Name, "xs:element", StringComparison.OrdinalIgnoreCase) == 0)
                  {
                    if (string.Compare(xmlReader.GetAttribute("name"), schemaKey.KeyName, StringComparison.Ordinal) == 0)
                      break;
                  }
                }
              }
            }
          }
          catch (Exception ex)
          {
            strA = "error";
            ErrorViewerWriter.Write(ex);
            int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_UPDATE_SCHEMA"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
          }
          if (!string.IsNullOrEmpty(category) && !this.RemoveKey(schemaKey.KeyName, category))
            strA = "error";
        }
      }
      else
        break;
    }
    foreach (WebConfigKey webConfigKey in this._webConfigKeys)
    {
      if (string.Compare(strA, "error", StringComparison.OrdinalIgnoreCase) != 0)
      {
        if (!string.IsNullOrEmpty(webConfigKey.KeyName) && !schemaKeys.Contains(webConfigKey))
        {
          if (string.Compare(strA, "error", StringComparison.OrdinalIgnoreCase) != 0)
            strA = "true";
          if (!this.CreateKey(webConfigKey.KeyName, (string) null, "string", (List<string>) null, "Misc", string.Empty))
            strA = "error";
        }
      }
      else
        break;
    }
    return strA;
  }

  public void SaveChanges(string savePath, TabControl tabControl)
  {
    XmlDocument xmlDocument = new XmlDocument();
    try
    {
      string webConfigPath = this._webConfigPath;
      using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        xmlDocument.Load(reader);
      XmlNodeList childNodes = xmlDocument.GetElementsByTagName("appSettings")[0].ChildNodes;
      this.LoopThroughTabs(xmlDocument, childNodes, tabControl.TabPages, true);
      this.SaveProtectedBlocks(xmlDocument, tabControl);
      this.SaveNonAppSettings(xmlDocument, tabControl);
      if (this._assembly.IsAppServerOrWebServer)
        this.SaveADFSSettings(xmlDocument, tabControl);
      XmlEditor.XmlDocumentSaveWithFormatting(xmlDocument, savePath);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_CONFIG_SAVE_ERROR"), Localize.GetString("STR_RC_UNABLE_TO_SAVE_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  private void LoopThroughTabs(
    XmlDocument doc,
    XmlNodeList nodes,
    TabControl.TabPageCollection tabCollection,
    bool removeAsterisks)
  {
    foreach (TabPage tab in tabCollection)
    {
      if (removeAsterisks)
      {
        string text = tab.Text;
        if (text.EndsWith("*", StringComparison.Ordinal))
          tab.Text = text.Remove(text.Length - 1);
      }
      foreach (Control control1 in (ArrangedElementCollection) tab.Controls)
      {
        if (control1 is TabControl)
        {
          TabControl tabControl = (TabControl) control1;
          this.LoopThroughTabs(doc, nodes, tabControl.TabPages, true);
        }
        else if (control1 is FlowLayoutPanel)
        {
          foreach (Control control2 in (ArrangedElementCollection) control1.Controls)
            this.LoopThroughControls(doc, nodes, control2);
        }
      }
    }
  }

  private void LoopThroughControls(XmlDocument doc, XmlNodeList nodes, Control control)
  {
    string key = string.Empty;
    string str = string.Empty;
    int num;
    switch (control)
    {
      case Panel _:
        IEnumerator enumerator1 = control.Controls.GetEnumerator();
        try
        {
          while (enumerator1.MoveNext())
          {
            Control current = (Control) enumerator1.Current;
            this.LoopThroughControls(doc, nodes, current);
          }
          goto label_28;
        }
        finally
        {
          if (enumerator1 is IDisposable disposable)
            disposable.Dispose();
        }
      case Label _:
        num = control.BackColor != Color.Transparent ? 1 : 0;
        break;
      default:
        num = 0;
        break;
    }
    if (num != 0)
    {
      control.BackColor = Color.Transparent;
    }
    else
    {
      switch (control)
      {
        case GroupBox _:
          GroupBox groupBox = (GroupBox) control;
          if (string.Compare(groupBox.Text, "Identity Provider", StringComparison.Ordinal) == 0)
          {
            key = "IdPUrl";
            str = this.CreateHylandIdPUrl(groupBox.Controls[0].Controls);
            break;
          }
          IEnumerator enumerator2 = groupBox.Controls[0].Controls.GetEnumerator();
          try
          {
            while (enumerator2.MoveNext())
            {
              Control current = (Control) enumerator2.Current;
              this.LoopThroughControls(doc, nodes, current);
            }
            break;
          }
          finally
          {
            if (enumerator2 is IDisposable disposable)
              disposable.Dispose();
          }
        case TextBox _:
          TextBox textBox = (TextBox) control;
          key = textBox.Name;
          str = textBox.Text;
          break;
        case NumericUpDown _:
          NumericUpDown numericUpDown = (NumericUpDown) control;
          key = numericUpDown.Name;
          str = numericUpDown.Value.ToString();
          break;
        case CheckBox _:
          CheckBox checkBox = (CheckBox) control;
          key = checkBox.Name;
          str = checkBox.Checked.ToString().ToLowerInvariant();
          break;
        case ComboBox _:
          ComboBox comboBox = (ComboBox) control;
          key = comboBox.Name;
          if (comboBox.SelectedItem != null)
            str = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
          break;
      }
    }
label_28:
    if (key.StartsWith(this.customIdentifier, StringComparison.OrdinalIgnoreCase))
      key = key.Substring(this.customIdentifier.Length);
    this.ChangeValueAttribute(doc, nodes, key, str);
  }

  public void ChangeValueAttribute(XmlDocument doc, XmlNodeList nodes, string key, string value)
  {
    XmlAttribute key1 = this.FindKey(nodes, key);
    if (key1 != null)
    {
      try
      {
        key1.InnerXml = value;
      }
      catch (XmlException ex)
      {
        ErrorViewerWriter.Write((Exception) ex);
        int num = (int) MessageBox.Show(Hyland.Localization.Strings.GetString("STR_RC_UNABLE_TO_EDIT_KEY", (object) key), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
    else
    {
      if (string.IsNullOrEmpty(key) || key.StartsWith("NotAppSettings", StringComparison.OrdinalIgnoreCase) || key.StartsWith("protected", StringComparison.OrdinalIgnoreCase))
        return;
      try
      {
        XmlNode xmlNode = doc.SelectSingleNode("configuration/appSettings");
        XmlNode node = doc.CreateNode(XmlNodeType.Element, "add", (string) null);
        XmlAttribute attribute1 = doc.CreateAttribute(nameof (key));
        attribute1.Value = key;
        node.Attributes.Append(attribute1);
        XmlAttribute attribute2 = doc.CreateAttribute(nameof (value));
        attribute2.Value = value;
        node.Attributes.Append(attribute2);
        xmlNode.AppendChild(node);
      }
      catch (Exception ex)
      {
        ErrorViewerWriter.Write(ex);
        int num = (int) MessageBox.Show(Hyland.Localization.Strings.GetString("STR_RC_UNABLE_TO_EDIT_KEY", (object) key), Localize.GetString("STR_RC_ERROR_ADDING_KEY"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
  }

  private void GetControlValue(
    XmlDocument doc,
    Control control,
    XmlNodeList nodes,
    string sectionName)
  {
    bool flag1 = false;
    string str1 = string.Empty;
    string str2 = control.Name;
    string str3 = "protected";
    if (str2.StartsWith(str3, StringComparison.OrdinalIgnoreCase))
      str2 = str2.Substring(str3.Length);
    if (control is Label && control.BackColor != Color.Transparent)
    {
      control.BackColor = Color.Transparent;
    }
    else
    {
      switch (control)
      {
        case TextBox _:
          str1 = (control as TextBox).Text;
          flag1 = true;
          break;
        case NumericUpDown _:
          str1 = (control as NumericUpDown).Value.ToString();
          flag1 = true;
          break;
        case CheckBox _:
          str1 = (control as CheckBox).Checked.ToString().ToLowerInvariant();
          flag1 = true;
          break;
        case ComboBox _:
          ComboBox comboBox = control as ComboBox;
          if (comboBox.SelectedItem != null)
            str1 = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
          flag1 = true;
          break;
      }
    }
    if (!flag1)
      return;
    bool flag2 = false;
    int count = nodes.Count;
    for (int i = 0; i < count; ++i)
    {
      if (string.Compare(nodes[i].Name, str2, StringComparison.OrdinalIgnoreCase) == 0)
      {
        nodes[i].Attributes["value"].Value = str1;
        flag2 = true;
        break;
      }
    }
    if (!flag2)
    {
      CustomConfigSection section = EncryptionProvider.ReadEncryptedSettings(this.WebConfigPath, sectionName).GetSection(sectionName) as CustomConfigSection;
      if (!control.Name.Equals(section.CheckboxName, StringComparison.OrdinalIgnoreCase))
      {
        XmlNode xmlNode = doc.SelectSingleNode("configuration/" + sectionName);
        XmlNode node = doc.CreateNode(XmlNodeType.Element, str2, string.Empty);
        XmlAttribute attribute = doc.CreateAttribute("value");
        attribute.Value = str1;
        node.Attributes.Append(attribute);
        xmlNode.AppendChild(node);
      }
    }
  }

  public bool CheckForMissingSections(TabControl tabControl)
  {
    bool flag = false;
    XmlDocument xmlDocument = new XmlDocument();
    try
    {
      string webConfigPath = this._webConfigPath;
      using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        xmlDocument.Load(reader);
      foreach (CustomConfigSection customSection in this._customSections)
      {
        XmlNodeList elementsByTagName = xmlDocument.GetElementsByTagName(customSection.Type);
        if (elementsByTagName.Count > 0)
        {
          XmlNodeList childNodes = elementsByTagName[0].ChildNodes;
        }
        string tabName = customSection.TabName;
        if (string.IsNullOrEmpty(customSection.Parent))
        {
          if (!tabControl.TabPages.ContainsKey(tabName))
          {
            flag = true;
            int num = (int) MessageBox.Show(Localize.GetString("STR_RC_MISSINGSECTIONLOADING", (object) tabName), Localize.GetString("STR_RC_MISSING_SECTION"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
          }
        }
        else if (!(tabControl.TabPages[customSection.Parent].Controls[0] as TabControl).TabPages.ContainsKey(tabName))
        {
          flag = true;
          int num = (int) MessageBox.Show(Localize.GetString("STR_RC_MISSINGSECTIONLOADING", (object) tabName), Localize.GetString("STR_RC_MISSING_SECTION"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
    }
    return flag;
  }

  private void SaveProtectedBlocks(XmlDocument doc, TabControl tabControl)
  {
    foreach (CustomConfigSection customSection in this._customSections)
    {
      string type = customSection.Type;
      try
      {
        XmlNodeList nodes = doc.GetElementsByTagName(type);
        if (nodes.Count > 0)
          nodes = nodes[0].ChildNodes;
        Control.ControlCollection controlCollection = (Control.ControlCollection) null;
        string tabName = customSection.TabName;
        if (string.IsNullOrEmpty(customSection.Parent))
        {
          if (tabControl.TabPages.ContainsKey(tabName))
          {
            controlCollection = tabControl.TabPages[tabName].Controls;
          }
          else
          {
            int num1 = (int) MessageBox.Show(Localize.GetString("STR_RC_MISSINGFROMWEBCONFIG", (object) tabName), Localize.GetString("STR_RC_MISSING_SECTION"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
          }
        }
        else
        {
          TabControl control = tabControl.TabPages[customSection.Parent].Controls[0] as TabControl;
          if (control.TabPages.ContainsKey(tabName))
          {
            controlCollection = control.TabPages[tabName].Controls;
          }
          else
          {
            int num2 = (int) MessageBox.Show(Localize.GetString("STR_RC_MISSINGFROMWEBCONFIG", (object) tabName), Localize.GetString("STR_RC_MISSING_SECTION"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
          }
        }
        if (controlCollection != null)
        {
          foreach (Control control1 in (ArrangedElementCollection) controlCollection)
          {
            if (control1 is FlowLayoutPanel)
            {
              foreach (Control control2 in (ArrangedElementCollection) control1.Controls)
              {
                if (control2 is Panel)
                {
                  foreach (Control control3 in (ArrangedElementCollection) control2.Controls)
                    this.GetControlValue(doc, control3, nodes, type);
                }
                else if (control2 is GroupBox)
                {
                  foreach (Control control4 in (ArrangedElementCollection) control2.Controls[0].Controls)
                  {
                    foreach (Control control5 in (ArrangedElementCollection) control4.Controls)
                      this.GetControlValue(doc, control5, nodes, type);
                  }
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorViewerWriter.Write(ex);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append(Localize.GetString("STR_RC_CONFIG_UPDATE_ERROR"));
        stringBuilder.Append(" ");
        stringBuilder.Append(type);
        stringBuilder.Append(".");
        int num = (int) MessageBox.Show(stringBuilder.ToString(), Localize.GetString("STR_RC_UNABLE_TO_SAVE_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
  }

  private void SaveNonAppSettings(XmlDocument doc, TabControl tabControl)
  {
    bool flag = true;
    try
    {
      if (!this.SaveServiceClientType(doc, tabControl, false))
        flag = false;
      if (!this.SaveServerURL(doc, tabControl, false))
        flag = false;
      if (!this.SaveServiceLocations_ServicePath(doc, tabControl, false))
        flag = false;
      if (!this.SaveServiceLocations_DataSource(doc, tabControl, false))
        flag = false;
      if (!this.SaveHylandTracing(doc, tabControl, false))
        flag = false;
      if (!this.SaveRequestTimeout(doc, tabControl, false))
        flag = false;
      if (!this.SaveSessionStateTimeout(doc, tabControl, false))
        flag = false;
      if (!this.SaveSessionStateSameSiteCookie(doc, tabControl, false))
        flag = false;
      if (!this.SaveExecutionTimeout(doc, tabControl, false))
        flag = false;
      if (!this.SaveMaxRequestLength(doc, tabControl, false))
        flag = false;
      if (!this.SaveMaxAllowedContentLength(doc, tabControl, false))
        flag = false;
      if (!this.SaveWOPISettings(doc, tabControl, false))
        flag = false;
      if (!this.SaveIDPNode(doc, tabControl))
        flag = false;
      if (this.SaveTrustedCertificate(doc, tabControl))
        ;
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      if (!flag)
        return;
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_UPDATING_NON_APPSETTINGS"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  private void SaveADFSSettings(XmlDocument doc, TabControl tabControl)
  {
    bool flag = true;
    try
    {
      if (!this.SaveADFSEnabled(doc, tabControl, false))
        flag = false;
      if (!this.SaveAuthenticationMode(doc, tabControl, false))
        flag = false;
      if (!this.SaveRequestValidationMode(doc, tabControl, false))
        flag = false;
      if (!this.SaveSystemIdentityModelValues(doc, tabControl, false))
        flag = false;
      if (this.SaveSystemIdentityModelServicesValues(doc, tabControl, false))
        ;
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      if (!flag)
        return;
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_UPDATING_NON_APPSETTINGS"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  private XmlNodeList GetSystemWebNodes(XmlDocument doc)
  {
    XmlNodeList elementsByTagName = doc.GetElementsByTagName("system.web");
    XmlNodeList childNodes;
    if (elementsByTagName.Count > 0)
    {
      childNodes = elementsByTagName[0].ChildNodes;
    }
    else
    {
      XmlNode node = doc.CreateNode(XmlNodeType.Element, "system.web", (string) null);
      doc.DocumentElement.AppendChild(node);
      childNodes = node.ChildNodes;
    }
    return childNodes;
  }

  private XmlNodeList GetSystemWebServerNodes(XmlDocument doc)
  {
    XmlNodeList elementsByTagName = doc.GetElementsByTagName("system.webServer");
    XmlNodeList childNodes;
    if (elementsByTagName.Count > 0)
    {
      childNodes = elementsByTagName[0].ChildNodes;
    }
    else
    {
      XmlNode node = doc.CreateNode(XmlNodeType.Element, "system.webServer", (string) null);
      doc.DocumentElement.AppendChild(node);
      childNodes = node.ChildNodes;
    }
    return childNodes;
  }

  private XmlNodeList GetHylandServicesClientNodes(XmlDocument doc, bool export)
  {
    XmlNodeList servicesClientNodes = doc.GetElementsByTagName("Hyland.Services.Client");
    if (servicesClientNodes.Count > 0)
      servicesClientNodes = servicesClientNodes[0].ChildNodes;
    else if (export)
    {
      XmlNode node = doc.CreateNode(XmlNodeType.Element, "Hyland.Services.Client", (string) null);
      doc.DocumentElement.AppendChild(node);
      servicesClientNodes = node.ChildNodes;
    }
    return servicesClientNodes;
  }

  private XmlNodeList GetADFSNodes(XmlDocument doc)
  {
    XmlNodeList adfsNodes = doc.GetElementsByTagName("Hyland.Authentication");
    if (adfsNodes.Count > 0)
      adfsNodes = adfsNodes[0].ChildNodes;
    return adfsNodes;
  }

  private bool SaveSystemIdentityModelServicesValues(
    XmlDocument doc,
    TabControl tabControl,
    bool export)
  {
    bool flag = true;
    try
    {
      Control[] controlArray1 = tabControl.Controls.Find("NotAppSettingsWSFederationIssuer", true);
      if (controlArray1.Length != 0)
      {
        TextBox textBox1 = (TextBox) controlArray1[0];
        XmlNode xmlNode = doc.SelectSingleNode("configuration/system.identityModel.services/federationConfiguration/wsFederation");
        if (xmlNode == null)
          return true;
        if (xmlNode.Attributes["issuer"] != null)
          xmlNode.Attributes["issuer"].InnerXml = textBox1.Text;
        Control[] controlArray2 = tabControl.Controls.Find("NotAppSettingsWSFederationRealm", true);
        if (controlArray2.Length != 0)
        {
          TextBox textBox2 = (TextBox) controlArray2[0];
          if (xmlNode.Attributes["realm"] != null)
            xmlNode.Attributes["realm"].InnerXml = textBox2.Text;
        }
      }
      Control[] controlArray3 = tabControl.Controls.Find("NotAppSettingsWebServerCertificateReference509FindType", true);
      if (controlArray3.Length != 0)
      {
        TextBox textBox3 = (TextBox) controlArray3[0];
        XmlNode xmlNode = doc.SelectSingleNode("configuration/system.identityModel.services/federationConfiguration/serviceCertificate/certificateReference");
        if (xmlNode.Attributes["x509FindType"] != null)
          xmlNode.Attributes["x509FindType"].InnerXml = textBox3.Text;
        Control[] controlArray4 = tabControl.Controls.Find("NotAppSettingsWebServerCertificateReferenceFindValue", true);
        if (controlArray4.Length != 0)
        {
          TextBox textBox4 = (TextBox) controlArray4[0];
          if (xmlNode.Attributes["findValue"] != null)
            xmlNode.Attributes["findValue"].InnerXml = textBox4.Text;
        }
        Control[] controlArray5 = tabControl.Controls.Find("NotAppSettingsWebServerCertificateReferenceStoreLocation", true);
        if (controlArray5.Length != 0)
        {
          TextBox textBox5 = (TextBox) controlArray5[0];
          if (xmlNode.Attributes["storeLocation"] != null)
            xmlNode.Attributes["storeLocation"].InnerXml = textBox5.Text;
        }
        Control[] controlArray6 = tabControl.Controls.Find("NotAppSettingsWebServerCertificateReferenceStoreName", true);
        if (controlArray6.Length != 0)
        {
          TextBox textBox6 = (TextBox) controlArray6[0];
          if (xmlNode.Attributes["storeName"] != null)
            xmlNode.Attributes["storeName"].InnerXml = textBox6.Text;
        }
      }
      Control[] controlArray7 = tabControl.Controls.Find("NotAppSettingsCookieHandlerRequireSSL", true);
      if (controlArray7.Length != 0)
      {
        CheckBox checkBox = (CheckBox) controlArray7[0];
        XmlNode xmlNode = doc.SelectSingleNode("configuration/system.identityModel.services/federationConfiguration/cookieHandler");
        if (xmlNode.Attributes["requireSsl"] != null)
          xmlNode.Attributes["requireSsl"].InnerXml = checkBox.Checked.ToString().ToLowerInvariant();
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ADFS_UNABLE_TO_SAVE_SYSTEMIDENTITYMODELSERVICES"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveSystemIdentityModelValues(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag = true;
    try
    {
      Control[] controlArray1 = tabControl.Controls.Find("NotAppSettingsWebServerURI", true);
      if (controlArray1.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray1[0];
        XmlNode xmlNode = doc.SelectSingleNode("configuration/system.identityModel/identityConfiguration/securityTokenHandlers/securityTokenHandlerConfiguration/audienceUris/add");
        if (xmlNode == null)
          return true;
        if (xmlNode.Attributes["value"] != null)
          xmlNode.Attributes["value"].InnerXml = textBox.Text;
      }
      Control[] controlArray2 = tabControl.Controls.Find("NotAppSettingsTrustedIssuersThumbprint", true);
      if (controlArray2.Length != 0)
      {
        TextBox textBox1 = (TextBox) controlArray2[0];
        XmlNode xmlNode = doc.SelectSingleNode("configuration/system.identityModel/identityConfiguration/securityTokenHandlers/securityTokenHandlerConfiguration/issuerNameRegistry/trustedIssuers/add");
        if (xmlNode.Attributes["thumbprint"] != null)
          xmlNode.Attributes["thumbprint"].InnerXml = textBox1.Text;
        Control[] controlArray3 = tabControl.Controls.Find("NotAppSettingsTrustedIssuersName", true);
        if (controlArray3.Length != 0)
        {
          TextBox textBox2 = (TextBox) controlArray3[0];
          if (xmlNode.Attributes["name"] != null)
            xmlNode.Attributes["name"].InnerXml = textBox2.Text;
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ADFS_UNABLE_TO_SAVE_SYSTEMIDENTITYMODEL"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveRequestValidationMode(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag = true;
    try
    {
      XmlNodeList systemWebNodes = this.GetSystemWebNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsRequestValidationMode", true);
      if (controlArray.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray[0];
        foreach (XmlNode xmlNode in systemWebNodes)
        {
          if (string.Compare(xmlNode.Name, "httpRuntime", StringComparison.Ordinal) == 0)
          {
            XmlAttribute attribute = xmlNode.Attributes["requestValidationMode"];
            if (attribute != null)
            {
              attribute.InnerXml = textBox.Text;
              break;
            }
            break;
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ADFS_UNABLE_TO_SAVE_REQVALMODE"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveAuthenticationMode(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag = true;
    try
    {
      XmlNodeList systemWebNodes = this.GetSystemWebNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsAuthenticationMode", true);
      if (controlArray.Length != 0)
      {
        ComboBox comboBox = (ComboBox) controlArray[0];
        foreach (XmlNode xmlNode in systemWebNodes)
        {
          if (string.Compare(xmlNode.Name, "authentication", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["mode"].InnerXml = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
            break;
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ADFS_UNABLE_TO_SAVE_AUTHMODE"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveADFSEnabled(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag = true;
    try
    {
      XmlNodeList adfsNodes = this.GetADFSNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsADFSEnabled", true);
      if (controlArray.Length != 0)
      {
        CheckBox checkBox = (CheckBox) controlArray[0];
        foreach (XmlNode xmlNode in adfsNodes)
        {
          if (string.Compare(xmlNode.Name, "adfs", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["enabled"].InnerXml = checkBox.Checked.ToString().ToLowerInvariant();
            break;
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ADFS_UNABLE_TO_SAVE_ADFSENABLED"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveServiceClientType(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList servicesClientNodes = this.GetHylandServicesClientNodes(doc, export);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsServiceClientType", true);
      if (controlArray.Length != 0)
      {
        ComboBox comboBox = (ComboBox) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in servicesClientNodes)
        {
          if (string.Compare(xmlNode.Name, "ApplicationServer", StringComparison.Ordinal) == 0)
          {
            this._serviceClientType = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
            xmlNode.Attributes["ServiceClientType"].InnerXml = "SOAP";
            flag2 = true;
            break;
          }
        }
        if (!flag2 & export)
        {
          XmlNode xmlNode = doc.SelectSingleNode("configuration/Hyland.Services.Client");
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "ApplicationServer", (string) null);
          XmlAttribute attribute1 = doc.CreateAttribute("Url");
          attribute1.Value = string.Empty;
          node.Attributes.Append(attribute1);
          XmlAttribute attribute2 = doc.CreateAttribute("ServiceClientType");
          attribute2.Value = "SOAP";
          this._serviceClientType = "SOAP";
          node.Attributes.Append(attribute2);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_SAVE_SERVICECLIENTTYPE"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveServerURL(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList servicesClientNodes = this.GetHylandServicesClientNodes(doc, export);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsServerURL", true);
      if (controlArray.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in servicesClientNodes)
        {
          if (string.Compare(xmlNode.Name, "ApplicationServer", StringComparison.Ordinal) == 0)
          {
            XmlAttribute attribute = xmlNode.Attributes["Url"];
            if (!textBox.Text.EndsWith("/Service.asmx", StringComparison.OrdinalIgnoreCase))
              textBox.Text += "/Service.asmx";
            attribute.InnerXml = textBox.Text;
            flag2 = true;
            break;
          }
        }
        if (!flag2 & export)
        {
          XmlNode xmlNode = doc.SelectSingleNode("Hyland.Services.Client");
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "ApplicationServer", (string) null);
          XmlAttribute attribute1 = doc.CreateAttribute("Url");
          attribute1.Value = textBox.Text + "/Service.rem";
          node.Attributes.Append(attribute1);
          XmlAttribute attribute2 = doc.CreateAttribute("ServiceClientType");
          attribute2.Value = "Remoting";
          node.Attributes.Append(attribute2);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_SAVE_SERVERURL"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveServiceLocations_ServicePath(
    XmlDocument doc,
    TabControl tabControl,
    bool export)
  {
    bool flag = true;
    try
    {
      XmlNodeList servicesClientNodes = this.GetHylandServicesClientNodes(doc, export);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsServicePath", true);
      if (controlArray.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray[0];
        foreach (XmlNode xmlNode in servicesClientNodes)
        {
          if (string.Compare(xmlNode.Name, "ServiceLocations", StringComparison.OrdinalIgnoreCase) == 0)
          {
            IEnumerator enumerator = xmlNode.ChildNodes.GetEnumerator();
            try
            {
              while (enumerator.MoveNext())
              {
                XmlNode current = (XmlNode) enumerator.Current;
                if (string.Compare(current.Name, "add", StringComparison.OrdinalIgnoreCase) == 0)
                {
                  current.Attributes["ServicePath"].InnerXml = textBox.Text;
                  break;
                }
              }
              break;
            }
            finally
            {
              if (enumerator is IDisposable disposable)
                disposable.Dispose();
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVESERVICEPATH"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveServiceLocations_DataSource(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag = true;
    try
    {
      XmlNodeList servicesClientNodes = this.GetHylandServicesClientNodes(doc, export);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsDataSource", true);
      if (controlArray.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray[0];
        foreach (XmlNode xmlNode in servicesClientNodes)
        {
          if (string.Compare(xmlNode.Name, "ServiceLocations", StringComparison.OrdinalIgnoreCase) == 0)
          {
            IEnumerator enumerator = xmlNode.ChildNodes.GetEnumerator();
            try
            {
              while (enumerator.MoveNext())
              {
                XmlNode current = (XmlNode) enumerator.Current;
                if (string.Compare(current.Name, "add", StringComparison.OrdinalIgnoreCase) == 0)
                {
                  current.Attributes["DataSource"].InnerXml = textBox.Text;
                  break;
                }
              }
              break;
            }
            finally
            {
              if (enumerator is IDisposable disposable)
                disposable.Dispose();
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVEDATASOURCE"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveRequestTimeout(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList servicesClientNodes = this.GetHylandServicesClientNodes(doc, export);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsRequestTimeoutSeconds", true);
      if (controlArray.Length != 0)
      {
        NumericUpDown numericUpDown = (NumericUpDown) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in servicesClientNodes)
        {
          if (string.Compare(xmlNode.Name, "RequestTimeoutSeconds", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["Value"].InnerXml = numericUpDown.Value.ToString();
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("Hyland.Services.Client").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("Hyland.Services.Client")[0];
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "RequestTimeoutSeconds", (string) null);
          XmlAttribute attribute = doc.CreateAttribute("Value");
          attribute.Value = numericUpDown.Value.ToString();
          node.Attributes.Append(attribute);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVEREQUESTTIMEOUT"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveMaxAllowedContentLength(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag = true;
    try
    {
      XmlNodeList systemWebServerNodes = this.GetSystemWebServerNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsMaxAllowedContentLength", true);
      if (controlArray.Length != 0)
      {
        NumericUpDown numericUpDown = (NumericUpDown) controlArray[0];
        foreach (XmlNode xmlNode in systemWebServerNodes)
        {
          if (string.Compare(xmlNode.Name, "security", StringComparison.OrdinalIgnoreCase) == 0)
          {
            IEnumerator enumerator1 = xmlNode.ChildNodes.GetEnumerator();
            try
            {
              while (enumerator1.MoveNext())
              {
                XmlNode current1 = (XmlNode) enumerator1.Current;
                if (string.Compare(current1.Name, "requestFiltering", StringComparison.OrdinalIgnoreCase) == 0)
                {
                  IEnumerator enumerator2 = current1.ChildNodes.GetEnumerator();
                  try
                  {
                    while (enumerator2.MoveNext())
                    {
                      XmlNode current2 = (XmlNode) enumerator2.Current;
                      if (string.Compare(current2.Name, "requestLimits", StringComparison.OrdinalIgnoreCase) == 0)
                      {
                        XmlAttribute attribute = current2.Attributes["maxAllowedContentLength"];
                        if (attribute != null)
                        {
                          attribute.InnerXml = numericUpDown.Value.ToString();
                          break;
                        }
                        break;
                      }
                    }
                    break;
                  }
                  finally
                  {
                    if (enumerator2 is IDisposable disposable)
                      disposable.Dispose();
                  }
                }
              }
              break;
            }
            finally
            {
              if (enumerator1 is IDisposable disposable)
                disposable.Dispose();
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVEMAXCONTENTLENGTH"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveSessionStateTimeout(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList systemWebNodes = this.GetSystemWebNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsSessionStateTimeout", true);
      if (controlArray.Length != 0)
      {
        NumericUpDown numericUpDown = (NumericUpDown) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in systemWebNodes)
        {
          if (string.Compare(xmlNode.Name, "sessionState", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["timeout"].InnerXml = numericUpDown.Value.ToString();
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("system.web").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("system.web")[0];
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "sessionState", (string) null);
          XmlAttribute attribute = doc.CreateAttribute("timeout");
          attribute.Value = numericUpDown.Value.ToString();
          node.Attributes.Append(attribute);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_SAVE_SESSIONTIMEOUT"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveSessionStateSameSiteCookie(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList systemWebNodes = this.GetSystemWebNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsSessionStateSameSiteCookie", true);
      if (controlArray.Length != 0)
      {
        ComboBox comboBox = (ComboBox) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in systemWebNodes)
        {
          if (string.Compare(xmlNode.Name, "sessionState", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["cookieSameSite"].InnerXml = comboBox.Text;
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("system.web").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("system.web")[0];
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "sessionState", (string) null);
          XmlAttribute attribute = doc.CreateAttribute("cookieSameSite");
          attribute.Value = comboBox.Text;
          node.Attributes.Append(attribute);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_SAVE_SAMESITECOOKIE"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveMaxRequestLength(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList systemWebNodes = this.GetSystemWebNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsMaxRequestLength", true);
      if (controlArray.Length != 0)
      {
        NumericUpDown numericUpDown = (NumericUpDown) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in systemWebNodes)
        {
          if (string.Compare(xmlNode.Name, "httpRuntime", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["maxRequestLength"].InnerXml = numericUpDown.Value.ToString();
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("system.web").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("system.web")[0];
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "httpRuntime", (string) null);
          XmlAttribute attribute = doc.CreateAttribute("maxRequestLength");
          attribute.Value = numericUpDown.Value.ToString();
          node.Attributes.Append(attribute);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVEMAXREQUESTLENGTH"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveExecutionTimeout(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList systemWebNodes = this.GetSystemWebNodes(doc);
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsExecutionTimeout", true);
      if (controlArray.Length != 0)
      {
        NumericUpDown numericUpDown = (NumericUpDown) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in systemWebNodes)
        {
          if (string.Compare(xmlNode.Name, "httpRuntime", StringComparison.Ordinal) == 0)
          {
            xmlNode.Attributes["executionTimeout"].InnerXml = numericUpDown.Value.ToString();
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("system.web").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("system.web")[0];
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "httpRuntime", (string) null);
          XmlAttribute attribute = doc.CreateAttribute("executionTimeout");
          attribute.Value = numericUpDown.Value.ToString();
          node.Attributes.Append(attribute);
          xmlNode.AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVEEXECUTIONTIMEOUT"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveHylandTracing(XmlDocument doc, TabControl tabControl, bool export)
  {
    bool flag1 = true;
    try
    {
      XmlNodeList xmlNodeList = (XmlNodeList) null;
      XmlNodeList elementsByTagName = doc.GetElementsByTagName("system.diagnostics");
      if (elementsByTagName.Count > 0)
      {
        xmlNodeList = elementsByTagName[0].ChildNodes;
        if (xmlNodeList.Count > 0)
        {
          foreach (XmlNode xmlNode in xmlNodeList)
          {
            if (string.Compare(xmlNode.Name, "switches", StringComparison.OrdinalIgnoreCase) == 0)
            {
              xmlNodeList = xmlNode.ChildNodes;
              break;
            }
          }
        }
        else if (export)
        {
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "switches", (string) null);
          elementsByTagName[0].AppendChild(node);
          xmlNodeList = node.ChildNodes;
        }
      }
      else if (export)
      {
        XmlNode node1 = doc.CreateNode(XmlNodeType.Element, "system.diagnostics", (string) null);
        doc.DocumentElement.AppendChild(node1);
        XmlNode node2 = doc.CreateNode(XmlNodeType.Element, "switches", (string) null);
        node1.AppendChild(node2);
        xmlNodeList = node2.ChildNodes;
      }
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsHylandTracing", true);
      if (controlArray.Length != 0)
      {
        NumericUpDown numericUpDown = (NumericUpDown) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode xmlNode in xmlNodeList)
        {
          if (string.Compare(xmlNode.Name, "add", StringComparison.Ordinal) == 0)
          {
            flag2 = true;
            if (string.Compare(xmlNode.Attributes["name"].Value, "hylandTracing", StringComparison.Ordinal) == 0)
              xmlNode.Attributes["value"].InnerXml = numericUpDown.Value.ToString();
          }
        }
        if (!flag2 & export)
        {
          XmlNode node = doc.CreateNode(XmlNodeType.Element, "add", (string) null);
          XmlAttribute attribute1 = doc.CreateAttribute("name");
          attribute1.Value = "hylandTracing";
          node.Attributes.Append(attribute1);
          XmlAttribute attribute2 = doc.CreateAttribute("value");
          attribute2.Value = numericUpDown.Value.ToString();
          node.Attributes.Append(attribute2);
          doc.GetElementsByTagName("system.diagnostics")[0].ChildNodes[2].AppendChild(node);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_SAVE_HYLANDTRACING"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag1;
  }

  private bool SaveWOPISettings(XmlDocument doc, TabControl tabControl, bool export)
  {
    XmlNodeList wopiNodes = doc.GetElementsByTagName("Hyland.Core.Wopi");
    if (wopiNodes.Count > 0)
      wopiNodes = wopiNodes[0].ChildNodes;
    else if (export)
    {
      XmlNode element = (XmlNode) doc.CreateElement("Hyland.Core.Wopi");
      doc.DocumentElement.AppendChild(element);
      wopiNodes = element.ChildNodes;
    }
    bool flag = this.SaveUseOfficeWebAppServer(doc, wopiNodes, tabControl, export) && this.SaveOWAServerUri(doc, wopiNodes, tabControl, export) && this.SaveOWAProxyBase(doc, wopiNodes, tabControl, export);
    if (!flag)
    {
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLETOSAVEWOPISETTINGS"), Localize.GetString("STR_RC_ERROR_SAVING_VALUE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveUseOfficeWebAppServer(
    XmlDocument doc,
    XmlNodeList wopiNodes,
    TabControl tabControl,
    bool export)
  {
    bool flag1 = true;
    try
    {
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsUseOfficeWebAppServer", true);
      if (controlArray.Length != 0)
      {
        CheckBox checkBox = (CheckBox) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode wopiNode in wopiNodes)
        {
          if (string.Compare(wopiNode.Name, "useOfficeWebAppServer", StringComparison.OrdinalIgnoreCase) == 0)
          {
            wopiNode.Attributes["value"].InnerText = checkBox.Checked.ToString().ToLowerInvariant();
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("Hyland.Core.Wopi").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("Hyland.Core.Wopi")[0];
          XmlNode element = (XmlNode) doc.CreateElement("useOfficeWebAppServer");
          XmlAttribute attribute = doc.CreateAttribute("value");
          attribute.Value = checkBox.Checked.ToString();
          element.Attributes.Append(attribute);
          xmlNode.AppendChild(element);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
    }
    return flag1;
  }

  private bool SaveOWAServerUri(
    XmlDocument doc,
    XmlNodeList wopiNodes,
    TabControl tabControl,
    bool export)
  {
    bool flag1 = true;
    try
    {
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsOwaServerUri", true);
      if (controlArray.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode wopiNode in wopiNodes)
        {
          if (string.Compare(wopiNode.Name, "owaServerUri", StringComparison.OrdinalIgnoreCase) == 0)
          {
            wopiNode.Attributes["value"].InnerText = textBox.Text;
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("Hyland.Core.Wopi").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("Hyland.Core.Wopi")[0];
          XmlNode element = (XmlNode) doc.CreateElement("owaServerUri");
          XmlAttribute attribute = doc.CreateAttribute("value");
          attribute.Value = textBox.Text;
          element.Attributes.Append(attribute);
          xmlNode.AppendChild(element);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
    }
    return flag1;
  }

  private bool SaveOWAProxyBase(
    XmlDocument doc,
    XmlNodeList wopiNodes,
    TabControl tabControl,
    bool export)
  {
    bool flag1 = true;
    try
    {
      Control[] controlArray = tabControl.Controls.Find("NotAppSettingsOwaProxyBase", true);
      if (controlArray.Length != 0)
      {
        TextBox textBox = (TextBox) controlArray[0];
        bool flag2 = false;
        foreach (XmlNode wopiNode in wopiNodes)
        {
          if (string.Compare(wopiNode.Name, "owaProxyBase", StringComparison.OrdinalIgnoreCase) == 0)
          {
            wopiNode.Attributes["value"].InnerText = textBox.Text;
            flag2 = true;
            break;
          }
        }
        if (!flag2 && doc.GetElementsByTagName("Hyland.Core.Wopi").Count > 0)
        {
          XmlNode xmlNode = doc.GetElementsByTagName("Hyland.Core.Wopi")[0];
          XmlNode element = (XmlNode) doc.CreateElement("owaProxyBase");
          XmlAttribute attribute = doc.CreateAttribute("value");
          attribute.Value = textBox.Text;
          element.Attributes.Append(attribute);
          xmlNode.AppendChild(element);
        }
      }
    }
    catch (Exception ex)
    {
      flag1 = false;
      ErrorViewerWriter.Write(ex);
    }
    return flag1;
  }

  private bool SaveIDPNode(XmlDocument doc, TabControl tabControl)
  {
    bool flag = true;
    try
    {
      XmlNodeList adfsNodes = this.GetADFSNodes(doc);
      if (adfsNodes != null)
      {
        Control[] controlArray1 = tabControl.Controls.Find("NotAppSettingsRoot", true);
        if (controlArray1.Length != 0)
        {
          TextBox textBox = (TextBox) controlArray1[0];
          foreach (XmlNode xmlNode in adfsNodes)
          {
            if (string.Compare(xmlNode.Name, "idp", StringComparison.Ordinal) == 0)
            {
              xmlNode.Attributes["root"].Value = textBox.Text;
              break;
            }
          }
        }
        Control[] controlArray2 = tabControl.Controls.Find("NotAppSettingsTraceLevel", true);
        if (controlArray2.Length != 0)
        {
          ComboBox comboBox = (ComboBox) controlArray2[0];
          foreach (XmlNode xmlNode in adfsNodes)
          {
            if (string.Compare(xmlNode.Name, "idp", StringComparison.Ordinal) == 0)
            {
              xmlNode.Attributes["traceLevel"].Value = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
              break;
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_CONFIG_SAVE_ERROR"), Localize.GetString("STR_RC_UNABLE_TO_SAVE_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  private bool SaveTrustedCertificate(XmlDocument doc, TabControl tabControl)
  {
    bool flag = true;
    try
    {
      XmlNode xmlNode = doc.SelectSingleNode("configuration/Hyland.Authentication/idp");
      if (xmlNode != null)
      {
        string empty1 = string.Empty;
        string empty2 = string.Empty;
        string empty3 = string.Empty;
        string str1 = string.Empty;
        string str2 = string.Empty;
        Control[] controlArray1 = tabControl.Controls.Find("NotAppSettingsStoreLocation", true);
        if (controlArray1.Length != 0)
        {
          ComboBox comboBox = (ComboBox) controlArray1[0];
          if (comboBox.SelectedItem != null)
            empty1 = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
        }
        Control[] controlArray2 = tabControl.Controls.Find("NotAppSettingsStoreName", true);
        if (controlArray2.Length != 0)
        {
          ComboBox comboBox = (ComboBox) controlArray2[0];
          if (comboBox.SelectedItem != null)
            empty2 = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
        }
        Control[] controlArray3 = tabControl.Controls.Find("NotAppSettingsFindType", true);
        if (controlArray3.Length != 0)
        {
          ComboBox comboBox = (ComboBox) controlArray3[0];
          if (comboBox.SelectedItem != null)
            empty3 = (comboBox.SelectedItem as ConfigSettingComboBoxOption).Value;
        }
        Control[] controlArray4 = tabControl.Controls.Find("NotAppSettingsFindValue", true);
        if (controlArray4.Length != 0)
          str1 = controlArray4[0].Text;
        Control[] controlArray5 = tabControl.Controls.Find("NotAppSettingsDescription", true);
        if (controlArray5.Length != 0)
          str2 = controlArray5[0].Text;
        XmlNode newChild = xmlNode.SelectSingleNode("trustCertificate");
        if (newChild == null)
        {
          if (empty1.Length <= 0 && empty2.Length <= 0 && empty3.Length <= 0 && str1.Length <= 0 && str2.Length <= 0)
            return true;
          newChild = (XmlNode) doc.CreateElement("trustCertificate");
          xmlNode.AppendChild(newChild);
        }
        XmlNode node1 = newChild.Attributes.GetNamedItem("storeLocation");
        if (node1 == null)
        {
          node1 = (XmlNode) doc.CreateAttribute("storeLocation");
          newChild.Attributes.Append(node1 as XmlAttribute);
        }
        node1.Value = empty1;
        XmlNode node2 = newChild.Attributes.GetNamedItem("storeName");
        if (node2 == null)
        {
          node2 = (XmlNode) doc.CreateAttribute("storeName");
          newChild.Attributes.Append(node2 as XmlAttribute);
        }
        node2.Value = empty2;
        XmlNode node3 = newChild.Attributes.GetNamedItem("findType");
        if (node3 == null)
        {
          node3 = (XmlNode) doc.CreateAttribute("findType");
          newChild.Attributes.Append(node3 as XmlAttribute);
        }
        node3.Value = empty3;
        XmlNode node4 = newChild.Attributes.GetNamedItem("findValue");
        if (node4 == null)
        {
          node4 = (XmlNode) doc.CreateAttribute("findValue");
          newChild.Attributes.Append(node4 as XmlAttribute);
        }
        node4.Value = str1;
        XmlNode node5 = newChild.Attributes.GetNamedItem("description");
        if (node5 == null && str2.Length > 0)
        {
          node5 = (XmlNode) doc.CreateAttribute("description");
          newChild.Attributes.Append(node5 as XmlAttribute);
        }
        if (node5 != null)
          node5.Value = str2;
      }
    }
    catch (Exception ex)
    {
      flag = false;
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_CONFIG_SAVE_ERROR"), Localize.GetString("STR_RC_UNABLE_TO_SAVE_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  public bool CreateKey(
    string keyName,
    string displayName,
    string type,
    List<string> values,
    string category,
    string help)
  {
    bool key = false;
    string strA = this.DoesCategoryExist(category);
    if (string.Compare(strA, "error", StringComparison.OrdinalIgnoreCase) != 0)
    {
      XmlSchema schema = new XmlSchema();
      try
      {
        using (FileStream fileStream = new FileStream(this._adminSchemaPath, FileMode.Open))
        {
          FileStream input = fileStream;
          using (XmlReader reader = XmlReader.Create((Stream) input, new XmlReaderSettings()
          {
            XmlResolver = (XmlResolver) null
          }))
            schema = XmlSchema.Read(reader, (ValidationEventHandler) null);
        }
        if (string.Compare(strA, "false", StringComparison.OrdinalIgnoreCase) == 0)
        {
          XmlSchemaComplexType schemaComplexType = new XmlSchemaComplexType();
          schemaComplexType.Name = category;
          schema.Items.Add((XmlSchemaObject) schemaComplexType);
        }
        XmlSchemaComplexType category1 = this.GetCategory(schema, category);
        XmlSchemaElement xmlSchemaElement = new XmlSchemaElement();
        xmlSchemaElement.Name = keyName;
        xmlSchemaElement.SchemaTypeName = new XmlQualifiedName("xs:" + type);
        if (string.IsNullOrEmpty(displayName))
        {
          xmlSchemaElement.DefaultValue = help;
        }
        else
        {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.Append(displayName);
          stringBuilder.Append(": ");
          stringBuilder.Append(help);
          xmlSchemaElement.DefaultValue = stringBuilder.ToString();
        }
        if (category1.Particle == null)
        {
          XmlSchemaAll xmlSchemaAll = new XmlSchemaAll();
          xmlSchemaAll.Items.Add((XmlSchemaObject) xmlSchemaElement);
          category1.Particle = (XmlSchemaParticle) xmlSchemaAll;
        }
        else
          ((XmlSchemaGroupBase) category1.Particle).Items.Add((XmlSchemaObject) xmlSchemaElement);
        if (string.Compare(type, "other", StringComparison.OrdinalIgnoreCase) == 0)
        {
          XmlSchemaSimpleType customType = this.CreateCustomType(keyName, values);
          schema.Items.Add((XmlSchemaObject) customType);
          xmlSchemaElement.SchemaTypeName = new XmlQualifiedName($"mstns:{keyName}Enum");
        }
        using (StreamWriter writer = new StreamWriter(this._adminSchemaPath))
          schema.Write((TextWriter) writer);
        key = true;
      }
      catch (Exception ex)
      {
        ErrorViewerWriter.Write(ex);
        int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_FROM_SCHEMA"), Localize.GetString("STR_RC_EMBEDDED_XML_SCHEMA_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
    return key;
  }

  public void AddKeyToWebConfig(string keyName, string type)
  {
    XmlDocument docToSave = new XmlDocument();
    try
    {
      string webConfigPath = this._webConfigPath;
      using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        docToSave.Load(reader);
      XmlNode xmlNode = docToSave.SelectSingleNode("configuration/appSettings");
      int i = 0;
      XmlNode childNode;
      for (childNode = xmlNode.ChildNodes[i]; childNode.NodeType != XmlNodeType.Element; childNode = xmlNode.ChildNodes[i])
        ++i;
      XmlNode newChild = childNode.Clone();
      newChild.Attributes["key"].Value = keyName;
      if (string.Compare(type, "int", StringComparison.OrdinalIgnoreCase) == 0)
        newChild.Attributes["value"].Value = Convert.ToString(0);
      else if (string.Compare(type, "boolean", StringComparison.OrdinalIgnoreCase) == 0)
        newChild.Attributes["value"].Value = "true";
      else
        newChild.Attributes["value"].Value = string.Empty;
      xmlNode.AppendChild(newChild);
      XmlEditor.XmlDocumentSaveWithFormatting(docToSave, this._webConfigPath);
    }
    catch (XPathException ex)
    {
      ErrorViewerWriter.Write((Exception) ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_FIND_APPSETTINGS"), Localize.GetString("STR_RC_UNABLE_TO_EDIT_WEB_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_SAVING_WEB_CONFIG"), Localize.GetString("STR_RC_UNABLE_TO_EDIT_WEB_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  public bool RemoveKey(string keyName, string category)
  {
    bool flag = false;
    XmlSchema schema = new XmlSchema();
    try
    {
      using (FileStream fileStream = new FileStream(this._adminSchemaPath, FileMode.Open))
      {
        FileStream input = fileStream;
        using (XmlReader reader = XmlReader.Create((Stream) input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
          schema = XmlSchema.Read(reader, (ValidationEventHandler) null);
      }
      XmlSchemaComplexType category1 = this.GetCategory(schema, category);
      XmlSchemaElement element = this.GetElement(schema, keyName);
      this.RemoveEnum(schema, keyName);
      if (category1 != null && element != null)
        ((XmlSchemaGroupBase) category1.Particle).Items.Remove((XmlSchemaObject) element);
      using (StreamWriter writer = new StreamWriter(this._adminSchemaPath))
        schema.Write((TextWriter) writer);
      flag = true;
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_REMOVE_KEY"), Localize.GetString("STR_RC_ERROR_EDITING_SCHEMA"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return flag;
  }

  public void RemoveKeyFromWebConfig(XmlDocument doc, string keyName)
  {
    XmlNode xmlNode = (XmlNode) null;
    try
    {
      XmlNodeList childNodes = doc.DocumentElement.ChildNodes;
      int count1 = childNodes.Count;
      for (int i = 0; i < count1; ++i)
      {
        if (string.Compare(childNodes[i].Name, "appSettings", StringComparison.OrdinalIgnoreCase) == 0)
        {
          xmlNode = childNodes[i];
          childNodes = xmlNode.ChildNodes;
          break;
        }
      }
      int count2 = childNodes.Count;
      for (int i = 0; i < count2; ++i)
      {
        if (childNodes[i].Attributes != null && childNodes[i].Attributes["key"] != null && string.Compare(childNodes[i].Attributes["key"].Value, keyName, StringComparison.Ordinal) == 0)
        {
          xmlNode.RemoveChild(childNodes[i]);
          break;
        }
      }
      XmlEditor.XmlDocumentSaveWithFormatting(doc, this._webConfigPath);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_REMOVE_KEY"), Localize.GetString("STR_RC_UNABLE_TO_EDIT_WEB_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  public void MoveKey(string keyName, string oldCategory, string newCategory)
  {
    string strA = this.DoesCategoryExist(newCategory);
    if (string.Compare(strA, "error", StringComparison.OrdinalIgnoreCase) == 0)
      return;
    XmlSchema schema = new XmlSchema();
    try
    {
      using (FileStream fileStream = new FileStream(this._adminSchemaPath, FileMode.Open))
      {
        FileStream input = fileStream;
        using (XmlReader reader = XmlReader.Create((Stream) input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
          schema = XmlSchema.Read(reader, (ValidationEventHandler) null);
      }
      if (string.Compare(strA, "false", StringComparison.OrdinalIgnoreCase) == 0)
      {
        XmlSchemaComplexType schemaComplexType = new XmlSchemaComplexType();
        schemaComplexType.Name = newCategory;
        schema.Items.Add((XmlSchemaObject) schemaComplexType);
      }
      XmlSchemaComplexType category1 = this.GetCategory(schema, oldCategory);
      XmlSchemaComplexType category2 = this.GetCategory(schema, newCategory);
      XmlSchemaElement element = this.GetElement(schema, keyName);
      ((XmlSchemaGroupBase) category1.Particle).Items.Remove((XmlSchemaObject) element);
      if (category2.Particle == null)
      {
        XmlSchemaAll xmlSchemaAll = new XmlSchemaAll();
        xmlSchemaAll.Items.Add((XmlSchemaObject) element);
        category2.Particle = (XmlSchemaParticle) xmlSchemaAll;
      }
      else
        ((XmlSchemaGroupBase) category2.Particle).Items.Add((XmlSchemaObject) element);
      using (StreamWriter writer = new StreamWriter(this._adminSchemaPath))
        schema.Write((TextWriter) writer);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_OCCURRED_EDIT_SCHEMA"), Localize.GetString("STR_RC_ERROR_EDITING_SCHEMA"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  public string[] GetKeysFromCategory(string category)
  {
    category = category.Replace(' ', '_');
    List<string> stringList = new List<string>();
    string strA = string.Empty;
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        Stream input = schemaStream;
        using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
        {
          while (xmlReader.Read())
          {
            if (xmlReader.NodeType == XmlNodeType.Element)
            {
              if (string.Compare(xmlReader.Name, "xs:complexType", StringComparison.OrdinalIgnoreCase) == 0)
                strA = xmlReader.GetAttribute("name");
              if (string.Compare(strA, category, StringComparison.Ordinal) == 0 && string.Compare(xmlReader.Name, "xs:element", StringComparison.OrdinalIgnoreCase) == 0)
              {
                string attribute = xmlReader.GetAttribute("name");
                stringList.Add(attribute);
              }
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_FROM_SCHEMA"), Localize.GetString("STR_RC_XML_SCHEMA_DEFINITION_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return stringList.ToArray();
  }

  public string[] GetTabsFromXSD()
  {
    List<string> stringList = new List<string>();
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        Stream input = schemaStream;
        using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
        {
          while (xmlReader.Read())
          {
            if (xmlReader.NodeType == XmlNodeType.Element && string.Compare(xmlReader.Name, "xs:complexType", StringComparison.OrdinalIgnoreCase) == 0)
            {
              string str = xmlReader.GetAttribute("name").Replace("_", " ");
              stringList.Add(str);
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_GET_CATEGORY_NAMES"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return stringList.ToArray();
  }

  private XmlSchemaComplexType GetCategory(XmlSchema schema, string categoryName)
  {
    XmlSchemaComplexType category = (XmlSchemaComplexType) null;
    foreach (XmlSchemaObject xmlSchemaObject in schema.Items)
    {
      if (xmlSchemaObject is XmlSchemaComplexType)
      {
        XmlSchemaComplexType schemaComplexType = (XmlSchemaComplexType) xmlSchemaObject;
        if (string.Compare(schemaComplexType.Name, categoryName, StringComparison.Ordinal) == 0)
        {
          category = schemaComplexType;
          break;
        }
      }
    }
    return category;
  }

  private XmlSchemaElement GetElement(XmlSchema schema, string elementName)
  {
    XmlSchemaElement element = (XmlSchemaElement) null;
    foreach (XmlSchemaObject xmlSchemaObject in schema.Items)
    {
      if (xmlSchemaObject is XmlSchemaComplexType)
      {
        XmlSchemaComplexType schemaComplexType = (XmlSchemaComplexType) xmlSchemaObject;
        if (schemaComplexType.Particle != null)
        {
          foreach (XmlSchemaElement xmlSchemaElement in ((XmlSchemaGroupBase) schemaComplexType.Particle).Items)
          {
            if (string.Compare(xmlSchemaElement.Name, elementName, StringComparison.Ordinal) == 0)
            {
              element = xmlSchemaElement;
              break;
            }
          }
        }
      }
    }
    return element;
  }

  private List<string> ReadLines()
  {
    List<string> stringList = new List<string>();
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        using (StreamReader streamReader = new StreamReader(schemaStream))
        {
          for (string str = streamReader.ReadLine(); str != null; str = streamReader.ReadLine())
            stringList.Add(str);
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_FROM_SCHEMA"), Localize.GetString("STR_RC_XML_SCHEMA_DEFINITION_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return stringList;
  }

  private void RemoveEnum(XmlSchema schema, string enumName)
  {
    XmlSchemaSimpleType schemaSimpleType = (XmlSchemaSimpleType) null;
    List<int> intList = new List<int>();
    foreach (XmlSchemaObject xmlSchemaObject in schema.Items)
    {
      if (schemaSimpleType != null)
      {
        if (xmlSchemaObject is XmlSchemaEnumerationFacet)
          intList.Add(xmlSchemaObject.LineNumber);
        else
          break;
      }
      else if (xmlSchemaObject is XmlSchemaSimpleType)
      {
        schemaSimpleType = (XmlSchemaSimpleType) xmlSchemaObject;
        if (string.Compare(schemaSimpleType.Name, enumName, StringComparison.Ordinal) == 0)
        {
          int lineNumber = xmlSchemaObject.LineNumber;
          intList.Add(lineNumber);
          intList.Add(lineNumber + 1);
        }
        else
          schemaSimpleType = (XmlSchemaSimpleType) null;
      }
    }
    List<string> stringList = this.ReadLines();
    foreach (int num in intList)
      stringList.RemoveAt(num - 1);
    try
    {
      using (StreamWriter streamWriter = new StreamWriter(this._adminSchemaPath))
      {
        foreach (string str in stringList)
          streamWriter.WriteLine(str);
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_REMOVE_ENUM"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  private string DoesCategoryExist(string categoryName)
  {
    string str = "false";
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        Stream input = schemaStream;
        using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
        {
          while (xmlReader.Read())
          {
            if (xmlReader.NodeType == XmlNodeType.Element && string.Compare(xmlReader.Name, "xs:complexType", StringComparison.OrdinalIgnoreCase) == 0 && string.Compare(xmlReader.GetAttribute("name"), categoryName, StringComparison.Ordinal) == 0)
            {
              str = "true";
              break;
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      str = "error";
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_FROM_SCHEMA"), Localize.GetString("STR_RC_XML_SCHEMA_DEFINITION_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return str;
  }

  public XmlAttribute FindKey(XmlNodeList nodes, string keyName)
  {
    XmlAttribute key = (XmlAttribute) null;
    for (int i = 0; i < nodes.Count; ++i)
    {
      XmlNode node = nodes[i];
      if (node.Attributes != null && node.Attributes["key"] != null && string.Compare(node.Attributes["key"].Value, keyName, StringComparison.Ordinal) == 0)
      {
        key = node.Attributes["value"];
        break;
      }
    }
    return key;
  }

  public string GetKeyType(string keyName)
  {
    string keyType = string.Empty;
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        Stream input = schemaStream;
        using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
        {
          while (xmlReader.Read())
          {
            if (xmlReader.NodeType == XmlNodeType.Element && string.Compare(xmlReader.Name, "xs:element", StringComparison.OrdinalIgnoreCase) == 0 && string.Compare(xmlReader.GetAttribute("name"), keyName, StringComparison.OrdinalIgnoreCase) == 0)
            {
              keyType = xmlReader.GetAttribute("type");
              keyType = !keyType.StartsWith("xs:", StringComparison.Ordinal) ? "enumeration" : keyType.Remove(0, 3);
              break;
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_FROM_SCHEMA"), Localize.GetString("STR_RC_UNABLE_TO_GET_KEY_TYPE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return keyType;
  }

  public void ChangeKeyType(string keyName, string newType, List<string> enumVals)
  {
    XmlSchema schema = new XmlSchema();
    try
    {
      using (FileStream fileStream = new FileStream(this._adminSchemaPath, FileMode.Open))
      {
        FileStream input = fileStream;
        using (XmlReader reader = XmlReader.Create((Stream) input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
          schema = XmlSchema.Read(reader, (ValidationEventHandler) null);
      }
      XmlSchemaElement element = this.GetElement(schema, keyName);
      if (string.Compare(newType, "enumeration", StringComparison.OrdinalIgnoreCase) == 0)
      {
        element.SchemaTypeName = new XmlQualifiedName($"mstns:{keyName}Enum");
        XmlSchemaSimpleType customType = this.CreateCustomType(keyName, enumVals);
        schema.Items.Add((XmlSchemaObject) customType);
      }
      else
        element.SchemaTypeName = new XmlQualifiedName("xs:" + newType);
      using (StreamWriter writer = new StreamWriter(this._adminSchemaPath))
        schema.Write((TextWriter) writer);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_STR_RC_UNABLE_TO_UPDATE_SCHEMA"), Localize.GetString("STR_RC_UNABLE_TO_UPDATE_KEY_TYPE"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  private XmlSchemaSimpleType CreateCustomType(string keyName, List<string> values)
  {
    XmlSchemaSimpleType customType = new XmlSchemaSimpleType();
    customType.Name = keyName + "Enum";
    XmlSchemaSimpleTypeRestriction simpleTypeRestriction = new XmlSchemaSimpleTypeRestriction();
    simpleTypeRestriction.BaseTypeName = new XmlQualifiedName("xs:string");
    int count = values.Count;
    for (int index = 0; index < count; ++index)
    {
      XmlSchemaEnumerationFacet enumerationFacet = new XmlSchemaEnumerationFacet();
      enumerationFacet.Value = values[index];
      simpleTypeRestriction.Facets.Add((XmlSchemaObject) enumerationFacet);
    }
    customType.Content = (XmlSchemaSimpleTypeContent) simpleTypeRestriction;
    return customType;
  }

  public void ExportKeys(string savePath, TabControl tabControl)
  {
    XmlDocument xmlDocument = new XmlDocument();
    try
    {
      XmlElement element1 = xmlDocument.CreateElement("configuration");
      xmlDocument.AppendChild((XmlNode) element1);
      XmlElement element2 = xmlDocument.CreateElement("appSettings");
      element1.AppendChild((XmlNode) element2);
      XmlNodeList childNodes = xmlDocument.GetElementsByTagName("appSettings")[0].ChildNodes;
      this.LoopThroughTabs(xmlDocument, childNodes, tabControl.TabPages, false);
      this.SaveServiceClientType(xmlDocument, tabControl, true);
      this.SaveServerURL(xmlDocument, tabControl, true);
      this.SaveServiceLocations_ServicePath(xmlDocument, tabControl, true);
      this.SaveServiceLocations_DataSource(xmlDocument, tabControl, true);
      this.SaveHylandTracing(xmlDocument, tabControl, true);
      this.SaveSessionStateTimeout(xmlDocument, tabControl, true);
      this.SaveSessionStateSameSiteCookie(xmlDocument, tabControl, true);
      this.SaveRequestTimeout(xmlDocument, tabControl, true);
      this.SaveExecutionTimeout(xmlDocument, tabControl, true);
      this.SaveMaxRequestLength(xmlDocument, tabControl, true);
      this.SaveMaxAllowedContentLength(xmlDocument, tabControl, true);
      this.SaveWOPISettings(xmlDocument, tabControl, true);
      XmlEditor.XmlDocumentSaveWithFormatting(xmlDocument, savePath);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_EXPORTING_KEYS"), Localize.GetString("STR_RC_WAMCON_EXPORT_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  public double GetAdminConsoleVersion()
  {
    double result = -1.0;
    string appSetting = ConfigurationManager.AppSettings["version"];
    try
    {
      string decimalSeparator = CultureInfo.CurrentCulture.NumberFormat.PercentDecimalSeparator;
      if (!double.TryParse(appSetting.Replace(".", decimalSeparator), out result))
      {
        int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_GET_WAMCON_VERSION"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_READ_CULTURE_SETTINGS"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return result;
  }

  public double GetSchemaVersion()
  {
    double result = -1.0;
    string empty = string.Empty;
    XmlSchema xmlSchema = new XmlSchema();
    try
    {
      using (Stream schemaStream = this._assembly.GetSchemaStream())
      {
        Stream input = schemaStream;
        using (XmlReader reader = XmlReader.Create(input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
          xmlSchema = XmlSchema.Read(reader, (ValidationEventHandler) null);
      }
      if (!double.TryParse(xmlSchema.Version.Replace(".", CultureInfo.CurrentCulture.NumberFormat.PercentDecimalSeparator), out result))
      {
        int num = (int) MessageBox.Show(Localize.GetString("STR_RC_SCHEMA_VERSION_IMPROPERLY_FORMATTED"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_ERROR_READING_SCHEMA_VERSION"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return result;
  }

  public void CopyCustomBlocks(string importFilePath)
  {
    XmlDocument docToSave = new XmlDocument();
    string webConfigPath = this._webConfigPath;
    using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
    {
      XmlResolver = (XmlResolver) null
    }))
      docToSave.Load(reader);
    XmlDocument xmlDocument = new XmlDocument();
    string inputUri = importFilePath;
    using (XmlReader reader = XmlReader.Create(inputUri, new XmlReaderSettings()
    {
      XmlResolver = (XmlResolver) null
    }))
      xmlDocument.Load(reader);
    XmlNode xmlNode = docToSave.SelectSingleNode("configuration");
    foreach (CustomConfigSection customSection in this._customSections)
    {
      XmlNode oldChild = docToSave.SelectSingleNode("configuration/" + customSection.Type);
      XmlNode node = xmlDocument.SelectSingleNode("configuration/" + customSection.Type);
      if (oldChild != null && node != null)
      {
        XmlNode newChild = docToSave.ImportNode(node, true);
        xmlNode.ReplaceChild(newChild, oldChild);
      }
    }
    XmlEditor.XmlDocumentSaveWithFormatting(docToSave, this._webConfigPath);
  }

  public bool DoProtectedKeysExist()
  {
    bool flag = false;
    using (Stream schemaStream = this._assembly.GetSchemaStream())
    {
      Stream input = schemaStream;
      using (XmlReader xmlReader = XmlReader.Create(input, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
      {
        while (xmlReader.Read())
        {
          if (xmlReader.NodeType == XmlNodeType.Element)
          {
            string attribute = xmlReader.GetAttribute("name");
            if (!string.IsNullOrEmpty(attribute) && attribute.Contains("protected"))
            {
              flag = true;
              break;
            }
          }
        }
      }
    }
    return flag;
  }

  public List<ThemePart> GetThemeParts(string templateFilePath)
  {
    List<ThemePart> themeParts = new List<ThemePart>();
    try
    {
      using (FileStream fileStream = File.OpenRead(templateFilePath))
      {
        FileStream input = fileStream;
        using (XmlReader xmlReader = XmlReader.Create((Stream) input, new XmlReaderSettings()
        {
          XmlResolver = (XmlResolver) null
        }))
        {
          while (xmlReader.Read())
          {
            if (xmlReader.NodeType == XmlNodeType.Element && string.Compare(xmlReader.Name, "ThemePart", StringComparison.OrdinalIgnoreCase) == 0)
            {
              try
              {
                ThemePartType type = (ThemePartType) Enum.Parse(typeof (ThemePartType), xmlReader.GetAttribute("type"), true);
                string attribute1 = xmlReader.GetAttribute("name");
                if (!string.IsNullOrEmpty(attribute1))
                  attribute1 = Localize.GetString(attribute1);
                string attribute2 = xmlReader.GetAttribute("group");
                if (!string.IsNullOrEmpty(attribute2))
                  attribute2 = Localize.GetString(attribute2);
                string attribute3 = xmlReader.GetAttribute("selector");
                string attribute4 = xmlReader.GetAttribute("value");
                CSSPropertyName cssProperty = (CSSPropertyName) Enum.Parse(typeof (CSSPropertyName), xmlReader.GetAttribute("property").Replace("-", ""), true);
                ThemePart themePart = new ThemePart(type, attribute1, attribute2, attribute3, cssProperty, attribute4);
                string attribute5 = xmlReader.GetAttribute("advancedSelector");
                if (!string.IsNullOrEmpty(attribute5))
                  themePart.AdvancedSelector = attribute5;
                string attribute6 = xmlReader.GetAttribute("basicPart");
                if (!string.IsNullOrEmpty(attribute6))
                {
                  ThemePartType themePartType = (ThemePartType) Enum.Parse(typeof (ThemePartType), attribute6, true);
                  themePart.BasicPart = new ThemePartType?(themePartType);
                }
                string attribute7 = xmlReader.GetAttribute("advancedTypes");
                if (!string.IsNullOrEmpty(attribute7))
                {
                  string[] separator = new string[1]{ "," };
                  string[] strArray = attribute7.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                  List<ThemePartType> themePartTypeList = new List<ThemePartType>();
                  foreach (string str in strArray)
                  {
                    ThemePartType result;
                    if (Enum.TryParse<ThemePartType>(str, true, out result))
                      themePartTypeList.Add(result);
                  }
                  themePart.AdvancedTypes = themePartTypeList;
                }
                themeParts.Add(themePart);
              }
              catch (Exception ex)
              {
                ErrorViewerWriter.Write(ex);
              }
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_FAILED_TO_READ_TEMPLATE"), Localize.GetString("STR_RC_ERROR"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
      ErrorViewerWriter.Write(ex);
    }
    return themeParts;
  }

  public string CreateHylandIdPUrl(Control.ControlCollection controls)
  {
    string hylandIdPurl = string.Empty;
    foreach (Control control1 in (ArrangedElementCollection) controls)
    {
      foreach (Control control2 in (ArrangedElementCollection) control1.Controls)
      {
        if (control2 is TextBox && control2.Text != string.Empty)
          hylandIdPurl = $"{hylandIdPurl}{control2.Text};";
      }
    }
    if (hylandIdPurl.Length > 0)
      hylandIdPurl = hylandIdPurl.Remove(hylandIdPurl.Length - 1);
    return hylandIdPurl;
  }

  private string GetIDAttribute(XmlNode node)
  {
    string empty = string.Empty;
    XmlAttribute attribute = node.Attributes["ID"];
    if (attribute != null)
      empty = attribute.Value;
    return empty;
  }

  public List<RequiredKeywordItem> GetRequiredKeywords()
  {
    XmlDocument xmlDocument = new XmlDocument();
    List<RequiredKeywordItem> requiredKeywords = new List<RequiredKeywordItem>();
    try
    {
      string webConfigPath = this._webConfigPath;
      using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        xmlDocument.Load(reader);
      XmlNode xmlNode = xmlDocument.SelectSingleNode("configuration/RequiredKeywords");
      if (xmlNode != null)
      {
        int count1 = xmlNode.ChildNodes.Count;
        for (int i1 = 0; i1 < count1; ++i1)
        {
          XmlNode childNode = xmlNode.ChildNodes[i1];
          if (string.Compare(childNode.Name, "Query", StringComparison.OrdinalIgnoreCase) == 0)
          {
            string idAttribute1 = this.GetIDAttribute(childNode);
            long result = 0;
            if (long.TryParse(idAttribute1, out result) || string.Compare(idAttribute1, "*", StringComparison.OrdinalIgnoreCase) == 0)
            {
              XmlNodeList childNodes = childNode.ChildNodes;
              int count2 = childNodes.Count;
              for (int i2 = 0; i2 < count2; ++i2)
              {
                XmlNode node = childNodes[i2];
                if (string.Compare(node.Name, "Keyword", StringComparison.OrdinalIgnoreCase) == 0)
                {
                  string idAttribute2 = this.GetIDAttribute(node);
                  if (long.TryParse(idAttribute2, out result))
                  {
                    RequiredKeywordItem requiredKeywordItem = new RequiredKeywordItem(idAttribute1, idAttribute2);
                    requiredKeywords.Add(requiredKeywordItem);
                  }
                }
              }
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_READ_REQ_KEYWORDS"), Localize.GetString("STR_RC_ERROR_READING_FROM_WEBCONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return requiredKeywords;
  }

  public void SaveRequiredKeywords(
    List<RequiredKeywordItem> keysToAdd,
    List<RequiredKeywordItem> keysToRemove)
  {
    XmlDocument xmlDocument = new XmlDocument();
    try
    {
      string webConfigPath = this._webConfigPath;
      using (XmlReader reader = XmlReader.Create(webConfigPath, new XmlReaderSettings()
      {
        XmlResolver = (XmlResolver) null
      }))
        xmlDocument.Load(reader);
      foreach (RequiredKeywordItem requiredKeywordItem in keysToAdd)
        xmlDocument = this.AddRequiredKeyword(xmlDocument, requiredKeywordItem.QueryID, requiredKeywordItem.KeywordID);
      foreach (RequiredKeywordItem requiredKeywordItem in keysToRemove)
        xmlDocument = this.RemoveRequiredKeyword(xmlDocument, requiredKeywordItem.QueryID, requiredKeywordItem.KeywordID);
      XmlEditor.XmlDocumentSaveWithFormatting(xmlDocument, this._webConfigPath);
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_UPDATE_REQ_KEYWORDS"), Localize.GetString("STR_RC_UNABLE_TO_SAVE_CONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
  }

  private XmlDocument AddRequiredKeyword(XmlDocument doc, string queryID, string keywordID)
  {
    XmlNode node = doc.SelectSingleNode("configuration/RequiredKeywords");
    if (node != null)
    {
      XmlNode reqKeywordNode = this.FindReqKeywordNode(node, "Query", queryID);
      XmlElement element1 = doc.CreateElement("Keyword");
      XmlAttribute attribute1 = doc.CreateAttribute("ID");
      attribute1.Value = keywordID;
      element1.Attributes.Append(attribute1);
      if (reqKeywordNode == null)
      {
        XmlNode element2 = (XmlNode) doc.CreateElement("Query");
        XmlAttribute attribute2 = doc.CreateAttribute("ID");
        attribute2.Value = queryID;
        element2.Attributes.Append(attribute2);
        element2.AppendChild((XmlNode) element1);
        node.AppendChild(element2);
      }
      else
        reqKeywordNode.AppendChild((XmlNode) element1);
    }
    return doc;
  }

  private XmlDocument RemoveRequiredKeyword(XmlDocument doc, string queryID, string keywordID)
  {
    XmlNode node = doc.SelectSingleNode("configuration/RequiredKeywords");
    if (node != null)
    {
      XmlNode reqKeywordNode1 = this.FindReqKeywordNode(node, "Query", queryID);
      if (reqKeywordNode1 != null)
      {
        XmlNode reqKeywordNode2 = this.FindReqKeywordNode(reqKeywordNode1, "Keyword", keywordID);
        reqKeywordNode1.RemoveChild(reqKeywordNode2);
      }
    }
    return doc;
  }

  private XmlNode FindReqKeywordNode(XmlNode node, string nodeType, string nodeID)
  {
    XmlNode reqKeywordNode = (XmlNode) null;
    try
    {
      if (node != null)
      {
        int count = node.ChildNodes.Count;
        for (int i = 0; i < count; ++i)
        {
          XmlNode childNode = node.ChildNodes[i];
          if (string.Compare(childNode.Name, nodeType, StringComparison.OrdinalIgnoreCase) == 0)
          {
            string idAttribute = this.GetIDAttribute(childNode);
            if (string.Compare(nodeID, idAttribute, StringComparison.CurrentCulture) == 0)
            {
              reqKeywordNode = childNode;
              break;
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
      int num = (int) MessageBox.Show(Localize.GetString("STR_RC_UNABLE_TO_READ_REQ_KEYWORDS"), Localize.GetString("STR_RC_ERROR_READING_FROM_WEBCONFIG"), MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    return reqKeywordNode;
  }

  public static void XmlDocumentSaveWithFormatting(XmlDocument docToSave, string filePath)
  {
    using (XmlWriter w = XmlWriter.Create(filePath, new XmlWriterSettings()
    {
      Indent = true,
      IndentChars = "\t"
    }))
      docToSave.Save(w);
  }
}
