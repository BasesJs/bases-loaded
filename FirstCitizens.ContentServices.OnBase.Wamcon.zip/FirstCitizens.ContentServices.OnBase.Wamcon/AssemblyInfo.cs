﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCopyright("Copyright © 1992 - 2025 Hyland Software, Inc.")]
[assembly: AssemblyCompany("Hyland Software, Inc.")]
[assembly: AssemblyFileVersion("25.1.2.1000")]
[assembly: AssemblyInformationalVersion("25.1.2.1000")]
[assembly: AssemblyTitle("AdminConsole")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("AdminConsole")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("86c0f4f0-2847-423e-a47d-f081878c12db")]
[assembly: AssemblyVersion("25.1.2.1000")]
