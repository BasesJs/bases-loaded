﻿// Decompiled with JetBrains decompiler
// Type: FirstCitizens.ContentServices.OnBase.Wamcon.ApplicationPoolCollection
// Assembly: WebApplicationManagementConsole, Version=25.1.2.1000, Culture=neutral, PublicKeyToken=null
// MVID: E12C454C-A807-4890-B0D3-E1DEC2961811
// Assembly location: C:\Users\jacob\OpenCloud\Code\Web Applications Management Console\WebApplicationManagementConsole.exe

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class ApplicationPoolCollection : CollectionBase<ApplicationPool>
{
  internal ApplicationPoolCollection(ServerManager serverManager)
    : base(serverManager)
  {
  }
}
