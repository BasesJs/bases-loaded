﻿using System;
using System.DirectoryServices;
using Microsoft.Web.Administration;


namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class ApplicationPool : IDisposable
{
  private string _name;
  private ServerManager _serverManager;
  private LateBinding.ServerManager _microsoftServerManager;
  private DirectoryEntry _directoryEntry;
  private DirectoryEntry _directoryEntryParent;

  internal ApplicationPool(ServerManager serverManager, string name)
  {
    this._name = name;
    this._serverManager = serverManager;
    this._microsoftServerManager = this._serverManager.MicrosoftServerManager;
  }

  internal DirectoryEntry DirectoryEntry => this._directoryEntry;

  public string Name => this._name;

  public bool Enable32BitAppOnWin64
  {
    get
    {
      bool enable32BitAppOnWin64 = false;
      if (IntPtr.Size != 4 && this._microsoftServerManager.ApplicationPools[this._name].Enable32BitAppOnWin64)
        enable32BitAppOnWin64 = true;
      return enable32BitAppOnWin64;
    }
    set
    {
      if (IntPtr.Size == 4)
        return;
      this._microsoftServerManager.ApplicationPools[this._name].Enable32BitAppOnWin64 = value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public long QueueLength
  {
    get => this._microsoftServerManager.ApplicationPools[this._name].QueueLength;
    set
    {
      this._microsoftServerManager.ApplicationPools[this._name].QueueLength = value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public int IdleTimeOut
  {
    get
    {
      return (int) this._microsoftServerManager.ApplicationPools[this._name].ProcessModel.IdleTimeout.TotalMinutes;
    }
    set
    {
      this._microsoftServerManager.ApplicationPools[this._name].ProcessModel.IdleTimeout = new TimeSpan(0, value, 0);
      this._microsoftServerManager.CommitChanges();
    }
  }

  public int PeriodicRestartTime
  {
    get
    {
      return (int) this._microsoftServerManager.ApplicationPools[this._name].Recycling.PeriodicRestart.Time.TotalMinutes;
    }
    set
    {
      this._microsoftServerManager.ApplicationPools[this._name].Recycling.PeriodicRestart.Time = new TimeSpan(0, value, 0);
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool PingingEnabled
  {
    get => this._microsoftServerManager.ApplicationPools[this._name].ProcessModel.PingingEnabled;
    set
    {
      this._microsoftServerManager.ApplicationPools[this._name].ProcessModel.PingingEnabled = value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public bool RapidFailProtection
  {
    get => this._microsoftServerManager.ApplicationPools[this._name].Failure.RapidFailProtection;
    set
    {
      this._microsoftServerManager.ApplicationPools[this._name].Failure.RapidFailProtection = value;
      this._microsoftServerManager.CommitChanges();
    }
  }

  public void Dispose()
  {
    if (this._directoryEntry != null)
    {
      this._directoryEntry.Dispose();
      this._directoryEntry = (DirectoryEntry) null;
    }
    if (this._directoryEntryParent == null)
      return;
    this._directoryEntryParent.Dispose();
    this._directoryEntryParent = (DirectoryEntry) null;
  }

  public override string ToString() => $"Name = {this._name}";
}
