﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.IdentityProvider;

public class IdpTenant
{
  public string Name { get; set; }

  public string Root { get; set; }

  public List<IdpUserPopulation> Populations { get; set; }

  public IdpTenant()
  {
    this.Name = string.Empty;
    this.Root = string.Empty;
    this.Populations = new List<IdpUserPopulation>();
  }

  public override string ToString() => this.Name;

  public void LoadFromXML(XmlNode node)
  {
    this.ReadTenantName(node);
    this.ReadTenantRoot(node);
  }

  private void ReadTenantName(XmlNode node)
  {
    this.Name = (node.Attributes.GetNamedItem("name") ?? throw new Exception("name attribute is required for tenant")).Value;
  }

  private void ReadTenantRoot(XmlNode node)
  {
    XmlNode namedItem = node.Attributes.GetNamedItem("root");
    if (namedItem != null)
      this.Root = namedItem.Value;
    else
      this.Root = string.Empty;
  }
}
