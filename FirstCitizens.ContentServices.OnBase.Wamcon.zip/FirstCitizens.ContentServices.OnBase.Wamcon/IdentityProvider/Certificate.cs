﻿
using System;
using System.Security.Cryptography.X509Certificates;
using System.Xml;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.IdentityProvider;

public class Certificate
{
  public StoreLocation StoreLocation { get; set; }

  public StoreName StoreName { get; set; }

  public X509FindType FindType { get; set; }

  public string FindValue { get; set; }

  public string Description { get; set; }

  public Certificate()
  {
    this.StoreLocation = StoreLocation.CurrentUser;
    this.StoreName = StoreName.TrustedPeople;
    this.FindType = X509FindType.FindByThumbprint;
    this.FindValue = string.Empty;
    this.Description = string.Empty;
  }

  public override string ToString()
  {
    return this.Description.Length > 0 ? this.Description : $"<{Localize.GetString("STR_RC_BLANK")}>";
  }

  public void LoadFromXML(XmlNode node)
  {
    XmlNode namedItem1 = node.Attributes.GetNamedItem("storeLocation");
    StoreLocation result1;
    if (namedItem1 != null && Enum.TryParse<StoreLocation>(namedItem1.Value, out result1))
      this.StoreLocation = result1;
    XmlNode namedItem2 = node.Attributes.GetNamedItem("storeName");
    StoreName result2;
    if (namedItem2 != null && Enum.TryParse<StoreName>(namedItem2.Value, out result2))
      this.StoreName = result2;
    XmlNode namedItem3 = node.Attributes.GetNamedItem("findType");
    X509FindType result3;
    if (namedItem3 != null && Enum.TryParse<X509FindType>(namedItem3.Value, out result3))
      this.FindType = result3;
    XmlNode namedItem4 = node.Attributes.GetNamedItem("findValue");
    if (namedItem4 != null)
      this.FindValue = namedItem4.Value;
    XmlNode namedItem5 = node.Attributes.GetNamedItem("description");
    if (namedItem5 == null)
      return;
    this.Description = namedItem5.Value;
  }
}
