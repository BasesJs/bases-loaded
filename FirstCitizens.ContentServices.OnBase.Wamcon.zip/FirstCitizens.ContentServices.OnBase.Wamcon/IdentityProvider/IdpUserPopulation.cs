﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel.Security;
using System.Xml;

namespace FirstCitizens.ContentServices.OnBase.Wamcon.IdentityProvider;

public class IdpUserPopulation
{
  public string Name { get; set; }

  public string AppServer { get; set; }

  public string DataSource { get; set; }

  public bool StripDomain { get; set; }

  public string ProviderName { get; set; }

  public IdpUserPopulation.ProviderMethodType Provider { get; set; }

  public IdpUserPopulation.CallbackFilterMode CallbackMode { get; set; }

  public List<string> CallbackURLs { get; set; }

  public IdpUserPopulation.UserGroupSyncMethodType UserGroupSyncMethod { get; set; }

  public IdpUserPopulation.DirectoryServiceAttributeType DirectoryService { get; set; }

  public string CASServerURL { get; set; }

  public string UserNameClaimType { get; set; }

  public string RealNameClaimType { get; set; }

  public string RoleClaimType { get; set; }

  public string EmailClaimType { get; set; }

  public string MetadataURL { get; set; }

  public X509CertificateValidationMode ValidationMode { get; set; }

  public X509RevocationMode RevocationMode { get; set; }

  public Certificate SigningCertificate { get; set; }

  public Certificate EncryptionCertificate { get; set; }

  public bool SplashScreen { get; set; }

  public string SplashScreenPage { get; set; }

  public bool SplashScreenCached { get; set; }

  public long SplashExpireTime { get; set; }

  public IdpUserPopulation()
  {
    this.Name = string.Empty;
    this.AppServer = string.Empty;
    this.DataSource = string.Empty;
    this.StripDomain = false;
    this.ProviderName = string.Empty;
    this.Provider = IdpUserPopulation.ProviderMethodType.Normal;
    this.CallbackMode = IdpUserPopulation.CallbackFilterMode.Whitelist;
    this.CallbackURLs = new List<string>();
    this.UserGroupSyncMethod = IdpUserPopulation.UserGroupSyncMethodType.None;
    this.DirectoryService = IdpUserPopulation.DirectoryServiceAttributeType.SAMAccountName;
    this.CASServerURL = string.Empty;
    this.UserNameClaimType = string.Empty;
    this.RealNameClaimType = string.Empty;
    this.RoleClaimType = string.Empty;
    this.EmailClaimType = string.Empty;
    this.MetadataURL = string.Empty;
    this.ValidationMode = X509CertificateValidationMode.ChainTrust;
    this.RevocationMode = X509RevocationMode.Online;
    this.SigningCertificate = new Certificate();
    this.EncryptionCertificate = new Certificate();
    this.SplashScreen = false;
    this.SplashScreenPage = string.Empty;
    this.SplashScreenCached = false;
    this.SplashExpireTime = 5L;
  }

  public override string ToString() => this.Name;

  public void LoadFromXML(XmlNode node)
  {
    this.ReadUserPopName(node);
    this.ReadAppServer(node);
    this.ReadDataSource(node);
    this.ReadProviderNode(node);
    this.ReadCallbackFilterNode(node);
    this.ReadUsageTermsNode(node);
  }

  private void ReadUserPopName(XmlNode node)
  {
    this.Name = (node.Attributes.GetNamedItem("name") ?? throw new Exception("name attribute is required for user population")).Value;
  }

  private void ReadAppServer(XmlNode node)
  {
    this.AppServer = (node.Attributes.GetNamedItem("appServer") ?? throw new Exception("appServer attribute is required for user population")).Value;
  }

  private void ReadDataSource(XmlNode node)
  {
    this.DataSource = (node.Attributes.GetNamedItem("dsn") ?? throw new Exception("dsn attribute is required for user population")).Value;
  }

  private void ReadProviderNode(XmlNode node)
  {
    XmlNode providerNode = node.SelectSingleNode("providers/provider");
    if (providerNode == null)
      return;
    this.ProviderName = (providerNode.Attributes.GetNamedItem("name") ?? throw new Exception("name attribute is required for provider")).Value;
    XmlNode namedItem = providerNode.Attributes.GetNamedItem("method");
    if (namedItem == null)
      throw new Exception("method attribute is required for provider");
    IdpUserPopulation.ProviderMethodType result;
    if (!Enum.TryParse<IdpUserPopulation.ProviderMethodType>(namedItem.Value, out result))
      throw new Exception("invalid provider method");
    this.Provider = result;
    this.ReadSettingsNode(providerNode);
    if (this.Provider == IdpUserPopulation.ProviderMethodType.Cas)
      this.ReadCASSettings(providerNode);
    else if (this.Provider == IdpUserPopulation.ProviderMethodType.Saml)
      this.ReadSAMLSettings(providerNode);
    else if (this.Provider == IdpUserPopulation.ProviderMethodType.WsFederation)
      this.ReadWSFedSettings(providerNode);
  }

  private void ReadSettingsNode(XmlNode providerNode)
  {
    XmlNode xmlNode1 = providerNode.SelectSingleNode("settings");
    if (xmlNode1 == null)
      return;
    XmlNode xmlNode2 = xmlNode1.SelectSingleNode("add[@name='stripDomainFromUsername']");
    if (xmlNode2 != null)
    {
      XmlNode namedItem = xmlNode2.Attributes.GetNamedItem("value");
      if (namedItem != null)
      {
        bool result = false;
        if (bool.TryParse(namedItem.Value, out result))
          this.StripDomain = result;
      }
    }
    XmlNode xmlNode3 = xmlNode1.SelectSingleNode("add[@name='usergroupSyncMethod']");
    if (xmlNode3 != null)
    {
      XmlNode namedItem = xmlNode3.Attributes.GetNamedItem("value");
      IdpUserPopulation.UserGroupSyncMethodType result;
      if (namedItem != null && Enum.TryParse<IdpUserPopulation.UserGroupSyncMethodType>(namedItem.Value.ToString(), out result))
        this.UserGroupSyncMethod = result;
    }
    XmlNode xmlNode4 = xmlNode1.SelectSingleNode("add[@name='directoryServiceAttribute']");
    if (xmlNode4 != null)
    {
      XmlNode namedItem = xmlNode4.Attributes.GetNamedItem("value");
      IdpUserPopulation.DirectoryServiceAttributeType result;
      if (namedItem != null && Enum.TryParse<IdpUserPopulation.DirectoryServiceAttributeType>(namedItem.Value.ToString(), out result))
        this.DirectoryService = result;
    }
    XmlNode xmlNode5 = xmlNode1.SelectSingleNode("add[@name='usernameClaimType']");
    if (xmlNode5 != null)
    {
      XmlNode namedItem = xmlNode5.Attributes.GetNamedItem("value");
      if (namedItem != null)
        this.UserNameClaimType = namedItem.Value;
    }
    XmlNode xmlNode6 = xmlNode1.SelectSingleNode("add[@name='realnameClaimType']");
    if (xmlNode6 != null)
    {
      XmlNode namedItem = xmlNode6.Attributes.GetNamedItem("value");
      if (namedItem != null)
        this.RealNameClaimType = namedItem.Value;
    }
    XmlNode xmlNode7 = xmlNode1.SelectSingleNode("add[@name='roleClaimType']");
    if (xmlNode7 != null)
    {
      XmlNode namedItem = xmlNode7.Attributes.GetNamedItem("value");
      if (namedItem != null)
        this.RoleClaimType = namedItem.Value;
    }
    XmlNode xmlNode8 = xmlNode1.SelectSingleNode("add[@name='emailClaimType']");
    if (xmlNode8 != null)
    {
      XmlNode namedItem = xmlNode8.Attributes.GetNamedItem("value");
      if (namedItem != null)
        this.EmailClaimType = namedItem.Value;
    }
  }

  private void ReadCASSettings(XmlNode providerNode)
  {
    XmlNode namedItem = providerNode.Attributes.GetNamedItem("casBaseUrl");
    if (namedItem == null)
      return;
    this.CASServerURL = namedItem.Value;
  }

  private void ReadSAMLSettings(XmlNode providerNode)
  {
    XmlNode xmlNode1 = providerNode.SelectSingleNode("certificateValidation");
    if (xmlNode1 != null)
    {
      XmlNode namedItem1 = xmlNode1.Attributes.GetNamedItem("validationMode");
      X509CertificateValidationMode result1;
      if (namedItem1 != null && Enum.TryParse<X509CertificateValidationMode>(namedItem1.Value, out result1))
        this.ValidationMode = result1;
      XmlNode namedItem2 = xmlNode1.Attributes.GetNamedItem("revocationMode");
      X509RevocationMode result2;
      if (namedItem2 != null && Enum.TryParse<X509RevocationMode>(namedItem2.Value, out result2))
        this.RevocationMode = result2;
    }
    XmlNode xmlNode2 = providerNode.SelectSingleNode("serviceProvider");
    if (xmlNode2 != null)
    {
      XmlNode certificateNode1 = xmlNode2.SelectSingleNode("signingCertificate");
      if (certificateNode1 != null)
      {
        this.SigningCertificate = new Certificate();
        this.ReadCertificate(certificateNode1, this.SigningCertificate);
      }
      XmlNode certificateNode2 = xmlNode2.SelectSingleNode("encryptionCertificate");
      if (certificateNode2 != null)
      {
        this.EncryptionCertificate = new Certificate();
        this.ReadCertificate(certificateNode2, this.EncryptionCertificate);
      }
    }
    XmlNode xmlNode3 = providerNode.SelectSingleNode("identityProvider/metadata");
    if (xmlNode3 == null)
      return;
    XmlNode namedItem = xmlNode3.Attributes.GetNamedItem("url");
    if (namedItem != null)
      this.MetadataURL = namedItem.Value;
  }

  private void ReadCertificate(XmlNode certificateNode, Certificate cert)
  {
    XmlNode namedItem1 = certificateNode.Attributes.GetNamedItem("storeLocation");
    StoreLocation result1;
    if (namedItem1 != null && Enum.TryParse<StoreLocation>(namedItem1.Value, out result1))
      cert.StoreLocation = result1;
    XmlNode namedItem2 = certificateNode.Attributes.GetNamedItem("storeName");
    StoreName result2;
    if (namedItem2 != null && Enum.TryParse<StoreName>(namedItem2.Value, out result2))
      cert.StoreName = result2;
    XmlNode namedItem3 = certificateNode.Attributes.GetNamedItem("findValue");
    if (namedItem3 == null)
      return;
    cert.FindValue = namedItem3.Value;
  }

  private void ReadWSFedSettings(XmlNode providerNode)
  {
    XmlNode xmlNode = providerNode.SelectSingleNode("metadata");
    if (xmlNode == null)
      return;
    XmlNode namedItem = xmlNode.Attributes.GetNamedItem("url");
    if (namedItem != null)
      this.MetadataURL = namedItem.Value;
  }

  private void ReadCallbackFilterNode(XmlNode node)
  {
    XmlNode xmlNode = node.SelectSingleNode("callbackFilter");
    if (xmlNode == null)
      return;
    XmlNode namedItem1 = xmlNode.Attributes.GetNamedItem("mode");
    IdpUserPopulation.CallbackFilterMode result;
    if (namedItem1 != null && Enum.TryParse<IdpUserPopulation.CallbackFilterMode>(namedItem1.Value, out result))
      this.CallbackMode = result;
    foreach (XmlNode childNode in xmlNode.ChildNodes)
    {
      if (childNode.Name.Equals("add", StringComparison.OrdinalIgnoreCase))
      {
        XmlNode namedItem2 = childNode.Attributes.GetNamedItem("url");
        if (namedItem2 != null)
          this.CallbackURLs.Add(namedItem2.Value);
      }
    }
  }

  private void ReadUsageTermsNode(XmlNode node)
  {
    XmlNode xmlNode = node.SelectSingleNode("usageTerms");
    if (xmlNode == null)
      return;
    XmlNode namedItem1 = xmlNode.Attributes.GetNamedItem("required");
    if (namedItem1 != null && string.Compare(namedItem1.Value, "true", StringComparison.OrdinalIgnoreCase) == 0)
    {
      this.SplashScreen = true;
      XmlNode namedItem2 = xmlNode.Attributes.GetNamedItem("location");
      if (namedItem2 != null)
        this.SplashScreenPage = namedItem2.Value;
      XmlNode namedItem3 = xmlNode.Attributes.GetNamedItem("cache");
      if (namedItem3 != null)
      {
        bool result = true;
        if (bool.TryParse(namedItem3.Value, out result))
          this.SplashScreenCached = result;
      }
      XmlNode namedItem4 = xmlNode.Attributes.GetNamedItem("expireTime");
      if (namedItem4 != null)
      {
        long result = 5;
        if (long.TryParse(namedItem4.Value, out result))
          this.SplashExpireTime = result;
      }
    }
  }

  public enum ProviderMethodType
  {
    Normal,
    DirectoryService,
    CommonAccessCard,
    PersonalIdentityVerification,
    Cas,
    Saml,
    WsFederation,
  }

  public enum CallbackFilterMode
  {
    Whitelist,
    Off,
  }

  public enum UserGroupSyncMethodType
  {
    None,
    ConfiguredDirectoryService,
  }

  public enum DirectoryServiceAttributeType
  {
    SAMAccountName,
    UserPrincipalName,
  }
}
