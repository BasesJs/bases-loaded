﻿using Microsoft.Win32;
using System.Collections;
using System.DirectoryServices;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

internal class IISUtilities : IDisposable
{
  private static ServerManager serverManager;
  private static DirectoryEntry iisService;

  public void Dispose()
  {
    if (IISUtilities.serverManager != null)
    {
      IISUtilities.serverManager.Dispose();
      IISUtilities.serverManager = (ServerManager) null;
    }
    if (IISUtilities.iisService == null)
      return;
    IISUtilities.iisService.Dispose();
    IISUtilities.iisService = (DirectoryEntry) null;
  }

  public static List<ApplicationConfiguration> GetVirtualDirs()
  {
    string machineName = Environment.MachineName;
    List<ApplicationConfiguration> virtualDirs = new List<ApplicationConfiguration>();
    if (IISUtilities.GetIISVersion(machineName) < 7)
    {
      IISUtilities.iisService = new DirectoryEntry($"IIS://{machineName}/W3SVC");
      if (IISUtilities.iisService == null)
        throw new Exception(Localize.GetString("STR_RC_WEB_APPLICATION_LOAD_ERROR"));
      foreach (DirectoryEntry child1 in IISUtilities.iisService.Children)
      {
        foreach (DirectoryEntry child2 in child1.Children)
        {
          if (string.Compare(child2.SchemaClassName, "IIsWebVirtualDir", StringComparison.OrdinalIgnoreCase) == 0)
          {
            foreach (DirectoryEntry child3 in child2.Children)
            {
              string localPath = string.Empty;
              if (child3.Properties.Contains("Path"))
                localPath = child3.Properties["Path"].Value.ToString();
              else if (string.Compare(child3.SchemaClassName, "IIsWebDirectory", StringComparison.OrdinalIgnoreCase) == 0)
                localPath = Path.Combine(Convert.ToString(child2.Properties["Path"].Value), child3.Name);
              virtualDirs.Add(new ApplicationConfiguration(child3.Name, localPath));
            }
          }
        }
      }
    }
    else
    {
      IISUtilities.serverManager = new ServerManager();
      foreach (Site site in (IEnumerable) IISUtilities.serverManager.Sites)
      {
        foreach (Application application in (IEnumerable) site.Applications)
        {
          foreach (VirtualDirectory virtualDirectory in (IEnumerable) application.VirtualDirectories)
          {
            string name = virtualDirectory.Name;
            if (string.IsNullOrEmpty(name))
              name = application.Name;
            virtualDirs.Add(new ApplicationConfiguration(name, virtualDirectory.PhysicalPath));
          }
        }
      }
    }
    return virtualDirs;
  }

  public static bool DoesVirtualDirectoryExist(string virtualDirName)
  {
    if (IISUtilities.GetIISVersion(Environment.MachineName) < 7)
    {
      DirectoryEntry directoryEntry = new DirectoryEntry($"IIS://{Environment.MachineName}/W3SVC");
      if (directoryEntry != null)
      {
        foreach (DirectoryEntry child1 in directoryEntry.Children)
        {
          foreach (DirectoryEntry child2 in child1.Children)
          {
            if (child2.SchemaClassName.Equals("IISWebVirtualDir", StringComparison.OrdinalIgnoreCase))
            {
              foreach (DirectoryEntry child3 in child2.Children)
              {
                if (child3.Name.Equals(virtualDirName, StringComparison.OrdinalIgnoreCase))
                  return true;
              }
            }
          }
        }
      }
    }
    else
    {
      IISUtilities.serverManager = new ServerManager();
      foreach (Site site in (IEnumerable) IISUtilities.serverManager.Sites)
      {
        foreach (Application application in (IEnumerable) site.Applications)
        {
          if (application.Name.Equals(virtualDirName, StringComparison.OrdinalIgnoreCase))
            return true;
        }
      }
    }
    return false;
  }

  public static bool DoesApplicationPoolExist(string appPoolName)
  {
    bool flag = false;
    DirectoryEntry directoryEntry = new DirectoryEntry($"IIS://{Environment.MachineName}/W3SVC/APPPOOLS");
    if (directoryEntry != null)
    {
      foreach (DirectoryEntry child in directoryEntry.Children)
      {
        if (child.Name.Equals(appPoolName, StringComparison.OrdinalIgnoreCase))
          return true;
      }
    }
    return flag;
  }

  public static DirectoryEntry GetDirectoryEntry(string virtualDirName)
  {
    try
    {
      DirectoryEntry directoryEntry = new DirectoryEntry($"IIS://{Environment.MachineName}/W3SVC");
      if (directoryEntry != null)
      {
        foreach (DirectoryEntry child1 in directoryEntry.Children)
        {
          foreach (DirectoryEntry child2 in child1.Children)
          {
            if (child2.SchemaClassName.Equals("IISWebVirtualDir", StringComparison.OrdinalIgnoreCase))
            {
              foreach (DirectoryEntry child3 in child2.Children)
              {
                if (child3.Name.Equals(virtualDirName, StringComparison.OrdinalIgnoreCase))
                  return child3;
              }
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ErrorViewerWriter.Write(ex);
    }
    return (DirectoryEntry) null;
  }

  public static DirectoryEntry GetApplicationPool(string appPoolName)
  {
    DirectoryEntry directoryEntry = new DirectoryEntry($"IIS://{Environment.MachineName}/W3SVC/APPPOOLS");
    if (directoryEntry != null)
    {
      foreach (DirectoryEntry child in directoryEntry.Children)
      {
        if (child.Name.Equals(appPoolName, StringComparison.OrdinalIgnoreCase))
          return child;
      }
    }
    return (DirectoryEntry) null;
  }

  public static int GetIISVersion(string serverName)
  {
    int iisVersion = 0;
    if (serverName.Equals("localhost", StringComparison.CurrentCultureIgnoreCase))
    {
      using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\InetStp"))
        iisVersion = (int) registryKey.GetValue("MajorVersion", (object) 0);
    }
    else
    {
      using (RegistryKey registryKey1 = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, serverName))
      {
        RegistryKey registryKey2 = registryKey1.OpenSubKey("SOFTWARE\\Microsoft\\InetStp");
        iisVersion = (int) registryKey2.GetValue("MajorVersion", (object) 0);
        registryKey2.Close();
      }
    }
    return iisVersion;
  }
}
