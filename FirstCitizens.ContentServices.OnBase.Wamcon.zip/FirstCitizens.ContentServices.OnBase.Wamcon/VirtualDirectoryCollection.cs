﻿namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class VirtualDirectoryCollection : CollectionBase<VirtualDirectory>
{
  private string _siteName;
  private long _siteId;
  private string _appName;

  internal VirtualDirectoryCollection(
    ServerManager serverManager,
    string siteName,
    long siteId,
    string appName)
    : base(serverManager)
  {
    this._appName = appName;
    this._siteName = siteName;
    this._siteId = siteId;
  }

  internal override void Add(VirtualDirectory value) => base.Add(value);
}
