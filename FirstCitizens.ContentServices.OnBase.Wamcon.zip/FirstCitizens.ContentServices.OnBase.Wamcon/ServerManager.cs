﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.DirectoryServices;

namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class ServerManager : IDisposable
{
  private LateBinding.ServerManager _microsoftServerManager;
  private DirectoryEntry _directoryEntry;
  private List<DirectoryEntry> _directoryEntries = new List<DirectoryEntry>();
  private int _majorVersion;
  private ApplicationPoolCollection _appPoolCollection;
  private SiteCollection _siteCollection;
  private DirectoryEntry _applicationPoolRoot;
  private ApplicationPool _appPool;
  private string _serverName;
  private bool _localHost;

  internal FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ServerManager MicrosoftServerManager
  {
    get => this._microsoftServerManager;
  }

  internal DirectoryEntry DirectoryEntry => this._directoryEntry;

  internal DirectoryEntry ApplicationPoolRoot => this._applicationPoolRoot;

  internal List<DirectoryEntry> DirectoryEntries => this._directoryEntries;

  internal string ServerName => this._serverName;

  public int MajorVersion => this._majorVersion;

  public ApplicationPoolCollection ApplicationPools => this._appPoolCollection;

  public SiteCollection Sites => this._siteCollection;

  public static ServerManager OpenRemote(string serverName) => new ServerManager(serverName);

  private ServerManager(string serverName)
  {
    this._serverName = serverName;
    this._majorVersion = this.GetVersion();
    if (this._majorVersion < 7)
      throw new IISMissingException("A supported version of IIS was not found.");
    this._microsoftServerManager = new FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ServerManager(serverName);
    this._appPoolCollection = new ApplicationPoolCollection(this);
    this._siteCollection = new SiteCollection(this);
    this.FillApplicationPoolCollection();
    this.FillSiteCollection();
  }

  public ServerManager()
    : this("localhost")
  {
  }

  private int GetVersion()
  {
    int version = 0;
    this._localHost = this._serverName.Equals("localhost", StringComparison.CurrentCultureIgnoreCase);
    if (this._localHost)
    {
      using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\InetStp"))
        version = (int) registryKey.GetValue("MajorVersion", (object) 0);
    }
    else
    {
      using (RegistryKey registryKey1 = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, this._serverName))
      {
        RegistryKey registryKey2 = registryKey1.OpenSubKey("SOFTWARE\\Microsoft\\InetStp");
        version = (int) registryKey2.GetValue("MajorVersion", (object) 0);
        registryKey2.Close();
      }
    }
    return version;
  }

  private void FillApplicationPoolCollection()
  {
    foreach (FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ApplicationPool applicationPool in this._microsoftServerManager.ApplicationPools)
    {
      this._appPool = new ApplicationPool(this, applicationPool.Name);
      this._appPoolCollection.Add(this._appPool);
    }
  }

  private void FillSiteCollection()
  {
    foreach (FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.Site site1 in this._microsoftServerManager.Sites)
    {
      using (Site site2 = new Site(this, site1.Name, site1.Id))
        this._siteCollection.Add(site2);
    }
  }

  public void Dispose()
  {
    if (this._microsoftServerManager != null)
    {
      this._microsoftServerManager.Dispose();
      this._microsoftServerManager = (FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ServerManager) null;
    }
    if (this._applicationPoolRoot != null)
    {
      this._applicationPoolRoot.Dispose();
      this._applicationPoolRoot = (DirectoryEntry) null;
    }
    if (this._appPool != null)
    {
      this._appPool.Dispose();
      this._appPool = (ApplicationPool) null;
    }
    if (this._directoryEntry != null)
    {
      this._directoryEntry.Dispose();
      this._directoryEntry = (DirectoryEntry) null;
    }
    foreach (Component directoryEntry in this._directoryEntries)
      directoryEntry?.Dispose();
  }
}
