﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;

#nullable disable
namespace FirstCitizens.ContentServices.OnBase.Wamcon;

public sealed class Site : IDisposable
{
  private long _id;
  private string _name;
  private string _physicalPath;
  private string _bindingInfo;
  private ServerManager _serverManager;
  private DirectoryEntry _directoryEntry;
  private DirectoryEntry _directoryEntryRoot;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.ServerManager _microsoftServerManager;
  private FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.Site _microsoftSite;
  private ApplicationCollection _applicationCollection;
  private VirtualDirectoryCollection _virtualDirectoryCollection;
  private Application _rootApplication;

  internal Site(ServerManager serverManager, string name, long siteId)
  {
    this._name = name;
    this._id = siteId;
    this._serverManager = serverManager;
    this._applicationCollection = new ApplicationCollection(this._serverManager, this._name, this._id);
    this._virtualDirectoryCollection = new VirtualDirectoryCollection(this._serverManager, this._name, this._id, "/");
    this._microsoftServerManager = this._serverManager.MicrosoftServerManager;
    this._microsoftSite = this._microsoftServerManager.Sites[this._name];
    this._physicalPath = this._microsoftSite.Applications["/"].VirtualDirectories["/"].PhysicalPath;
    this._bindingInfo = this._microsoftSite.Bindings[0].BindingInformation;
    foreach (FirstCitizens.ContentServices.OnBase.Wamcon.LateBinding.Application application1 in this._microsoftServerManager.Sites[this._name].Applications)
    {
      string path = application1.Path;
      if (application1.Path != "/")
      {
        using (Application application2 = new Application(this._serverManager, ((IEnumerable<string>) path.Split('/')).Last<string>(), application1.Path, this._id, this._name))
          this._applicationCollection.Add(application2);
      }
      else
      {
        Application application3 = new Application(this._serverManager, path, path, this._id, this._name);
        this._rootApplication = application3;
        foreach (VirtualDirectory virtualDirectory in (IEnumerable) application3.VirtualDirectories)
          this._virtualDirectoryCollection.Add(virtualDirectory);
      }
    }
  }

  public long Id => this._id;

  public string Name => this._name;

  public Application RootApplication => this._rootApplication;

  public string PhysicalPath
  {
    get => this._physicalPath;
    set
    {
      this._microsoftSite.Applications["/"].VirtualDirectories["/"].PhysicalPath = value;
      this._microsoftServerManager.CommitChanges();
      this._physicalPath = value;
    }
  }

  public ApplicationCollection Applications => this._applicationCollection;

  public VirtualDirectoryCollection VirtualDirectories => this._virtualDirectoryCollection;

  public void Dispose()
  {
    if (this._directoryEntry != null)
    {
      this._directoryEntry.Dispose();
      this._directoryEntry = (DirectoryEntry) null;
    }
    if (this._directoryEntryRoot != null)
    {
      this._directoryEntryRoot.Dispose();
      this._directoryEntryRoot = (DirectoryEntry) null;
    }
    if (this._rootApplication == null)
      return;
    this._rootApplication.Dispose();
    this._rootApplication = (Application) null;
  }

  public override string ToString() => $"Name = {this._name}, Id = {this._id}";
}
